# Pais gap loop: test equipment and instrumentation list

Companion to the A3 drawing set PTP-000…902 (13 Nov 2026). Examples are for specification only ("or equivalent"). Concept design for review.

## T1 · B6 TANGENTIAL COUPON SHOT

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| Two-stage light-gas gun range | 1 | smooth launch tube ≥ Ø38; 3.0 and 6.28 km/s with 26–31 g; blast tank + stripper; target tank ≥ 3.6 × 2.0 × 1.2 m, ≤ 1 mbar | large two-stage gun class, e.g. SwRI | facility |
| Track fixture + catcher | 1 | PTP-102/103; 668 kg (CAD); consumable liner, lips, witness plates | this drawing set | build |
| Coupons and sabots | 28+ | PTP-104; coupons EDM-cut from the rotor tape stack | this drawing set | build |
| Laser screens | 2 | diode light sheet + photoreceiver, rise < 20 ns, 0.5 m baseline | — | facility / buy |
| Flash X-ray | 4 heads | ≥ 450 kV, 20–35 ns, image plates or digital detectors | e.g. Scandiflash 450 kV class | facility / hire |
| High-speed cameras + light | 2 | ≥ 5 Mfps, ≥ 128 frames; pulsed LED or flash ≥ 1 ms | e.g. Shimadzu HPV-X2, Kirana class | hire |
| PDV velocimetry | 4 ch | 1550 nm seed + 2 W EDFA, circulators, LO upshift, ≥ 20 GHz photoreceivers; 5° exit probe | — | buy / build |
| PDV digitizer | 1 | ≥ 16 GHz, ≥ 50 GS/s, 4 ch, 1 ms record (beat 6.7–8.1 GHz) | e.g. Tektronix DPO70000SX / Keysight UXR class | buy / hire |
| PVDF stress gauges + conditioning | 9/shot | 25 µm PVDF; 0.1 Ω CVR or charge amplifiers | e.g. Dynasen PVF2 gauges | buy |
| Transient digitizers | 2 × 8 ch | 1 GS/s, 12 bit | — | buy |
| Triggering and timing | 1 set | velocity-adaptive trigger computer; 4-ch delay generator; TIC ≤ 1 ns; Rb 10 MHz | e.g. SRS DG645 | buy |
| Survey | 1 set | laser tracker (gap ±0.1 mm); 3D scanner / profilometer (gouges) | — | hire |

## T2a · B6 CONDUCTOR

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| High-field magnet + VTI | 1 | ≥ 30 T; Ø50 bore resistive (31 T) with ≥ Ø38 VTI, 4.2–25 K; or 32 mm bore with the Ø26 probe | NHMFL, HFML, LNCMI (user proposal) | facility |
| I_c probe, rotating, 1 kA | 1 | PTP-201: G10 head, Cu/HTS leads, α ±15° | this drawing set | build |
| DC current source | 1 | 1 kA / 10 V, ramp and 1–10 ms pulse modes, DCCT | e.g. TDK-Lambda Genesys class + pulse unit | buy |
| Quench detector + IGBT diverter | 1 | trip ≤ 100 µs on bridge, joint and lead taps | — | build |
| Nanovoltmeters | 2 | ≤ 10 nV noise | e.g. Keithley 2182A | buy |
| Fast DAQ | 1 | 24 bit, 100 kS/s, 8 ch (flux jumps) | — | buy |
| Thermometry | 1 + 2 | temperature controller + 2 Cernox + 2 film heaters | e.g. Lake Shore 336, CX-1050 | buy |
| Hall sensor + electronics; rotator drive | 1 + 1 | cryogenic Hall; stepper + encoder 0.005° | — | buy |
| REBCO tape samples | 2 bases | A-MOCVD thick film (4 µm, Hf/Zr), centre-slit, thick Cu; 50 µm and 0.1 mm | research tape (40 m pieces) | buy / partner |
| Bridge patterning; 77 K reel-to-reel I_c | — | w = 0.50 ±0.01 mm; lengthwise uniformity of 40 m pieces | lab or manufacturer service | service |

## T2b · B6 STATOR FIELD MAP

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| REBCO tape, 12 mm | 3.2 km | 4 single pancakes × 250 turns, insulated (Kapton co-wind) | e.g. Faraday Factory Japan, SuperOx, Fujikura, SuperPower, Shanghai SC | buy |
| Ring coil, former, overband, cryostat | 1 | PTP-203: r 500–530, 20 K, annular vessel r 465–645 | this drawing set | build |
| GM cryocoolers + compressors | 2 | single stage, ≥ 40 W at 20 K; water 10 kW | Cryomech AL / Sumitomo CH class | buy |
| Magnet PSU + protection | 1 | 600 A / 10 V, DCCT, ≤ 10 ppm; DC breaker, 1.25 Ω dump, balanced-bridge QD | e.g. Danfysik class | buy / build |
| Current leads | 1 pair | Cu 300→60 K + HTS 60→20 K, 600 A | — | buy / build |
| Mapping: stage, Hall array, coil, NMR | 1 set | non-magnetic piezo stage (2²⁴ counts); 5 × 3-axis Hall; search coil + integrator; NMR on axis | e.g. Senis / Metrolab THM1176, PDI 5025, PT2026 | buy |
| Trim-coil supplies | 16 | ±10 A bipolar | — | buy |
| Vacuum + thermometry | 1 set | turbo 300 l/s + scroll, gauges; controller + 6 Cernox, 2 PT100 | e.g. Pfeiffer HiPace, Edwards nXDS | buy |

## T3 · B7 FILM IN AN FEL CAVITY

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| FEL beam time | — | intracavity access at 30 µm (10 THz), 1 GHz micropulses, 8 µs macropulses, 10 Hz | FELIX Laboratory (FELICE), FHI FEL, ELBE | facility |
| Film station (chamber, holder, transfer) | 1 | PTP-301/302; ≤ 1e-10 mbar; diamond Brewster plate | this drawing set | build |
| MBE growth of K₃C₆₀ films | — | C₆₀ + K co-deposition, ≈ 2 ML/h, 12–24 ML | partner group (Struct. Dyn. 12, 024503, 2025) | partner |
| CVD diamond plates | 6+ | 30 × 16 × 0.5, optical grade, both sides polished, pads pre-patterned | e.g. Element Six / Diamond Materials | buy |
| UHV suitcase | 1 | ≤ 1e-10 mbar, ion pump + NEG, battery | e.g. Ferrovac class | buy |
| UHV LHe flow cryostat | 1 | 5–300 K, ≥ 15 W at 100 K | e.g. Lake Shore/Janis ST-400 UHV class | buy |
| Faraday magnetometry | 1 set | FEL-synchronised fs laser 800 nm; Wollaston; balanced detector | e.g. Thorlabs PDB450A class | facility / buy |
| IR reflectivity | 1 set | QCL or OPA probe; MCT/bolometer detectors ≥ 100 MHz | — | buy |
| Transport + thermometry + field | 1 set | bias tee, 40 GHz sampling or on-chip voltmeter; RTD 1 MHz amp; coil supply ±0.5 A | — | buy / build |
| Macropulse digitizers | 8 ch | ≥ 1 GS/s, tagged FEL-on/off | — | buy |

## T4 · GAP 4 / K4 NULL TEST

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| Vacuum chamber + pumps | 1 | Ø1640 × 1200, ≤ 1e-6 mbar, turbo 700 l/s, seismic block | — | buy / build |
| nN balance | 1 | Invar post, crossed-blade flexures, CFRP arm, comb calibrator, eddy damper, caging | C-Flex type pivots; TU Dresden practice | build |
| Displacement interferometer | 2 | pm/√Hz class (balance arm end; T4b antinode) | e.g. attocube IDS3010 class | buy |
| Rig electronics (on arm) | 1 set | Li-ion 24 V; Cockcroft–Walton ±100 kV; 100 MHz osc. + 10 W PA; piezo stack; MCU; IR link | — | build / OEM |
| Environment monitors | 1 set | 2 tiltmeters, fluxgate, 8 thermometers, gauges | e.g. Bartington Mag-03 class | buy |
| Resonant detector (T4b) | 1 | Ti-6Al-4V beam 1200 × 150 × 11.6 (42.0 Hz), isolation stack, Ø600 chamber | ETH dynamic-gravity group | partner |
| EM source + drive (T4b) | 1 set | capacitor/coil set in Cu + mu-metal; 21 Hz generator, power amp; accelerometers | — | build |
| Lock-in | 1 | 2f reference (42 Hz), τ 100–1000 s | e.g. SRS SR860 class | buy |

## T5 · X1 WITH UV CHARGE CONTROL

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| Vacuum chamber + pumps | 1 | Ø910 × 700, ≤ 1e-6 mbar, turbo 300 l/s | — | buy |
| µN balance with feedback | 1 | flexure pivots, CFRP arm r 0.35 m, voice coil ±10 mN, null sensor ≤ 1 µN | — | build |
| Sealed box + relay + IR link | 1 | Al 200 × 150 × 100, conductive gasket; vacuum reed relay | — | build |
| Deep-UV LEDs + fibres | 2 | 250 nm, ≥ 1 mW, drivers 1–100 nA photocurrent; solarisation-resistant fibre; grounded mesh | e.g. Crystal IS class LEDs | buy |
| Electron flood gun | 1 | 1–100 eV, nA–µA | e.g. Kimball Physics class | buy |
| Electrometer; ESV | 1 + 1 | fA–µA; non-contact ESV with vacuum-compatible probe (confirm) | e.g. Keithley 6517B; Trek-type ESV | buy |
| X1 device | 1 | as supplied by the claimant or built to their description | Exodus | partner |

## COMMON

| Item | Qty | Key specification | Example (or equivalent) | Source |
| --- | --- | --- | --- | --- |
| Data and safety | — | DAQ PCs, GPS/Rb timing, UPS; HV, X-ray, cryogen and laser safety; He leak detector; RGA | — | buy / facility |

## Drawing index

| Dwg | Title | Sheet |
| --- | --- | --- |
| PTP-000 | Cover, drawing index, programme diagram | 1 |
| PTP-101 | T1 · light-gas-gun range · general arrangement | 2 |
| PTP-102 | T1 · curved track fixture R 2000 · assembly | 3 |
| PTP-103 | T1 · track section, channel detail, entry geometry | 4 |
| PTP-104 | T1 · coupon and separating sabot | 5 |
| PTP-105 | T1 · instrumentation, triggering and timing | 6 |
| PTP-201 | T2a · variable-temperature I_c probe, 1 kA · GA | 7 |
| PTP-202 | T2a · I_c and flux-jump measurement · schematic | 8 |
| PTP-203 | T2b · REBCO ring coil Ø1 m and mapping arm · GA | 9 |
| PTP-204 | T2b · power, protection, cryogenics, mapping | 10 |
| PTP-301 | T3 · intracavity film station · GA | 11 |
| PTP-302 | T3 · film holder, Brewster plate, sensors | 12 |
| PTP-303 | T3 · timing, readout and sample transfer | 13 |
| PTP-401 | T4a · nN vacuum torsion balance · GA | 14 |
| PTP-402 | T4b · 42 Hz resonant beam detector · GA | 15 |
| PTP-403 | T4 · rig, balance and detector schematics | 16 |
| PTP-501 | T5 · µN balance, sealed box, charge control · GA | 17 |
| PTP-502 | T5 · charge control and F–Q test · schematic | 18 |
| PTP-901 | Equipment and instrumentation · T1, T2 | 19 |
| PTP-902 | Equipment and instrumentation · T3, T4, T5, common | 20 |
