"""PTP-000 cover / index / programme diagram, PTP-901..902 equipment and instrumentation list; also writes equipment CSV + markdown"""
import json, csv, sys, textwrap
import numpy as np
from ptp import *
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'
ONLY = sys.argv[1:]
INDEX = [('PTP-000', 'Cover, drawing index, programme diagram', 1),
         ('PTP-101', 'T1 · light-gas-gun range · general arrangement', 2), ('PTP-102', 'T1 · curved track fixture R 2000 · assembly', 3),
         ('PTP-103', 'T1 · track section, channel detail, entry geometry', 4), ('PTP-104', 'T1 · coupon and separating sabot', 5),
         ('PTP-105', 'T1 · instrumentation, triggering and timing', 6),
         ('PTP-201', 'T2a · variable-temperature I_c probe, 1 kA · GA', 7), ('PTP-202', 'T2a · I_c and flux-jump measurement · schematic', 8),
         ('PTP-203', 'T2b · REBCO ring coil Ø1 m and mapping arm · GA', 9), ('PTP-204', 'T2b · power, protection, cryogenics, mapping', 10),
         ('PTP-301', 'T3 · intracavity film station · GA', 11), ('PTP-302', 'T3 · film holder, Brewster plate, sensors', 12),
         ('PTP-303', 'T3 · timing, readout and sample transfer', 13),
         ('PTP-401', 'T4a · nN vacuum torsion balance · GA', 14), ('PTP-402', 'T4b · 42 Hz resonant beam detector · GA', 15),
         ('PTP-403', 'T4 · rig, balance and detector schematics', 16),
         ('PTP-501', 'T5 · µN balance, sealed box, charge control · GA', 17), ('PTP-502', 'T5 · charge control and F–Q test · schematic', 18),
         ('PTP-901', 'Equipment and instrumentation · T1, T2', 19), ('PTP-902', 'Equipment and instrumentation · T3, T4, T5, common', 20)]

EQ = {
 'T1 · B6 TANGENTIAL COUPON SHOT': [
  ('Two-stage light-gas gun range', '1', 'smooth launch tube ≥ Ø38; 3.0 and 6.28 km/s with 26–31 g; blast tank + stripper; target tank ≥ 3.6 × 2.0 × 1.2 m, ≤ 1 mbar', 'large two-stage gun class, e.g. SwRI', 'facility'),
  ('Track fixture + catcher', '1', 'PTP-102/103; 668 kg (CAD); consumable liner, lips, witness plates', 'this drawing set', 'build'),
  ('Coupons and sabots', '28+', 'PTP-104; coupons EDM-cut from the rotor tape stack', 'this drawing set', 'build'),
  ('Laser screens', '2', 'diode light sheet + photoreceiver, rise < 20 ns, 0.5 m baseline', '—', 'facility / buy'),
  ('Flash X-ray', '4 heads', '≥ 450 kV, 20–35 ns, image plates or digital detectors', 'e.g. Scandiflash 450 kV class', 'facility / hire'),
  ('High-speed cameras + light', '2', '≥ 5 Mfps, ≥ 128 frames; pulsed LED or flash ≥ 1 ms', 'e.g. Shimadzu HPV-X2, Kirana class', 'hire'),
  ('PDV velocimetry', '4 ch', '1550 nm seed + 2 W EDFA, circulators, LO upshift, ≥ 20 GHz photoreceivers; 5° exit probe', '—', 'buy / build'),
  ('PDV digitizer', '1', '≥ 16 GHz, ≥ 50 GS/s, 4 ch, 1 ms record (beat 6.7–8.1 GHz)', 'e.g. Tektronix DPO70000SX / Keysight UXR class', 'buy / hire'),
  ('PVDF stress gauges + conditioning', '9/shot', '25 µm PVDF; 0.1 Ω CVR or charge amplifiers', 'e.g. Dynasen PVF2 gauges', 'buy'),
  ('Transient digitizers', '2 × 8 ch', '1 GS/s, 12 bit', '—', 'buy'),
  ('Triggering and timing', '1 set', 'velocity-adaptive trigger computer; 4-ch delay generator; TIC ≤ 1 ns; Rb 10 MHz', 'e.g. SRS DG645', 'buy'),
  ('Survey', '1 set', 'laser tracker (gap ±0.1 mm); 3D scanner / profilometer (gouges)', '—', 'hire')],
 'T2a · B6 CONDUCTOR': [
  ('High-field magnet + VTI', '1', '≥ 30 T; Ø50 bore resistive (31 T) with ≥ Ø38 VTI, 4.2–25 K; or 32 mm bore with the Ø26 probe', 'NHMFL, HFML, LNCMI (user proposal)', 'facility'),
  ('I_c probe, rotating, 1 kA', '1', 'PTP-201: G10 head, Cu/HTS leads, α ±15°', 'this drawing set', 'build'),
  ('DC current source', '1', '1 kA / 10 V, ramp and 1–10 ms pulse modes, DCCT', 'e.g. TDK-Lambda Genesys class + pulse unit', 'buy'),
  ('Quench detector + IGBT diverter', '1', 'trip ≤ 100 µs on bridge, joint and lead taps', '—', 'build'),
  ('Nanovoltmeters', '2', '≤ 10 nV noise', 'e.g. Keithley 2182A', 'buy'),
  ('Fast DAQ', '1', '24 bit, 100 kS/s, 8 ch (flux jumps)', '—', 'buy'),
  ('Thermometry', '1 + 2', 'temperature controller + 2 Cernox + 2 film heaters', 'e.g. Lake Shore 336, CX-1050', 'buy'),
  ('Hall sensor + electronics; rotator drive', '1 + 1', 'cryogenic Hall; stepper + encoder 0.005°', '—', 'buy'),
  ('REBCO tape samples', '2 bases', 'A-MOCVD thick film (4 µm, Hf/Zr), centre-slit, thick Cu; 50 µm and 0.1 mm', 'research tape (40 m pieces)', 'buy / partner'),
  ('Bridge patterning; 77 K reel-to-reel I_c', '—', 'w = 0.50 ±0.01 mm; lengthwise uniformity of 40 m pieces', 'lab or manufacturer service', 'service')],
 'T2b · B6 STATOR FIELD MAP': [
  ('REBCO tape, 12 mm', '3.2 km', '4 single pancakes × 250 turns, insulated (Kapton co-wind)', 'e.g. Faraday Factory Japan, SuperOx, Fujikura, SuperPower, Shanghai SC', 'buy'),
  ('Ring coil, former, overband, cryostat', '1', 'PTP-203: r 500–530, 20 K, annular vessel r 465–645', 'this drawing set', 'build'),
  ('GM cryocoolers + compressors', '2', 'single stage, ≥ 40 W at 20 K; water 10 kW', 'Cryomech AL / Sumitomo CH class', 'buy'),
  ('Magnet PSU + protection', '1', '600 A / 10 V, DCCT, ≤ 10 ppm; DC breaker, 1.25 Ω dump, balanced-bridge QD', 'e.g. Danfysik class', 'buy / build'),
  ('Current leads', '1 pair', 'Cu 300→60 K + HTS 60→20 K, 600 A', '—', 'buy / build'),
  ('Mapping: stage, Hall array, coil, NMR', '1 set', 'non-magnetic piezo stage (2²⁴ counts); 5 × 3-axis Hall; search coil + integrator; NMR on axis', 'e.g. Senis / Metrolab THM1176, PDI 5025, PT2026', 'buy'),
  ('Trim-coil supplies', '16', '±10 A bipolar', '—', 'buy'),
  ('Vacuum + thermometry', '1 set', 'turbo 300 l/s + scroll, gauges; controller + 6 Cernox, 2 PT100', 'e.g. Pfeiffer HiPace, Edwards nXDS', 'buy')]}
EQ2 = {
 'T3 · B7 FILM IN AN FEL CAVITY': [
  ('FEL beam time', '—', 'intracavity access at 30 µm (10 THz), 1 GHz micropulses, 8 µs macropulses, 10 Hz', 'FELIX Laboratory (FELICE), FHI FEL, ELBE', 'facility'),
  ('Film station (chamber, holder, transfer)', '1', 'PTP-301/302; ≤ 1e-10 mbar; diamond Brewster plate', 'this drawing set', 'build'),
  ('MBE growth of K₃C₆₀ films', '—', 'C₆₀ + K co-deposition, ≈ 2 ML/h, 12–24 ML', 'partner group (Struct. Dyn. 12, 024503, 2025)', 'partner'),
  ('CVD diamond plates', '6+', '30 × 16 × 0.5, optical grade, both sides polished, pads pre-patterned', 'e.g. Element Six / Diamond Materials', 'buy'),
  ('UHV suitcase', '1', '≤ 1e-10 mbar, ion pump + NEG, battery', 'e.g. Ferrovac class', 'buy'),
  ('UHV LHe flow cryostat', '1', '5–300 K, ≥ 15 W at 100 K', 'e.g. Lake Shore/Janis ST-400 UHV class', 'buy'),
  ('Faraday magnetometry', '1 set', 'FEL-synchronised fs laser 800 nm; Wollaston; balanced detector', 'e.g. Thorlabs PDB450A class', 'facility / buy'),
  ('IR reflectivity', '1 set', 'QCL or OPA probe; MCT/bolometer detectors ≥ 100 MHz', '—', 'buy'),
  ('Transport + thermometry + field', '1 set', 'bias tee, 40 GHz sampling or on-chip voltmeter; RTD 1 MHz amp; coil supply ±0.5 A', '—', 'buy / build'),
  ('Macropulse digitizers', '8 ch', '≥ 1 GS/s, tagged FEL-on/off', '—', 'buy')],
 'T4 · GAP 4 / K4 NULL TEST': [
  ('Vacuum chamber + pumps', '1', 'Ø1640 × 1200, ≤ 1e-6 mbar, turbo 700 l/s, seismic block', '—', 'buy / build'),
  ('nN balance', '1', 'Invar post, crossed-blade flexures, CFRP arm, comb calibrator, eddy damper, caging', 'C-Flex type pivots; TU Dresden practice', 'build'),
  ('Displacement interferometer', '2', 'pm/√Hz class (balance arm end; T4b antinode)', 'e.g. attocube IDS3010 class', 'buy'),
  ('Rig electronics (on arm)', '1 set', 'Li-ion 24 V; Cockcroft–Walton ±100 kV; 100 MHz osc. + 10 W PA; piezo stack; MCU; IR link', '—', 'build / OEM'),
  ('Environment monitors', '1 set', '2 tiltmeters, fluxgate, 8 thermometers, gauges', 'e.g. Bartington Mag-03 class', 'buy'),
  ('Resonant detector (T4b)', '1', 'Ti-6Al-4V beam 1200 × 150 × 11.6 (42.0 Hz), isolation stack, Ø600 chamber', 'ETH dynamic-gravity group', 'partner'),
  ('EM source + drive (T4b)', '1 set', 'capacitor/coil set in Cu + mu-metal; 21 Hz generator, power amp; accelerometers', '—', 'build'),
  ('Lock-in', '1', '2f reference (42 Hz), τ 100–1000 s', 'e.g. SRS SR860 class', 'buy')],
 'T5 · X1 WITH UV CHARGE CONTROL': [
  ('Vacuum chamber + pumps', '1', 'Ø910 × 700, ≤ 1e-6 mbar, turbo 300 l/s', '—', 'buy'),
  ('µN balance with feedback', '1', 'flexure pivots, CFRP arm r 0.35 m, voice coil ±10 mN, null sensor ≤ 1 µN', '—', 'build'),
  ('Sealed box + relay + IR link', '1', 'Al 200 × 150 × 100, conductive gasket; vacuum reed relay', '—', 'build'),
  ('Deep-UV LEDs + fibres', '2', '250 nm, ≥ 1 mW, drivers 1–100 nA photocurrent; solarisation-resistant fibre; grounded mesh', 'e.g. Crystal IS class LEDs', 'buy'),
  ('Electron flood gun', '1', '1–100 eV, nA–µA', 'e.g. Kimball Physics class', 'buy'),
  ('Electrometer; ESV', '1 + 1', 'fA–µA; non-contact ESV with vacuum-compatible probe (confirm)', 'e.g. Keithley 6517B; Trek-type ESV', 'buy'),
  ('X1 device', '1', 'as supplied by the claimant or built to their description', 'Exodus', 'partner')],
 'COMMON': [
  ('Data and safety', '—', 'DAQ PCs, GPS/Rb timing, UPS; HV, X-ray, cryogen and laser safety; He leak detector; RGA', '—', 'buy / facility')]}

def eq_table(ax, x, y, groups, fs=4.5):
    colw = [50, 14, 172, 108, 38]
    rows = [('ITEM', 'QTY', 'KEY SPECIFICATION', 'EXAMPLE (OR EQUIVALENT)', 'SOURCE')]
    yy = table(ax, x, y, colw, rows, fs=fs)
    for g, items in groups.items():
        ax.add_patch(Rectangle((x, yy - 4.2), sum(colw), 4.2, color='#e8eef8', lw=0)); ax.text(x + 1, yy - 2.1, g, fontsize=fs + 0.6, weight='bold', va='center')
        ax.plot([x, x + sum(colw)], [yy - 4.2, yy - 4.2], 'k', lw=0.3); yy -= 4.2
        yy = table(ax, x, yy, colw, items, fs=fs, header=False, shade_first=False)
    return yy

if not ONLY or '000' in ONLY:
    fig, ax = sheet('COVER · DRAWING INDEX · PROGRAMME DIAGRAM', 'PTP-000', 1, 'NTS', 'TESTS T1–T5 · after the gap loop stopped (run 11)')
    ax.text(24, 276, 'PAIS GAP LOOP — TEST PROGRAMME', fontsize=17, weight='bold', va='top')
    ax.text(24, 266, 'Concept drawings for the five tests that decide what the gap research loop left open', fontsize=8.5, va='top', color='0.25')
    label(ax, 24, 250, 'SEQUENCE AND LEAD ITEMS', 'run cheapest first; no dates: each starts when its lead item clears')
    xs = [24, 66, 108, 150, 192]
    lead = [('T5', 'X1 device access;\nUV LEDs, balance'), ('T4', 'balance noise floor;\nETH collaboration'), ('T2', 'magnet-lab proposal;\n3.2 km tape for T2b'),
            ('T3', 'FEL proposal; new\nstation; MBE partner'), ('T1', 'range time; fixture\nand coupons')]
    for i, (x, (t_, l_)) in enumerate(zip(xs, lead)):
        b = blk(ax, x, 216, 36, 24, t_, l_.split('\n'), fc=['#eaf1fb', '#eaf1fb', '#fff8e6', '#fff8e6', '#fdecea'][i], fs=6)
        if i < 4: route(ax, [(x + 36, 228), (xs[i + 1], 228)], kind='signal')
    ax.text(24, 211, 'T5 and T4 are small-laboratory tests; T2 needs a high-field user facility and a coil build; T3 needs FEL beam time and a new cryogenic\nstation; T1 needs a light-gas-gun range and a curved track. Any T1–T5 result restarts the gap loop.', fontsize=5.0, va='top', linespacing=1.4)
    label(ax, 24, 196, 'PROGRAMME', 'gap or claim → test → what the result decides')
    rows = [('T5', 'X1 (Exodus) force claim · III.6–III.8', 'X1 in a sealed grounded box on a µN balance; UV / e-flood charge control', 'F ∝ Q² → 0 as charge is removed: electrostatic, X1 cut', 'force stays with Q = 0 in a sealed box: replicate outside', 'small lab', '501–502'),
            ('T4', 'Gap 4 / K4: EM–gravity coupling · III.3', 'nN vacuum balance (T4a); 42 Hz resonant detector with EM source (T4b)', 'null bounds the coupling at ≈ 1 nN / 7–28 pN', 'reproducible, reversal-proof signal: new physics', 'small lab + ETH', '401–403'),
            ('T2', 'B6 conductor + stator field · I.32–I.35', 'I_c at 30 T, 4.2–25 K (T2a); Ø1 m ring coil field map with shims (T2b)', 'J_e ≥ 11.6 kA/mm² at T_op; n = 1 ripple ≤ 6–80 ppm incl. drift', 'J_e short, jumps persist warm, or ripple/drift above target', 'magnet lab + coil build', '201–204'),
            ('T3', 'B7 light-driven K₃C₆₀ · V.9–V.13', 'MBE film on diamond at Brewster inside an FEL cavity, re-driven at 1 GHz', 'zero R + field expulsion held at ≥ 100 K', 'no expulsion at ≈ 50 nT: B7 cut', 'FEL beam time + MBE', '301–303'),
            ('T1', 'B6 burst-rotor debris · I.30, I.34', 'tape-stack coupon on an R 2000 concave track at 3.0 and 6.28 km/s', 'line load ≈ λv²/R ± 20 %, erosion within ablator', 'load stays high, debris escapes inward, or gouging beats budget', 'light-gas-gun range', '101–105')]
    table(ax, 24, 188, [10, 56, 98, 74, 74, 44, 26], [('TEST', 'GAP / CLAIM', 'RIG', 'PASS', 'FAIL', 'VENUE', 'SHEETS')] + rows, fs=4.9)
    label(ax, 24, 140, 'DELIVERABLES', None)
    notes(ax, 24, 135, 204, [
        'This A3 set (20 sheets): general arrangements, assemblies, details, schematics, block diagrams, equipment lists.',
        'STEP models (colours, named parts): T1 track fixture, T1 coupon and sabot, T2a probe, T2b ring and mapper, T3 station, T4a balance, T4b detector, T5 balance.',
        'DXF views at 1:1 (layers VISIBLE, HIDDEN, SECTION) for every modelled rig; shaded renders; the CAD and drawing scripts with the computed numbers (JSON).'], fs=5.0, title=None)
    notes(ax, 232, 140, 174, [
        'Status: concept design for review, not for manufacture. Facility items (guns, magnets, FELs) are drawn indicatively; confirm envelopes with each host.',
        'Units mm unless stated; third-angle projection; hidden lines dashed; sections hatched by part.',
        'Physics numbers come from the run sheet (items I.30–I.35, III.3–III.10, V.9–V.13) and the test plans; geometry-derived numbers (masses, fields, fluences, timings) are computed in the CAD scripts.',
        'Design checks raised here: T3 film fluence at Brewster (cos θ_B = 0.39) and macropulse heating; T2b peak field and hoop stress set 300 A as the operating point; T1 drag sets ≤ 1 mbar in the target tank.'], fs=4.9)
    from PIL import Image
    label(ax, 24, 110, 'THE RIGS', 'shaded CAD renders')
    for i, (fn, cap) in enumerate((('T1_fixture_iso', 'T1 track fixture'), ('T2b_ring_cutaway', 'T2b ring + mapper'), ('T3_station_cutaway', 'T3 FEL station'),
                                   ('T4a_balance_cutaway', 'T4a nN balance'), ('T5_balance_cutaway', 'T5 µN balance'))):
        put_image(ax, Image.open(f'{OUT}/renders/{fn}.png'), 24 + i * 41, 40, 39, 58, frame=True)
        ax.text(24 + i * 41 + 19.5, 36, cap, fontsize=4.8, ha='center', va='top')
    table(ax, 232, 281, [24, 128, 22], [('DWG NO', 'TITLE', 'SHEET')] + [(d, t_, s) for d, t_, s in INDEX], fs=4.6, title=None, aligns=['l', 'l', 'c'])
    save(fig, 'PTP-000')

if not ONLY or '901' in ONLY:
    fig, ax = sheet('EQUIPMENT AND INSTRUMENTATION LIST · T1, T2', 'PTP-901', 19, 'NTS', 'ALL TESTS · additional equipment needed beyond the rigs drawn')
    label(ax, 24, 281, 'EQUIPMENT AND INSTRUMENTATION · T1, T2a, T2b', 'examples are for specification only: “or equivalent”; source: facility, buy, hire, build, partner')
    eq_table(ax, 24, 274, EQ, fs=4.6)
    save(fig, 'PTP-901')
if not ONLY or '902' in ONLY:
    fig, ax = sheet('EQUIPMENT AND INSTRUMENTATION LIST · T3, T4, T5', 'PTP-902', 20, 'NTS', 'ALL TESTS · additional equipment needed beyond the rigs drawn')
    label(ax, 24, 281, 'EQUIPMENT AND INSTRUMENTATION · T3, T4, T5, COMMON', 'examples are for specification only: “or equivalent”')
    eq_table(ax, 24, 274, EQ2, fs=4.6)
    save(fig, 'PTP-902')

# CSV + markdown
with open(f'{OUT}/PTP_equipment_list.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['test', 'item', 'qty', 'key specification', 'example (or equivalent)', 'source'])
    for G in (EQ, EQ2):
        for g, items in G.items():
            for it in items: w.writerow([g] + list(it))
md = ['# Pais gap loop: test equipment and instrumentation list', '', 'Companion to the A3 drawing set PTP-000…902 (13 Nov 2026). Examples are for specification only ("or equivalent"). Concept design for review.', '']
for G in (EQ, EQ2):
    for g, items in G.items():
        md += [f'## {g}', '', '| Item | Qty | Key specification | Example (or equivalent) | Source |', '| --- | --- | --- | --- | --- |']
        md += [f'| {a} | {b} | {c} | {d} | {e} |' for a, b, c, d, e in items] + ['']
md += ['## Drawing index', '', '| Dwg | Title | Sheet |', '| --- | --- | --- |'] + [f'| {d} | {t_} | {s} |' for d, t_, s in INDEX]
open(f'{OUT}/PTP_equipment_list.md', 'w').write('\n'.join(md) + '\n')
print('ok')
