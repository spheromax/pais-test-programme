"""T2 sheets PTP-201..204 (reads out/t2.pkl)"""
import pickle, math, sys
import numpy as np
from PIL import Image
from ptp import *
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'

D = pickle.load(open(f'{OUT}/t2.pkl', 'rb')); PJ, NUM = D['PJ'], D['NUM']
TA = 'TEST T2a · B6 CONDUCTOR · I.32, I.35'
TB = 'TEST T2b · B6 STATOR FIELD MAP · I.33, ledger 36'
ONLY = sys.argv[1:]
nb = lambda I: NUM[f'B_orbit_{I}A']

# =====================================================================================  PTP-201 probe GA
if not ONLY or '201' in ONLY:
    fig, ax = sheet('T2a · VARIABLE-TEMPERATURE I_c PROBE, 1 kA, ROTATING · GA', 'PTP-201', 7, '1:10 · 1:1 · 5:1', TA)
    label(ax, 58, 279, 'PROBE  1:10', 'in magnet + VTI (phantom)')
    vp = View(ax, PJ['probe_front'], 10, 44, 0); vp.mc = np.array([0.0, 935.0]); vp.c = np.array([44.0, 184.0]); vp.draw(hidden=False, lw=0.4)
    # phantom magnet + VTI
    for r_, z0, z1, lab in ((19, -280, 1700, None), (23, -280, 1700, None), (25, -260, 260, None), (190, -260, 260, None)):
        for sx in (-1, 1):
            p, q = vp.P(sx * r_, z0), vp.P(sx * r_, z1); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.45', lw=0.35, ls=(0, (6, 2, 1, 2)))
    for zz in (-260, 260): p, q = vp.P(-190, zz), vp.P(190, zz); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.45', lw=0.35, ls=(0, (6, 2, 1, 2)))
    p = vp.P(-30, 0); q = vp.P(30, 0); ax.plot([p[0] - 6, q[0] + 6], [p[1], q[1]], color='k', lw=0.3, ls=(0, (10, 2, 2, 2))); ax.text(q[0] + 7, q[1], 'field centre, z = 0', fontsize=4.5, va='center')
    ax.text(*vp.P(-185, 230), 'MAGNET\n31 T, Ø50 bore\n(facility)', fontsize=4.5, va='top', color='0.35')
    ax.text(*vp.P(-185, -120), 'VTI (facility)', fontsize=4.5, color='0.35')
    ax.annotate('', xy=vp.P(120, 200), xytext=vp.P(120, -150), arrowprops=dict(arrowstyle='-|>', lw=0.8, color=BL, mutation_scale=7)); ax.text(*(vp.P(125, 40)), 'B', fontsize=7, color=BL, weight='bold')
    for zt, txt in ((1870, 'terminals 1 kA, 19-pin connectors,\nrotator stepper + encoder'), (1757, 'top flange (to suit VTI)'), (1100, 'Cu vapour-cooled leads Ø8'),
                    (1000, 'Cu radiation baffles ×5'), (240, 'HTS leads, Bi-2223, 1 kA'), (60, 'head (see 1:1)')):
        leader(ax, vp.P(16, zt), vp.P(60, zt + 30), txt, fs=4.5)
    dim(ax, vp.P(-18, -40), vp.P(-18, 1750), -9, '1 790 to flange', fs=4.5, mode='v')
    label(ax, 104, 279, 'HEAD  1:1', 'internals, head tube shown phantom')
    vf = View(ax, PJ['head_front'], 1, 120, 0); vf.mc = np.array([0.0, 20.0]); vf.c = np.array([124.0, 205.0]); vf.draw(hidden=False, lw=0.45)
    vs = View(ax, PJ['head_side'], 1, 175, 0); vs.mc = np.array([0.0, 20.0]); vs.c = np.array([180.0, 205.0]); vs.draw(hidden=False, lw=0.45)
    for vv in (vf, vs):
        for xx in (-18, -16, 16, 18):
            p, q = vv.P(xx, -40), vv.P(xx, 85); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.5', lw=0.35, ls=(0, (6, 2, 1, 2)))
        p, q = vv.P(-18, -40), vv.P(18, -40); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.5', lw=0.35, ls=(0, (6, 2, 1, 2)))
    dim(ax, vf.P(-18, -40), vf.P(18, -40), -5, 'Ø36', fs=4.6, mode='h')
    dim(ax, vs.P(-10.5, 0), vs.P(10.5, 0), 0, '', fs=1) if False else None
    leader(ax, vf.P(0, -1), (100, 168), 'sample (REBCO tape)\nface toward −y', fs=4.5, ha='right') if False else leader(ax, vf.P(-6, -1), (99, 170), 'sample, face −y', fs=4.5, ha='right')
    leader(ax, vf.P(8.5, 3), (147, 236), 'Cu current block ×2', fs=4.5)
    leader(ax, vf.P(-8, 30), (99, 245), 'Cu lead 5 × 5 ×2', fs=4.5, ha='right')
    leader(ax, vf.P(12.75, 2), (147, 228), 'worm + wheel (rotate ±15°)', fs=4.5)
    leader(ax, vf.P(0, 7), (99, 222), 'Hall sensor (angle, flux jumps)', fs=4.5, ha='right')
    leader(ax, vf.P(-16, 0), (99, 196), 'axle Ø4 in head tube', fs=4.5, ha='right')
    leader(ax, vs.P(0, -30), (198, 150), 'G10 head tube Ø36 × 2', fs=4.5)
    ax.annotate('', xy=vs.P(0, 0) + (0, 0), xytext=vs.P(0, 0) + (0.01, 0), arrowprops=dict(arrowstyle='-', lw=0.1))
    ax.add_patch(Arc(vs.P(0, 0), 30, 30, theta1=60, theta2=120, lw=0.5, color=BL)); ax.text(*(vs.P(0, 0) + (0, 17)), 'α ±15°', fontsize=4.6, ha='center', color=BL)
    ax.text(124, 140, 'FRONT', fontsize=5, ha='center'); ax.text(180, 140, 'SIDE', fontsize=5, ha='center')
    # sample 5:1
    label(ax, 98, 128, 'SAMPLE  5:1', 'bridge laser-cut or chemically etched in the tape; current along x ⊥ B; B ∥ ab at α = 0')
    vt = View(ax, PJ['sample_front'], 0.2, 160, 98); vt.draw(lw=0.6)
    for sx in (-1, 1):
        p0, p1 = vt.P(sx * 5.5, -2), vt.P(sx * 11, 2); ax.add_patch(Rectangle(np.minimum(p0, p1), *abs(p1 - p0), fc='#f0c890', ec='none', alpha=0.6, zorder=0))
    dim(ax, vt.P(-11, -2), vt.P(11, -2), -5, '22.0', fs=4.6, mode='h')
    dim(ax, vt.P(-2, 2), vt.P(2, 2), 4, '4.0 bridge', fs=4.6, mode='h')
    dim(ax, vt.P(11, -2), vt.P(11, 2), 4, '4.0', fs=4.6, mode='v')
    dim(ax, vt.P(-11, 2), vt.P(-5.5, 2), 4, '5.5 solder pad', fs=4.6, mode='h')
    leader(ax, vt.P(0, 0.25), (200, 116), 'w = 0.50 ±0.01 (measure)', fs=4.6)
    for xx in (-1.5, 1.5): q = vt.P(xx, 0); ax.plot(*q, 'o', ms=2.0, color=RD)
    ax.text(*(vt.P(0, -0.7) + (0, -1.5)), 'V taps 3.0 apart', fontsize=4.5, ha='center', color=RD, va='top')
    ax.annotate('', xy=vt.P(-6, -3.6), xytext=vt.P(-10, -3.6), arrowprops=dict(arrowstyle='-|>', lw=0.6, mutation_scale=5)); ax.text(*(vt.P(-10, -3.6) + (-1, 0)), 'I', fontsize=5.5, ha='right', va='center')
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'MATERIAL'),
            ('1', '1', 'Head tube Ø36 × 2, front window 20 × 26', 'G10'), ('2', '1', 'Rotor Ø21 × 22 on axle Ø4 (Ti), α ±15°', 'G10 / Ti'),
            ('3', '2', 'Current block 6 × 6 × 10, In-soldered pads', 'OFHC Cu'), ('4', '2', 'Flexible braid, 25 mm², block → lead', 'Cu'),
            ('5', '2', 'Lower lead 5 × 5 × 66', 'OFHC Cu'), ('6', '2', 'HTS lead, 4 tapes, 1 kA at ≤ 50 K', 'Bi-2223/AgAu'),
            ('7', '2', 'Vapour-cooled lead Ø8 tube, 1.35 m', 'Cu (RRR 50)'), ('8', '1', 'Worm m0.3 + wheel Ø10, drive rod Ø3', 'brass / G10'),
            ('9', '2', 'Cernox thermometer (one per block)', '—'), ('10', '2', 'Film heater 25 Ω on each block', '—'),
            ('11', '1', 'Cryogenic Hall sensor on rotor face', '—'), ('12', '1', 'Probe tube Ø36 × 0.5, 1.68 m', '316L'),
            ('13', '5', 'Radiation baffle Ø34.8 × 1', 'Cu'), ('14', '1', 'Top flange + head box, 2 × 1 kA terminals, 2 × 19-pin, rotator', 'SS / Al')]
    table(ax, 232, 184, [9, 9, 108, 48], rows, fs=4.7, title='PARTS')
    put_image(ax, Image.open(f'{OUT}/renders/T2a_head_iso.png'), 232, 192, 84, 84, title='HEAD · tubes transparent')
    put_image(ax, Image.open(f'{OUT}/renders/T2a_top_iso.png'), 322, 192, 84, 84, title='TOP END')
    notes(ax, 24, 62, 204, [
        f"Bridge 0.50 × 4.0 mm in a 4 µm film: I_c ≈ {NUM['Ic_bridge_A']:.0f} A at 30 T, B ∥ ab, 4.2 K if J_c = 36.3 MA/cm² (the full 4 mm tape would need ≈ {NUM['Ic_full_tape_A'] / 1000:.1f} kA). A 1 kA source covers every point.",
        'Envelope Ø36 suits a VTI with ≥ Ø38 sample space (50 mm-bore 31 T resistive magnet). For 32 mm-bore magnets (45 T hybrid, 38 T) build a Ø26 variant with 0.2 mm bridges (≈ 290 A).',
        'Rotation about x (the current direction) keeps I ⊥ B while tilting B out of the ab plane; zero α by the Hall-sensor minimum of the in-plane component, ±0.02°.',
        'Joints: ≥ 20 mm² In or In-Sn per pad, target ≤ 100 nΩ each; the bridge itself must be protected by the fast diverter on PTP-202.',
        'Temperature 4.2–25 K in flowing He gas: regulate on the block Cernox with the block heaters; record both blocks; reject points with ΔT > 0.1 K between blocks.'], fs=4.9)
    save(fig, 'PTP-201')

# =====================================================================================  PTP-202 schematic + matrix
if not ONLY or '202' in ONLY:
    fig, ax = sheet('T2a · I_c AND FLUX-JUMP MEASUREMENT · SCHEMATIC AND MATRIX', 'PTP-202', 8, 'NTS', TA)
    label(ax, 24, 279, 'CURRENT CIRCUIT AND SENSING', 'one sample · probe boundary dashed · flags = named nets')
    ax.add_patch(Rectangle((100, 150), 112, 122, fill=False, lw=0.6, ls=(0, (5, 2)))); ax.text(102, 268, 'PROBE (PTP-201)', fontsize=5.2, weight='bold')
    sym_src(ax, (52, 224), 'I', r=5); ax.text(45, 224, 'DC SOURCE\n1 kA / 10 V\n+ DCCT', fontsize=4.6, ha='right', va='center')
    wire(ax, [(52, 229), (52, 262), (60, 262)]); sym_R(ax, (60, 262), (80, 262), 'shunt 100 µΩ', w=1.2)
    wire(ax, [(80, 262), (110, 262)]); dot(ax, (92, 262))
    wire(ax, [(52, 219), (52, 206), (40, 206), (40, 276), (200, 276), (200, 262)]); dot(ax, (92, 276))
    sym_sw(ax, (92, 262), (92, 276), None); ax.text(88, 269, 'IGBT\ndiverter', fontsize=4.4, ha='right', va='center')
    flag(ax, (106, 269), 'TRIP', 'L', col=BL)
    flag(ax, (66, 224), 'I_SET', 'L')
    sym_R(ax, (110, 262), (110, 240), 'VC lead', w=1.0, lab_side=-1)
    ax.plot([110, 110], [240, 218], color='#30308c', lw=2.2); ax.text(113, 229, 'HTS', fontsize=4.6, va='center')
    sym_R(ax, (200, 262), (200, 240), None, w=1.0); ax.plot([200, 200], [240, 218], color='#30308c', lw=2.2)
    for xb in (110, 200):
        wire(ax, [(xb, 218), (xb, 210)]); ax.add_patch(Rectangle((xb - 6, 196), 12, 14, fc='#e9b98a', ec='k', lw=0.6, zorder=3))
        ax.text(xb, 203, 'Cu', fontsize=4.6, ha='center', va='center', zorder=4)
    ax.add_patch(Polygon([[116, 199], [140, 199], [146, 201.2], [164, 201.2], [170, 199], [194, 199], [194, 205], [170, 205], [164, 202.8], [146, 202.8], [140, 205], [116, 205]], closed=True, fc='0.25', ec='k', lw=0.4, zorder=3))
    ax.text(155, 207.5, 'BRIDGE 0.5 × 4', fontsize=4.6, ha='center')
    for xt in (150, 160): dot(ax, (xt, 202), 0.6, RD); wire(ax, [(xt, 202), (xt, 186)], col=RD, lw=0.5)
    sym_meter(ax, (155, 181), 'nV', col=RD); wire(ax, [(150, 186), (151.5, 183.5)], col=RD, lw=0.5); wire(ax, [(160, 186), (158.5, 183.5)], col=RD, lw=0.5)
    wire(ax, [(158.2, 181), (172, 181)], col=RD, lw=0.5); flag(ax, (172, 181), 'V_BR', 'R', col=RD)
    ax.text(155, 175, 'taps 3.0 apart: 1 µV/cm = 0.3 µV', fontsize=4.4, ha='center', color=RD)
    for xt in (128, 182): dot(ax, (xt, 202), 0.5, '#7b3fa0'); wire(ax, [(xt, 202), (xt, 168)], col='#7b3fa0', lw=0.4)
    wire(ax, [(128, 168), (182, 168), (190, 168)], col='#7b3fa0', lw=0.4); flag(ax, (190, 168), 'TAPS', 'R', col='#7b3fa0')
    ax.text(155, 164, 'joint + lead taps (also across HTS leads)', fontsize=4.4, ha='center', color='#7b3fa0')
    for xb, nm, sd in ((110, 'T1/H1', 'L'), (200, 'T2/H2', 'R')):
        sym_R(ax, (xb - 6, 192), (xb + 6, 192), None, w=0.8); ax.text(xb, 188.5, 'Cernox + heater', fontsize=4.2, ha='center', va='top')
        e = (xb - 6, 192) if sd == 'L' else (xb + 6, 192); flag(ax, (e[0] - 1 if sd == 'L' else e[0] + 1, 192), nm, sd)
    ax.add_patch(Rectangle((152, 213), 6, 4, fc=GOLD, ec='k', lw=0.4)); wire(ax, [(158, 215), (166, 215)], lw=0.4); flag(ax, (166, 215), 'HALL', 'R')
    ax.add_patch(Circle((132, 238), 4.5, fill=False, lw=0.6)); ax.text(132, 238, 'M', fontsize=5.2, ha='center', va='center', weight='bold')
    ax.text(132, 231.5, 'rotator (warm, top)', fontsize=4.3, ha='center', va='top'); flag(ax, (127.5, 238), 'STEP', 'L', col=RD)
    route(ax, [(136.5, 238), (155, 238), (155, 217)], kind='mech', arrow=True)
    ax.text(170, 262, 'B ∥ z (30 T)', fontsize=4.6, color=BL); ax.annotate('', xy=(166, 268), xytext=(166, 258), arrowprops=dict(arrowstyle='-|>', color=BL, lw=0.7, mutation_scale=5))
    def inst(x, y, w, h, title, lines, ins=(), outs=(), **kw):
        b = blk(ax, x, y, w, h, title, lines, **kw)
        for i, (nm, col) in enumerate(ins): flag(ax, (x - 1.0 - 0 * i, y + h - 5 - 4.4 * i), nm, 'L', col=col) if False else flag(ax, (x - 12.5, y + h - 5 - 4.4 * i), nm, 'R', col=col)
        for i, (nm, col) in enumerate(outs): flag(ax, (x + w + 0.5, y + h - 5 - 4.4 * i), nm, 'R', col=col)
        return b
    inst(244, 252, 46, 24, 'NANOVOLTMETER', ['V_bridge, 2182A class', 'shunt V on ch 2'], ins=[('V_BR', RD)])
    inst(316, 252, 46, 24, 'FAST DAQ 24 bit', ['100 kS/s, 8 ch', 'flux-jump capture'], ins=[('V_BR', RD), ('HALL', 'k'), ('TAPS', '#7b3fa0'), ('B(t)', 'k')])
    inst(244, 222, 46, 24, 'QUENCH DETECTOR', ['trip ≤ 100 µs', 'diverter + source off'], ins=[('TAPS', '#7b3fa0'), ('V_BR', RD)], outs=[('TRIP', BL)], fc='#fdecea')
    inst(316, 222, 46, 24, 'TEMPERATURE CTRL', ['2 Cernox, 2 heaters', '(336 class) + VTI'], ins=[('T1/H1', 'k'), ('T2/H2', 'k')])
    inst(244, 192, 46, 24, 'HALL ELECTRONICS', ['10 mA source + amp', 'α zero ±0.02°'], ins=[('HALL', 'k')])
    inst(316, 192, 46, 24, 'ROTATOR CONTROL', ['stepper + encoder', '0.005° step'], outs=[('STEP', RD)])
    inst(244, 162, 46, 24, 'MAGNET (facility)', ['31 T resistive, Ø50', 'B readback, ramps'], outs=[('B(t)', 'k')], dash=True)
    inst(316, 162, 46, 24, 'SOURCE CONTROL', ['1 kA, ramp or', '1–10 ms pulses'], ins=[('TRIP', BL)], outs=[('I_SET', 'k')])
    ax.text(244, 157, 'All instruments report to the logging PC (I–V sweeps, n-value, J_e(T, α, B), flux-jump records).', fontsize=4.5)
    sig_legend(ax, 244, 148, ['power', 'signal', 'trigger', 'mech'], cols=2, colw=64)
    rows = [('STEP', 'CONDITIONS', 'POINTS'),
            ('1 Cool, zero α', '4.2 K, 30 T; Hall minimum sets α = 0', '—'),
            ('2 I_c vs α', 'α = 0, ±0.5, ±1, ±2, ±5, ±10° at 4.2, 10, 15, 20, 25 K', '55 per sample'),
            ('3 I_c vs B', 'α = 0: 20, 25, 30, 31 T at 4.2 and 20 K', '8'),
            ('4 Flux jumps', 'ramp B at the spin-up rate and ×0.3, ×3; I = 0, 0.5, 0.8 I_c; 4.2, 15, 20, 25 K', '36 ramps'),
            ('5 Repeat', '4 samples: 50 µm and 0.1 mm bases, 2 bridges each', '≈ 400 I–V'),
            ('6 Uniformity', '40 m pieces, 77 K reel-to-reel I_c + Hall scan (separate rig)', 'per piece')]
    table(ax, 24, 140, [34, 138, 32], rows, fs=4.8, title='TEST MATRIX')
    rows2 = [('CRITERION', 'VALUE'),
             ('pass', f"J_e(T_op) ≥ 5.856 / 0.506 = {NUM['Je_pass']:.1f} kA/mm² (i ≤ 0.506)"),
             ('I_c definition', '1 µV/cm on the 3.0 mm tap span; record n-value'),
             ('prediction 50 µm basis', 'passes up to 24.5 K (23.5–25.4), T* = 22 K'),
             ('prediction 0.1 mm basis', 'passes up to 9.2 K (9.0–9.4)'),
             ('production tape', 'never passes'),
             ('flux jumps (I.35)', 'margin falls 18–50× from 4.2 to 15–20 K: jumps at 4.2 K should vanish warm; fail if they persist at 15–25 K')]
    table(ax, 232, 136, [44, 130], rows2, fs=4.8, title='PASS / FAIL AND PREDICTIONS')
    notes(ax, 24, 80, 204, [
        'Protection: a 0.5 mm bridge carrying ~700 A has almost no copper, so a normal zone must be cut in < 100 µs. The quench detector fires the IGBT diverter (current bypasses the probe) and drops the source.',
        'For the highest currents use 1–10 ms current pulses (short-sample practice) to limit joint heating; compare with slow ramps at lower currents.',
        'Flux-jump runs: record V_bridge and Hall at 100 kS/s; a jump shows as a step in the Hall signal with a voltage spike.'], fs=4.9)
    save(fig, 'PTP-202')

# =====================================================================================  PTP-203 ring GA
if not ONLY or '203' in ONLY:
    fig, ax = sheet('T2b · REBCO RING COIL Ø1 m AND FIELD-MAPPING ARM · GA', 'PTP-203', 9, '1:10 · 1:2', TB)
    SP = PJ['ring_sect_polys']
    SPh = [(n, (o, h)) for n, (o, h) in SP if o[:, 0].max() > -60]
    label(ax, 24, 279, 'HALF SECTION  1:10', 'plane through the axis at φ = 0 (arm position)')
    cols = {'PANCAKE': ('#3d56a6', ''), 'FORMER': ('#b9bec6', '////'), 'OVERBAND': ('#b9bec6', '////'), 'SHIELD': ('#e2e5ea', ''), 'VACUUM': ('#c9ccd2', '\\\\\\\\'),
            'COLD': ('#9da2aa', ''), 'COOLER': ('#5c5f66', ''), 'THERMAL': ('#d58b52', ''), 'COLUMN': ('#cfd3d8', '////'), 'ROTARY': ('#6b6e75', ''),
            'HUB': ('#cfd3d8', ''), 'ARM': ('#41444a', ''), 'PROBE': ('#f3f3ee', ''), 'HALL': ('#e6b84a', ''), 'SEARCH': ('#d58b52', ''), 'NMR': ('#d65c4a', ''),
            'LEAD': ('#9da2aa', ''), 'LEG': ('#cfd3d8', ''), 'STRUT': ('#8db36b', ''), 'TRIM': ('#d58b52', '')}
    def dsect(polys, den, mc, c, clip=None, lw=0.4):
        k = 1.0 / den; cp = Rectangle((clip[0], clip[1]), clip[2] - clip[0], clip[3] - clip[1], transform=ax.transData) if clip else None
        for name, (outer, holes) in polys:
            fc, h = next((v for kk, v in cols.items() if name.startswith(kk)), ('#dddddd', ''))
            verts, codes = [], []
            for w in [outer] + holes:
                q = c + (np.asarray(w) - mc) * k; verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
            pa = ax.add_patch(PathPatch(Path(verts, codes), facecolor=fc, edgecolor='k', lw=lw, hatch=h))
            if cp is not None: pa.set_clip_path(cp)
        return lambda u, v: c + (np.array([u, v]) - mc) * k
    PH = dsect(SPh, 10, np.array([300.0, -150.0]), np.array([66.0, 205.0]), clip=(26, 150, 112, 272))
    ax.plot(*zip(PH(0, -720), PH(0, 480)), color='k', lw=0.3, ls=(0, (10, 2, 2, 2))); ax.text(*(PH(0, 470) + (1, 0)), '℄ axis', fontsize=4.5)
    ax.plot(*zip(PH(-60, 0), PH(680, 0)), color='k', lw=0.25, ls=(0, (10, 2, 2, 2)))
    dim(ax, PH(0, -730), PH(650, -730), -5, '650', fs=4.5, mode='h') if False else None
    dim(ax, PH(0, 130), PH(450, 130), 3, 'orbit r 450', fs=4.5, mode='h')
    dim(ax, PH(645, -110), PH(645, 110), 4, '220', fs=4.5, mode='v')
    leader(ax, PH(580, 300), (100, 262), 'GM cold head', fs=4.5); leader(ax, PH(0, -400), (40, 156), 'Al column + piezo stage', fs=4.5)
    leader(ax, PH(200, 0), (64, 236), 'CFRP arm', fs=4.5, ha='right'); leader(ax, PH(0, 40), (34, 252), 'NMR probe', fs=4.5, ha='right')
    ax.add_patch(Circle(PH(545, 0), 9, fill=False, lw=0.5, ls=(0, (3, 1.5)))); ax.text(*(PH(545, 0) + (6, 9)), 'D', fontsize=7, weight='bold')
    label(ax, 118, 279, 'DETAIL D  1:2', 'winding, cryostat and the mapping orbit')
    PD = dsect(SP, 2, np.array([548.0, 0.0]), np.array([172.0, 212.0]), clip=(118, 150, 226, 272), lw=0.45)
    ax.add_patch(Rectangle((118, 150), 108, 122, fill=False, lw=0.3, ls=(0, (4, 2))))
    dim(ax, PD(500, 25.5), PD(530, 25.5), 30, '30 build', fs=4.5, mode='h')
    dim(ax, PD(530, -25.5), PD(530, 25.5), 18, '51 (4 × 12 + 3)', fs=4.5, mode='v')
    dim(ax, PD(465, -110), PD(645, -110), -6, 'vessel r 465–645', fs=4.5, mode='h')
    leader(ax, PD(515, 10), (205, 262), 'REBCO pancakes ×4\n12 mm tape, 250 t each', fs=4.5)
    leader(ax, PD(494, 30), (122, 262), 'SS former + flanges', fs=4.5)
    leader(ax, PD(533, -15), (205, 158), 'SS overband 6', fs=4.5)
    leader(ax, PD(479, -60), (122, 160), 'Al shield 3 + MLI', fs=4.5)
    leader(ax, PD(452, 14), (122, 214), 'Hall array r 395–452', fs=4.5)
    leader(ax, PD(468, 80), (122, 236), 'bore wall r 465', fs=4.5)
    # plan
    label(ax, 232, 279, 'PLAN  1:20', 'from +z · arm at φ = 0 · trim coils on both plates')
    vpl = View(ax, PJ['ring_plan'], 20, 300, 232); vpl.mc = np.array([0.0, 0.0]); vpl.draw(hidden=False, lw=0.35)
    for k in range(8):
        a = math.radians(22.5 + 45 * k); ax.text(*(vpl.P(700 * math.cos(a), 700 * math.sin(a))), f'T{k + 1}', fontsize=4.4, ha='center', va='center', color=OR)
    ax.add_patch(Circle(vpl.P(0, 0), 22.5, fill=False, lw=0.45, ls=(0, (8, 2, 1, 2)), color=RD)); ax.text(*(vpl.P(0, -470) + (0, -2)), 'mapping orbit r 450', fontsize=4.5, ha='center', color=RD)
    ax.add_patch(Arc(vpl.P(0, 0), 18, 18, theta1=0, theta2=60, lw=0.6, color=BL)); ax.text(*(vpl.P(170, 120)), 'φ', fontsize=6, color=BL)
    leader(ax, vpl.P(0, 580), (350, 272), 'current-lead turret', fs=4.5); leader(ax, vpl.P(-580, 0), (240, 214), 'cold head 2', fs=4.5)
    leader(ax, vpl.P(580, 0), (380, 214), 'cold head 1', fs=4.5)
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'MATERIAL'),
            ('1', '4', f"Single pancake, 12 mm REBCO, 250 turns, r 500–530 ({NUM['tape_km']:.1f} km of tape in all)", 'REBCO + Kapton'),
            ('2', '1', 'Former (bobbin + flanges) and overband', '316L'), ('3', '1', 'Thermal shield + 30 layers MLI', 'Al 1100'),
            ('4', '1', 'Annular vacuum vessel r 465–645 × 220', '316L'), ('5', '2', 'GM cold head, single stage, ≥ 40 W at 20 K', '—'),
            ('6', '1', 'Lead turret: Cu + HTS leads, 600 A', '—'), ('7', '16', 'Trim coil 80 × 120, 200 turns, ±10 A (8 per plate)', 'Cu'),
            ('8', '4 + 4', 'G10 struts Ø16; legs 60 × 60 × 600', 'G10 / Al'), ('9', '1', 'Column Ø150 + non-magnetic piezo rotary stage, encoder', 'Al'),
            ('10', '1', 'Arm 455 + counter-arm, probe head r 380–455', 'CFRP / G10'), ('11', '5', '3-axis Hall sensors r 395–452', '—'),
            ('12', '1', 'Search coil 20 × 20, 200 turns', 'Cu'), ('13', '1', 'NMR probe on axis (absolute field, drift)', '—')]
    table(ax, 24, 140, [8, 9, 145, 42], rows, fs=4.6, title='PARTS')
    rows2 = [('OPERATING POINT', '200 A', '300 A', '400 A'),
             ('B on orbit r 450, z 0', f"{nb(200):.2f} T", f"{nb(300):.2f} T", f"{nb(400):.2f} T"),
             ('B at centre', f"{NUM['B_centre_200A']:.2f} T", f"{NUM['B_centre_300A']:.2f} T", f"{NUM['B_centre_400A']:.2f} T"),
             ('peak B at inner turns', f"{NUM['B_max_winding_200A']:.1f} T", f"{NUM['B_max_winding_300A']:.1f} T", f"{NUM['B_max_winding_400A']:.1f} T"),
             ('B ⊥ tape at end pancakes', f"{NUM['Br_end_200A']:.1f} T", f"{NUM['Br_end_300A']:.1f} T", f"{NUM['Br_end_400A']:.1f} T"),
             ('hoop stress (BJR × 0.75)', f"{NUM['hoop_MPa_200A']:.0f} MPa", f"{NUM['hoop_MPa_300A']:.0f} MPa", f"{NUM['hoop_MPa_400A']:.0f} MPa"),
             ('stored energy (L = %.2f H)' % NUM['L_H'], f"{NUM['E_kJ_200A']:.0f} kJ", f"{NUM['E_kJ_300A']:.0f} kJ", f"{NUM['E_kJ_400A']:.0f} kJ"),
             ('target n = 1 ripple, 6–80 ppm', f"{6e-6 * nb(200) * 1e6:.0f}–{80e-6 * nb(200) * 1e6:.0f} µT", f"{6e-6 * nb(300) * 1e6:.0f}–{80e-6 * nb(300) * 1e6:.0f} µT", f"{6e-6 * nb(400) * 1e6:.0f}–{80e-6 * nb(400) * 1e6:.0f} µT")]
    table(ax, 232, 190, [62, 37, 37, 38], rows2, fs=4.8, title='COMPUTED FIELD AND LOADS (Biot–Savart, 20 K)', aligns=['l', 'c', 'c', 'c'])
    notes(ax, 232, 152, 174, [
        'Single ring, not a split pair: at the same orbit field two coils would pull together with ~2 MN and need struts through the mapping gap.',
        'Run at 300 A (1.15 T on the orbit). 400 A only after conductor and overband checks (≈ 370 MPa).',
        'All materials within 1 m of the orbit non-magnetic (Al, Ti, G10, CFRP, brass); motors stay below the floor plate.'], fs=4.8)
    put_image(ax, Image.open(f'{OUT}/renders/T2b_ring_cutaway.png'), 232, 66, 86, 60, title='CUTAWAY (half removed)')
    put_image(ax, Image.open(f'{OUT}/renders/T2b_ring_iso.png'), 322, 66, 84, 60, title='ISOMETRIC')
    # radial field profile
    prof = NUM['Bz_profile_300A']; gx, gy, gw, gh = 40, 22, 176, 40
    ax.add_patch(Rectangle((gx, gy), gw, gh, fill=False, lw=0.4))
    rr = np.array([p[0] for p in prof]) * 1e3; bb = np.array([p[1] for p in prof]); bm = 1.4
    ax.plot(gx + rr / 500 * gw, gy + bb / bm * gh, color=BL, lw=0.9)
    for xv in (0, 100, 200, 300, 400, 500): ax.text(gx + xv / 500 * gw, gy - 2.2, f'{xv}', fontsize=4.3, ha='center', va='top'); ax.plot([gx + xv / 500 * gw] * 2, [gy, gy + 1], 'k', lw=0.3)
    for yv in (0, 0.5, 1.0): ax.text(gx - 1.5, gy + yv / bm * gh, f'{yv:.1f}', fontsize=4.3, ha='right', va='center'); ax.plot([gx, gx + 1], [gy + yv / bm * gh] * 2, 'k', lw=0.3)
    ax.plot([gx + 450 / 500 * gw] * 2, [gy, gy + gh], color=RD, lw=0.4, ls=(0, (3, 2))); ax.text(gx + 450 / 500 * gw - 1, gy + gh - 3, 'orbit', fontsize=4.4, color=RD, ha='right')
    ax.plot([gx + 465 / 500 * gw] * 2, [gy, gy + gh], color='0.4', lw=0.4); ax.text(gx + 467 / 500 * gw, gy + 3, 'bore\nwall', fontsize=4.0, color='0.3')
    ax.text(gx + gw / 2, gy - 6.5, 'r (mm), midplane', fontsize=4.6, ha='center'); ax.text(26, gy + gh / 2, 'B_z (T)', fontsize=4.6, rotation=90, va='center', ha='center')
    ax.text(gx, gy + gh + 2.0, 'B_z(r) AT 300 A', fontsize=5.6, weight='bold')
    save(fig, 'PTP-203')

# =====================================================================================  PTP-204 schematic
if not ONLY or '204' in ONLY:
    fig, ax = sheet('T2b · RING POWER, PROTECTION, CRYOGENICS AND MAPPING · SCHEMATIC', 'PTP-204', 10, 'NTS', TB)
    label(ax, 24, 279, 'MAGNET CIRCUIT AND QUENCH PROTECTION', f"L = {NUM['L_H']:.2f} H · 300 A → {NUM['E_kJ_300A']:.0f} kJ · dump to ≤ 500 V")
    sym_src(ax, (55, 230), 'I', r=5); ax.text(48, 230, 'PSU\n600 A / 10 V\n+ DCCT', fontsize=4.6, ha='right', va='center')
    wire(ax, [(55, 235), (55, 262), (120, 262)]); wire(ax, [(55, 225), (55, 198), (120, 198)])
    sym_sw(ax, (70, 262), (92, 262), None); ax.text(81, 267, 'DC breaker / IGBT', fontsize=4.4, ha='center')
    wire(ax, [(100, 262), (100, 250)]); sym_R(ax, (100, 250), (100, 212), 'R_dump 1.25 Ω', w=1.4, lab_side=-1); wire(ax, [(100, 212), (100, 198)]); dot(ax, (100, 262)); dot(ax, (100, 198))
    for i in range(4):
        y0 = 258 - i * 15; sym_L(ax, (150, y0), (150, y0 - 12), n_=3, lab=f'P{i + 1}', col='#3d56a6')
        if i < 3: wire(ax, [(150, y0 - 12), (150, y0 - 15)])
        dot(ax, (150, y0), 0.5, '#7b3fa0'); wire(ax, [(150, y0), (170, y0)], col='#7b3fa0', lw=0.4)
    dot(ax, (150, 201), 0.5, '#7b3fa0'); wire(ax, [(150, 201), (170, 201), (170, 214)], col='#7b3fa0', lw=0.4)
    wire(ax, [(120, 262), (150, 262), (150, 258)]); wire(ax, [(120, 198), (150, 198), (150, 201)])
    ax.add_patch(Rectangle((140, 196), 20, 70, fill=False, lw=0.5, ls=(0, (4, 2)))); ax.text(150, 268, 'RING (4 pancakes)', fontsize=4.6, ha='center')
    q = blk(ax, 170, 214, 56, 40, 'QUENCH DETECTION', ['5 taps → balanced pairs', '(P1+P2) − (P3+P4), P1−P2, P3−P4', 'threshold 50 mV, 50 ms', 'opens breaker; heaters optional'], fc='#fdecea')
    route(ax, [q.p('T', 0.5), (198, 274), (81, 274), (81, 266)], kind='trigger', label='open', li=1, loff=(0, 1.2))
    ax.text(170, 206, 'Insulated (Kapton co-wound) pancakes keep the field\nfast and exact; no-insulation windings would add\ncharging delay and current redistribution.', fontsize=4.4, va='top')
    label(ax, 232, 279, 'CRYOGENICS AND VACUUM', 'conduction-cooled to 20 K')
    c1 = blk(ax, 232, 248, 54, 24, 'GM COLD HEADS ×2', ['single stage, ≥ 40 W at 20 K', 'Cu links to former'])
    c2 = blk(ax, 292, 248, 54, 24, 'COMPRESSORS ×2', ['water cooled', '(facility water 10 kW)'], dash=True)
    c3 = blk(ax, 352, 248, 54, 24, 'TEMPERATURE CTRL', ['6 Cernox on coil, 2 PT100', 'heater trim 20.0 ± 0.1 K'])
    c4 = blk(ax, 232, 218, 54, 24, 'VACUUM', ['turbo 300 l/s + scroll', 'gauge → interlock'])
    c5 = blk(ax, 292, 218, 54, 24, 'CURRENT LEADS', ['Cu 300→60 K + HTS 60→20 K', '600 A; lead V monitored'])
    c6 = blk(ax, 352, 218, 54, 24, 'INTERLOCK PLC', ['T > 25 K, p > 1e-4 mbar,', 'lead V → ramp down'], fc='#fdecea')
    route(ax, [c2.p('L', 0.5), c1.p('R', 0.5)], kind='cryo', both=True); route(ax, [c3.p('B', 0.5), c6.p('T', 0.5)], kind='signal')
    route(ax, [c4.p('R', 0.5), c5.p('L', 0.5)], kind='vacuum', arrow=False) if False else None
    route(ax, [c4.p('B', 0.5), (259, 212), (379, 212), c6.p('B', 0.5)], kind='signal')
    label(ax, 24, 186, 'FIELD MAPPING AND SHIMMING', 'B(φ) on the orbit every 10 min for 24 h')
    m1 = blk(ax, 24, 140, 46, 36, 'ROTARY STAGE', ['non-magnetic piezo,', '1 rev/min continuous', 'encoder 2²⁴ counts/rev'])
    m2 = blk(ax, 76, 140, 46, 36, 'HALL ARRAY ×5', ['3-axis, r 395–452', 'temperature-stabilised', '±0.01 % gain'])
    m3 = blk(ax, 128, 140, 46, 36, 'SEARCH COIL', ['moving tangentially', 'digital integrator', '(fluxmeter class)'])
    m4 = blk(ax, 180, 140, 46, 36, 'NMR TESLAMETER', ['probe on axis', 'absolute B, drift', '< 1 ppm'])
    m5 = blk(ax, 24, 96, 98, 32, 'DAQ (encoder-triggered)', ['4,096 samples per turn: Hall ×15 ch, coil flux', 'time stamp, I(t) from DCCT, T(t)'], fc='#eaf1fb')
    m6 = blk(ax, 128, 96, 98, 32, 'HARMONIC ANALYSIS (PC)', ['FFT of B_z(φ) at each radius → b_n, a_n, n = 1…8', 'drift db₁/dt; 24 h log; scaling to 30 T'], fc='#eaf1fb')
    m7 = blk(ax, 232, 140, 84, 36, 'TRIM-COIL SUPPLIES', ['16 × ±10 A bipolar (8 per plate)', 'set from the fitted a₁, b₁ … a₄, b₄', '200 turns: ≈ 1–3 mT per 10 A on the orbit'])
    m8 = blk(ax, 322, 140, 84, 36, 'CHARGING PROFILE', ['overshoot: ramp to I_op + 10 %, hold 10 min,', 'return to I_op; compare with plain ramp', 'and with field-cycling'])
    for b in (m1, m2, m3, m4): route(ax, [b.p('B', 0.5), (b.p('B', 0.5)[0], 128)], kind='signal' if b is not m1 else 'trigger')
    route(ax, [m5.p('R', 0.5), m6.p('L', 0.5)], kind='data')
    route(ax, [m6.p('R', 0.5), (232, 112), (274, 112), m7.p('B', 0.5)], kind='data', label='shim set-points', li=1, loff=(0, 1.2))
    route(ax, [m8.p('L', 0.85), m7.p('R', 0.85)], kind='data', arrow=False) if False else None
    rows = [('PASS / FAIL (T2b)', ''),
            ('pass', 'n = 1 ripple on the orbit inside 6–80 ppm of B₀ after shimming, and its drift over 24 h inside the same target; then scale up in field'),
            ('fail', 'no correction below ≈ 100 ppm, or drift beyond the target'),
            ('precedent', 'superconducting cyclotrons hold the first harmonic at 0.02–1.5 mT (absolute); the one REBCO cyclotron magnet built for field accuracy quenched at 250 of 540 A'),
            ('option (I.35)', 'stator wall at 15–20 K: the rotor then tolerates 0.7–1.8 mT')]
    table(ax, 24, 86, [28, 176], rows, fs=4.8, title=None)
    sig_legend(ax, 232, 100, ['power', 'signal', 'trigger', 'data', 'cryo'], cols=3, colw=58)
    notes(ax, 232, 82, 174, ['Resolution target: 1 ppm of B₀ at n = 1 (≈ 1.2 µT at 300 A), from 24 turns averaged per map.',
                              'Map at 200, 300 and 400 A, each with plain and overshoot charging.'], fs=4.8, title=None)
    save(fig, 'PTP-204')
print('ok')
