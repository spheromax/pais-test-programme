"""T1 · B6 tangential coupon shot - CAD models, projections, renders (cached for t1_sheets.py)"""
import math, json, pickle, time
import numpy as np
from ptp import *

t0 = time.time()
R = 2000.0; PH0, PH1 = -5.0, 40.0                      # track arc, phi measured from the tangent point (deg)
A = lambda ph: ph - 90.0                               # phi -> polar angle from +X
def P_arc(ph, r=R): a = math.radians(A(ph)); return np.array([r * math.cos(a), r * math.sin(a)])
STN = list(range(0, 41, 5))                            # PVDF gauge stations (phi)
NUM = {}

# ================================================================ fixture
fx = Rig('T1_track_fixture')
blocks = [sector(2006, 2106, -80, 160, A(PH0) + 15 * i, A(PH0) + 15 * (i + 1)) for i in range(3)]
for ph in STN:
    d = math.degrees(6 / 2006); pk = sector(2006, 2007, -6, 12, A(ph) - d, A(ph) + d)
    blocks = [b.cut(pk) for b in blocks]
for i, b in enumerate(blocks): fx.add(f'BLOCK {i + 1}', b, DSTEEL, '4340 / EN24 steel, Q&T')
fx.add('LINER', sector(2000, 2006, -30, 60, A(PH0), A(PH1)), LINER, 'per shot matrix')
fx.add('LIP UPPER', sector(1985, 2000, 10.5, 19.5, A(PH0), A(PH1)), STEEL, '4340 steel')
fx.add('LIP LOWER', sector(1985, 2000, -30, 19.5, A(PH0), A(PH1)), STEEL, '4340 steel')
for ph in STN:
    d = math.degrees(5 / 2006); fx.add(f'PVDF {ph}', sector(2006, 2006.5, -5, 10, A(ph) - d, A(ph) + d), PVDF, 'PVDF 25 µm gauge')
for i in range(3):
    fx.add(f'WITNESS {i + 1}', sector(1897, 1900, -60, 120, A(0) + 40 / 3 * i, A(0) + 40 / 3 * (i + 1)), (0.80, 0.90, 0.95), 'PC 3 mm, transparent')
for i, ph in enumerate((0, 40 / 3, 80 / 3, 40)):
    p = P_arc(ph, 1885); fx.add(f'POST {i + 1}', cyl(8, 140, (p[0], p[1], -80)), STEEL, 'steel Ø16')
fx.add('BASE PLATE', sector(1860, 2160, -140, 60, A(PH0) - 3, A(PH1) + 3), STEEL, 'S355 plate 60')
fx.add('SLIDE PLATE', sector(1840, 2180, -180, 40, A(PH0) - 4, A(PH1) + 4), STEEL, 'S355 plate 40')
for i, ph in enumerate((5, 35)):
    p = P_arc(ph, 2010)
    fx.add(f'RAIL {i + 1}', box(p[0] - 20, p[1] - 250, -215, 40, 500, 35), BLACK, 'linear guide, along Y')
    fx.add(f'SHIM PACK {i + 1}', box(p[0] - 40, p[1] + 250, -215, 80, 20, 60), GOLD, 'shims 1 / 5 / 20 mm')
g_show = 5.0
fx.add('COUPON (g = 5)', cbox(-150, -(R - g_show) + 1.1, 0, 25, 2.2, 20), RED, 'tape stack')
e = np.array([math.cos(math.radians(40)), math.sin(math.radians(40))]); nrm = np.array([-e[1], e[0]]); Pend = P_arc(40)
ang_e = 40.0
def along(s, lat=0.0): return Pend + e * s + nrm * lat
c1 = along(975); c2 = along(1175)
fx.add('CATCHER FACE', mv(rot(cbox(0, 0, 0, 50, 300, 300), (0, 0, 1), ang_e), c1[0], c1[1], 0), (0.86, 0.80, 0.55), 'Al honeycomb + PC layers')
fx.add('CATCHER BODY', mv(rot(cbox(0, 0, 0, 350, 340, 340), (0, 0, 1), ang_e), c2[0], c2[1], 0), DSTEEL, 'steel box, sand-filled')
pp = along(700, 61.2); dpr = unit(np.append(Pend - pp, 0))
fx.add('PDV PROBE', cyl(12.5, 80, (pp[0], pp[1], 0), tuple(-dpr)), BLACK, 'PDV collimator, 5° to exit line')
fx.add('PDV POST', cyl(10, 168, (pp[0], pp[1], -180)), STEEL, 'stand')
print('fixture parts', len(fx.parts), f'{time.time() - t0:.1f}s')

# masses (kg)
rho = {'BLOCK': 7.85, 'LINER': 7.85, 'LIP': 7.85, 'WITNESS': 1.20, 'POST': 7.85, 'BASE': 7.85, 'SLIDE': 7.85}
M = {}
for p in fx.parts:
    for k, r_ in rho.items():
        if p['name'].startswith(k): M[p['name']] = p['shape'].Volume() * r_ / 1e6
NUM['mass_kg'] = M
NUM['fixture_mass_kg'] = sum(M.values())
print('masses', {k: round(v, 1) for k, v in M.items()}, 'total', round(NUM['fixture_mass_kg']))

# ================================================================ entry geometry (wall radius R, shot line at R - g)
geo = []
for g in (1.0, 5.0, 20.0):
    th = math.degrees(math.acos((R - g) / R)); ximp = R * math.sin(math.radians(th)); arc = PH1 - th
    row = dict(g=g, theta=th, x_imp=ximp, arc=arc, vr={v: v * math.sin(math.radians(th)) for v in (3000, 6280)},
               ratio={mu: math.exp(-mu * math.radians(arc)) for mu in (0.1, 0.3, 0.5)})
    geo.append(row)
NUM['entry'] = geo
NUM['N_kN'] = {v: 8.8e-3 * v ** 2 / 2.0 / 1e3 for v in (3000, 6280)}
NUM['p_MPa'] = {v: 8.8e-3 * v ** 2 / 2.0 / (0.025 * 0.020) / 1e6 for v in (3000, 6280)}

# ================================================================ coupon + sabot
cs = Rig('T1_coupon_sabot')
coupon = cbox(0, 0, 0, 25, 2.2, 20)
xf = 12.6; L_s = 28.0; xr = xf - L_s
sab = cyl(19, L_s, (xr, 0, 0), (1, 0, 0))
sab = sab.cut(box(xf - 25.2, -1.15, -10.1, 25.2 + 1, 2.3, 20.2))
for sy in (-1, 1):
    for sz in (-1, 1):
        sab = sab.cut(cyl(6, 24, (xr, 7.78 * sy, 7.78 * sz), (1, 0, 0)))
sab = sab.cut(box(xr + 2.0, -0.3, -20, L_s, 0.6, 40)).cut(box(xr + 2.0, -20, -0.3, L_s, 40, 0.6))
sab = sab.cut(box(xr - 1, 18.4, -3, L_s + 2, 2, 6))                       # roll-index flat at +Y (wall side)
sab = sab.cut(torus(19, 1.2, (xf, 0, 0), (1, 0, 0)))                      # front edge relief
cs.add('SABOT', sab, POLY, 'UHMW-PE (or PC)')
cs.add('COUPON', coupon, RED, 'tape stack')
NUM['coupon_g'] = coupon.Volume() * 8.0 / 1000
NUM['sabot_g'] = {'UHMW-PE 0.94': sab.Volume() * 0.94 / 1000, 'PC 1.20': sab.Volume() * 1.20 / 1000}
for k, v in NUM['sabot_g'].items():
    m = (NUM['coupon_g'] + v) / 1000; NUM.setdefault('pkg_MJ', {})[k] = {vv: 0.5 * m * vv ** 2 / 1e6 for vv in (3000, 6280)}
print('coupon g', NUM['coupon_g'], 'sabot g', NUM['sabot_g'], 'pkg MJ', NUM['pkg_MJ'])

# ================================================================ projections
PJ = {}
comp_main = fx.compound(exclude=('COUPON',))
PJ['plan'] = hlr(comp_main, (0, 0, 1), (1, 0, 0)); print('plan', f'{time.time() - t0:.1f}s')
PJ['elev_s'] = hlr(comp_main, (0, -1, 0), (1, 0, 0))
# section A-A at phi = 20 (viewer upstream looking downstream)
al = math.radians(A(20)); rhat = np.array([math.cos(al), math.sin(al), 0]); that = np.array([-math.sin(al), math.cos(al), 0])
Nsec = -that
sect_parts = [p for p in fx.sel(exclude=('CATCHER', 'PDV', 'RAIL', 'SHIM', 'COUPON'))]
SP, kept = [], []
for p in sect_parts:
    polys, k = section_polys(p['shape'], (0, 0, 0), Nsec, rhat, defl=0.05)
    for pol in polys: SP.append((p['name'], pol))
    if k is not None: kept.append(k)
PJ['secAA'] = hlr(cq.Compound.makeCompound(kept), Nsec, rhat, defl=0.05)
PJ['secAA_polys'] = SP
print('section', len(SP), f'{time.time() - t0:.1f}s')
# coupon & sabot views (flight axis X): side (from -Z? use from +Y), front (from +X), top (from +Z)
csc = cs.compound()
PJ['cs_front'] = hlr(csc, (1, 0, 0), (0, 1, 0))       # looking aft from the front: y right, z up
PJ['cs_side'] = hlr(csc, (0, -1, 0), (1, 0, 0))       # from -Y: x right, z up
PJ['cs_top'] = hlr(csc, (0, 0, 1), (1, 0, 0))         # from +Z: x right, y up
spol, skept = section_polys(sab, (0, 0, 7.78), (0, 0, 1), (1, 0, 0), defl=0.02)   # section A-A: plane z = 7.78 through two lightening holes, viewed from +Z
cpol, _ = section_polys(coupon, (0, 0, 7.78), (0, 0, 1), (1, 0, 0), defl=0.02)
PJ['sab_sec'] = hlr(cq.Compound.makeCompound([skept]), (0, 0, 1), (1, 0, 0), defl=0.02)
PJ['sab_sec_polys'] = [('SABOT', p) for p in spol] + [('COUPON', p) for p in cpol]
PJ['coupon3'] = {k: hlr(coupon, n, vx, defl=0.01) for k, (n, vx) in dict(front=((1, 0, 0), (0, 1, 0)), side=((0, -1, 0), (1, 0, 0)), top=((0, 0, 1), (1, 0, 0))).items()}
print('coupon/sabot views', f'{time.time() - t0:.1f}s')

# ================================================================ renders
N, Vx = iso(62, 32)
img = render(fx.parts, N, Vx, size=1500, zoom=1.05, opacity={f'WITNESS {i}': 0.35 for i in (1, 2, 3)}); img.save(f'{OUT}/renders/T1_assembly_iso.png')
render(fx.sel(exclude=('CATCHER', 'PDV')), N, Vx, size=1600, zoom=1.0, opacity={f'WITNESS {i}': 0.35 for i in (1, 2, 3)}).save(f'{OUT}/renders/T1_fixture_iso.png')
# close-up of entry: intersect parts with a box around the entry
clip = cbox(40, -1990, -40, 520, 360, 420)
close = []
for p in fx.sel(exclude=('CATCHER', 'PDV', 'RAIL', 'SHIM', 'WITNESS', 'POST')):
    try:
        s = p['shape'].intersect(clip)
        if s.Volume() > 1e-3: close.append(dict(p, shape=s))
    except Exception: pass
N2, Vx2 = iso(100, 22)
render(close, N2, Vx2, size=1300, zoom=1.0).save(f'{OUT}/renders/T1_entry_closeup.png')
N3, Vx3 = iso(-35, 25)
csx = [dict(cs.parts[0]), dict(cs.parts[1], shape=mv(coupon, 45, 0, 0))]
render(csx, N3, Vx3, size=1100, zoom=0.95).save(f'{OUT}/renders/T1_coupon_sabot_exploded.png')
render(cs.parts, N3, Vx3, size=900, zoom=0.95).save(f'{OUT}/renders/T1_coupon_sabot_iso.png')
print('renders', f'{time.time() - t0:.1f}s')

# ================================================================ exports
print(fx.step(), cs.step())
write_dxf('T1_fixture_plan_and_section', [('PLAN (top)', *PJ['plan'], None, (0, 0)), ('SECTION A-A (phi 20)', *PJ['secAA'], [p for _, p in SP], (0, 2600))])
write_dxf('T1_coupon_sabot', [('FRONT', *PJ['cs_front'], None, (0, 0)), ('SIDE', *PJ['cs_side'], None, (80, 0)), ('TOP', *PJ['cs_top'], None, (80, 80)),
                               ('SECTION (XZ)', *PJ['sab_sec'], [p for _, p in PJ['sab_sec_polys']], (160, 0))])
pickle.dump(dict(PJ=PJ, NUM=NUM, R=R, PH0=PH0, PH1=PH1, STN=STN, Pend=Pend, e=e, nrm=nrm, pp=pp,
                 parts=[(p['name'], p['mat']) for p in fx.parts]), open(f'{OUT}/t1.pkl', 'wb'))
json.dump(NUM, open(f'{OUT}/t1_numbers.json', 'w'), indent=1, default=str)
print('done', f'{time.time() - t0:.1f}s')
