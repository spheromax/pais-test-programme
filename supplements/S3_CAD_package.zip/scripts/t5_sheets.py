"""T5 sheets PTP-501..502 (reads out/t5.pkl)"""
import pickle, math, sys
import numpy as np
from PIL import Image
from ptp import *
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'
D = pickle.load(open(f'{OUT}/t5.pkl', 'rb')); PJ, NUM = D['PJ'], D['NUM']
TT = 'TEST T5 · X1 (EXODUS) WITH UV CHARGE CONTROL · III.6–III.8'
ONLY = sys.argv[1:]
F0 = 4.46e-3; Q0 = NUM['Q0']
cols = {'CHAMBER': ('#c9ccd2', '////'), 'FLOOR': ('#c9ccd2', '////'), 'LID': ('#c9ccd2', '////'), 'POST': ('#9aa0a8', '////'), 'PIVOT': ('#e0c070', ''),
        'ARM': ('#41444a', ''), 'BOX LID': ('#b9bec6', ''), 'BOX HANGER': ('#cfd3d8', ''), 'BOX': ('#d9dde3', '\\\\\\\\'), 'X1': ('#d58b52', ''), 'SENSE': ('#e6b84a', ''),
        'COUNTER': ('#c9a46a', ''), 'VC MAGNET': ('#5a5d64', ''), 'VC COIL': ('#d58b52', 'xx'), 'VC BRACKET': ('#9aa0a8', ''), 'CAP': ('#4c5a8c', ''),
        'SENSOR POST': ('#9aa0a8', ''), 'UV': ('#7a5cc0', ''), 'COLLECTOR': ('#e6b84a', ''), 'E FLOOD': ('#5a5d64', ''), 'ESV PROBE': ('#333333', ''),
        'ESV POST': ('#9aa0a8', ''), 'FIBRE': ('#6a6ab8', ''), 'PUMP': ('#c9ccd2', ''), 'GROUND': ('#333333', '')}
def dsect(ax, polys, den, mc, c, lw=0.35):
    k = 1.0 / den
    for name, (outer, holes) in polys:
        fc, h = next((v for kk, v in sorted(cols.items(), key=lambda kv: -len(kv[0])) if name.startswith(kk)), ('#dddddd', ''))
        verts, codes = [], []
        for w in [outer] + holes:
            q = c + (np.asarray(w) - mc) * k; verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
        ax.add_patch(PathPatch(Path(verts, codes), facecolor=fc, edgecolor='k', lw=lw, hatch=h))
    return lambda u, v: c + (np.array([u, v]) - mc) * k

# =====================================================================================  PTP-501
if not ONLY or '501' in ONLY:
    fig, ax = sheet('T5 · µN VACUUM BALANCE, SEALED BOX AND CHARGE CONTROL · GA', 'PTP-501', 17, '1:10 · 1:5', TT)
    label(ax, 24, 279, 'SECTION A–A  1:10', 'vertical plane through the arm (y = 0), from −y; items beyond shown')
    vS = View(ax, PJ['sec'], 10, 0, 0); vS.mc = np.array([0.0, -50.0]); vS.c = np.array([72.0, 226.0]); vS.draw(hidden=False, lw=0.3)
    PA = dsect(ax, PJ['sec_polys'], 10, np.array([0.0, -50.0]), np.array([72.0, 226.0]))
    leader(ax, PA(350, -80), (110, 196), 'sealed box with X1', fs=4.5)
    leader(ax, PA(-400, 40), (30, 268), 'feedback voice coil', fs=4.5)
    leader(ax, PA(-320, -40), (30, 190), 'counterweight', fs=4.5)
    leader(ax, PA(0, 0), (72, 268), 'flexure pivot', fs=4.5)
    dim(ax, PA(-455, -415), PA(455, -415), -5, 'Ø910', fs=4.5, mode='h')
    label(ax, 130, 279, 'PLAN  1:10', 'lid removed')
    vP = View(ax, PJ['plan'], 10, 0, 0); vP.mc = np.array([0.0, -20.0]); vP.c = np.array([180.0, 228.0]); vP.draw(hidden=False, lw=0.3)
    leader(ax, vP.P(300, -300), (140, 186), 'electron flood gun', fs=4.5)
    leader(ax, vP.P(0, -470), (184, 182), 'UV fibre feedthrough', fs=4.5)
    leader(ax, vP.P(-200, -520), (136, 196), 'CF100 to turbo', fs=4.5) if False else None
    leader(ax, vP.P(500, -140), (222, 196), 'UV1 → box', fs=4.5, ha='right')
    leader(ax, vP.P(500, 140), (222, 270), 'UV2 → collector', fs=4.5, ha='right')
    label(ax, 24, 172, 'BOX AND CHARGE-CONTROL DETAIL  1:5', 'plan around the box (+x end)')
    vB = View(ax, PJ['box_plan'], 5, 0, 0); vB.mc = np.array([380.0, -40.0]); vB.c = np.array([110.0, 118.0]); vB.draw(hidden=True, lw=0.45)
    dim(ax, vB.P(250, -75), vB.P(450, -75), -6, '200', fs=4.5, mode='h'); dim(ax, vB.P(250, -75), vB.P(250, 75), -6, '150', fs=4.5, mode='v')
    for tgt, at, txt in (((350, -40), (40, 150), 'X1 inside (battery + driver)'), ((450, 0), (176, 156), 'Au sense patch / ESV probe 3 mm'),
                         ((469, 80), (176, 140), 'Au collector → electrometer'), ((495, -130), (176, 92), 'UV1 collimator + grounded mesh'),
                         ((495, 130), (176, 166), 'UV2 collimator'), ((330, -150), (40, 86), 'electron flood gun'), ((360, 25), (40, 160), 'ground / float relay')):
        leader(ax, vB.P(*tgt), at, txt, fs=4.5)
    # charge path arrows
    for (p, q, col) in (((495, -130), (452, -60), '#7a5cc0'), ((495, 130), (472, 85), '#7a5cc0'), ((300, -210), (330, -78), '#555555')):
        ax.annotate('', xy=vB.P(*q), xytext=vB.P(*p), arrowprops=dict(arrowstyle='-|>', color=col, lw=0.6, ls=(0, (2, 1)), mutation_scale=5))
    put_image(ax, Image.open(f'{OUT}/renders/T5_balance_cutaway.png'), 232, 190, 86, 86, title='CUTAWAY')
    put_image(ax, Image.open(f'{OUT}/renders/T5_box_iso.png'), 320, 190, 86, 86, title='BOX + CHARGE CONTROL')
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'NOTE'),
            ('1', '1', 'Chamber Ø910 × 700, CF100 to turbo 300 l/s', '≤ 1e-6 mbar'),
            ('2', '1', 'Invar post + conductive flexure pivots', 'arm grounded'),
            ('3', '1', 'CFRP arm 40 × 40, 0.76 m', 'r = 0.35 m'),
            ('4', '1', 'Sealed Al box 200 × 150 × 100, conductive gasket', 'X1 inside'),
            ('5', '1', 'X1 + cell + IR-commanded driver (228 µW)', 'device under test'),
            ('6', '1', 'Vacuum reed relay: box grounded or floating', 'IR-commanded'),
            ('7', '1', 'Feedback voice coil (magnet on arm, coil on frame)', '±10 mN, ≤ 1 µN'),
            ('8', '1', 'Capacitive/fibre displacement sensor (null)', '—'),
            ('9', '2', 'Deep-UV LED 250 nm, fibre + collimator + mesh', '1–100 nA'),
            ('10', '1', 'Au collector electrode → electrometer', 'charge transfer'),
            ('11', '1', 'Electron flood gun 1–100 eV', 'negative charging'),
            ('12', '1', 'Non-contact ESV probe on Au sense patch', 'box potential'),
            ('13', '1', 'Counterweight (brass, trimmed)', '—')]
    table(ax, 232, 184, [8, 8, 116, 42], rows, fs=4.5, title='PARTS')
    notes(ax, 232, 112, 174, [
        'Configuration A (as the claimants ran it): box lid off, X1 exposed; UV aimed at its dielectric surfaces. Configuration B: lid on, box grounded.',
        'Air ionisers do not work in vacuum; UV photoemission (4.88 eV at 254 nm) and electron flooding are the vacuum tools (LISA Pathfinder practice).',
        'Calibrate the balance with the voice coil and, separately, by charging the floating box to known Q and fitting F = cQ².'], fs=4.7)
    save(fig, 'PTP-501')

# =====================================================================================  PTP-502
if not ONLY or '502' in ONLY:
    fig, ax = sheet('T5 · CHARGE CONTROL, MEASUREMENT AND F–Q TEST · SCHEMATIC', 'PTP-502', 18, 'NTS', TT)
    label(ax, 24, 281, 'SCHEMATIC', 'charge in, charge out, charge measured; the balance reads force')
    ax.add_patch(Rectangle((24, 190), 204, 82, fill=False, lw=0.6, ls=(0, (5, 2)))); ax.text(26, 268.5, 'VACUUM CHAMBER', fontsize=4.6, weight='bold')
    bx = blk(ax, 92, 214, 54, 34, 'SEALED BOX (on arm)', ['X1 + cell inside', 'C_box ≈ 20–30 pF to chamber'], fc='#eef1f5')
    sym_sw(ax, (119, 214), (119, 200), None); ax.text(124, 207, 'ground / float relay', fontsize=4.4, va='center'); sym_gnd(ax, (119, 198))
    uv1 = blk(ax, 30, 240, 44, 18, 'UV1 → box / X1', ['250 nm, mesh'], fc='#efe8fb'); uv2 = blk(ax, 30, 214, 44, 18, 'UV2 → collector', ['250 nm, mesh'], fc='#efe8fb')
    eg = blk(ax, 30, 194, 44, 16, 'E-FLOOD GUN', ['1–100 eV'])
    co = blk(ax, 164, 230, 56, 18, 'Au COLLECTOR', ['→ electrometer (I)'], fc='#fbf1d6')
    es = blk(ax, 164, 206, 56, 18, 'ESV PROBE', ['box potential V'])
    route(ax, [uv1.p('R'), bx.p('L', 0.85)], kind='optical', label='e⁻ out: box +', li=0, loff=(0, 2.0))
    route(ax, [uv2.p('R'), (84, 223), (84, 238), (164, 238)], kind='optical') if False else route(ax, [uv2.p('R', 0.5), (160, 223), (160, 236), co.p('L', 0.33)], kind='optical')
    ax.text(150, 219.5, 'e⁻ from collector → box −', fontsize=4.4, ha='center', color=OR)
    route(ax, [eg.p('R'), (88, 202), (88, 220), bx.p('L', 0.18)], kind='signal', label='e⁻ beam: box −', li=0, loff=(-2, 2.0))
    route(ax, [es.p('L'), bx.p('R', 0.3)], kind='mech', arrow=False)
    # outside
    o1 = blk(ax, 232, 248, 56, 26, 'UV LED DRIVERS ×2', ['250 nm, 0–1 mW optical', 'pulse/DC; sets 1–100 nA'], fc='#efe8fb')
    o2 = blk(ax, 294, 248, 56, 26, 'ELECTROMETER', ['collector current, fA–µA', '(6517B class), integrates Q'])
    o3 = blk(ax, 356, 248, 50, 26, 'ESV READOUT', ['±kV, non-contact', 'Q = C_box · V'])
    o4 = blk(ax, 232, 214, 56, 26, 'FLOOD GUN SUPPLY', ['energy 1–100 eV', 'emission nA–µA'])
    o5 = blk(ax, 294, 214, 56, 26, 'BALANCE CONTROL', ['null sensor → PID →', 'voice-coil current = F'], fc='#eaf1fb')
    o6 = blk(ax, 356, 214, 50, 26, 'X1 + RELAY CMD', ['IR link: X1 on/off,', 'box ground/float'])
    o7 = blk(ax, 294, 186, 56, 20, 'DAQ + PC', ['F(t), Q(t), I(t), V(t)'], fc='#eaf1fb')
    for b_ in (o1, o2, o3, o4, o6): pass
    route(ax, [o1.p('B', 0.5), (260, 242), (230, 242), (230, 249), uv1.p('R', 0.1)], kind='optical', arrow=False) if False else None
    ax.text(230, 262, '◀ fibres', fontsize=4.4, ha='right', color=OR); ax.text(230, 246, '◀ triax', fontsize=4.4, ha='right')
    ax.text(230, 226, '◀ HV/filament', fontsize=4.4, ha='right'); ax.text(230, 210, '◀ ESV head', fontsize=4.4, ha='right')
    for b_, f in ((o1, 0.5), (o2, 0.5), (o3, 0.5), (o4, 0.5), (o6, 0.5)): pass
    route(ax, [o2.p('B', 0.5), (322, 244), (318, 244)], kind='data', arrow=False) if False else None
    route(ax, [o5.p('B', 0.5), o7.p('T', 0.5)], kind='data', both=True)
    route(ax, [o2.p('L', 0.2), (291, 253.2), (291, 196), o7.p('L', 0.5)], kind='data') if False else route(ax, [o3.p('B', 0.5), (381, 196), o7.p('R', 0.5)], kind='data')
    route(ax, [o2.p('B', 0.25), (308, 244), (291, 244), (291, 196), o7.p('L', 0.5)], kind='data')
    sig_legend(ax, 232, 180, ['optical', 'signal', 'data', 'mech'], cols=2, colw=64)

    label(ax, 24, 180, 'PREDICTED F–Q AND DISCHARGE (III.8)', f'F = c Q², Q₀ = 1.41×10⁻⁸ C ({NUM["e_count"]:.2g} e), c = 2.26×10¹³ N/C²')
    gx, gy, gw, gh = 40, 98, 84, 64
    ax.add_patch(Rectangle((gx, gy), gw, gh, fill=False, lw=0.4))
    qq = np.linspace(0, 1, 100)
    ax.plot(gx + qq * gw, gy + qq ** 2 * gh, color=BL, lw=0.9)
    for f, lab, ty in ((0.3, '30 %: 401 µN', 30), (0.1, '10 %: 44.6 µN', 21), (0.067, '6.7 %: 20 µN (resolution)', 12)):
        p = (gx + f * gw, gy + f * f * gh); ax.plot(*p, 'o', ms=2, color=RD)
        ax.annotate(lab, xy=p, xytext=(gx + 4, gy + ty), fontsize=4.3, color=RD, arrowprops=dict(arrowstyle='-', lw=0.3, color=RD))
    ax.plot(gx + gw, gy + gh, 'o', ms=2.5, color='k'); ax.text(gx + gw - 1, gy + gh - 3, 'claim 4.46 mN\nat Q₀', fontsize=4.4, ha='right', va='top')
    ax.text(gx + gw / 2, gy - 7.5, 'Q / Q₀', fontsize=4.8, ha='center'); ax.text(gx - 4, gy + gh / 2, 'F / 4.46 mN', fontsize=4.8, rotation=90, ha='center', va='center')
    for v in (0, 0.5, 1): ax.text(gx + v * gw, gy - 1.8, f'{v:g}', fontsize=4.3, ha='center', va='top'); ax.text(gx - 1.2, gy + v * gh, f'{v:g}', fontsize=4.3, ha='right', va='center')
    hx, hy, hw, hh = 140, 98, 84, 64
    ax.add_patch(Rectangle((hx, hy), hw, hh, fill=False, lw=0.4))
    tmax = 16.0
    for I, col in ((1, '#1f5fbf'), (10, '#2e7d32'), (100, '#c0392b')):
        td = Q0 / (I * 1e-9); tt = np.linspace(0, min(td, tmax), 200); F = (1 - tt / td) ** 2
        ax.plot(hx + tt / tmax * hw, hy + F * hh, color=col, lw=0.9); ax.text(hx + min(td, tmax) / tmax * hw + 0.8, hy + 2 + (I == 100) * 6 + (I == 10) * 2, f'{I} nA: {td:.2g} s', fontsize=4.3, color=col)
    ax.text(hx + hw / 2, hy - 7.5, 'time (s)', fontsize=4.8, ha='center')
    for v in (0, 4, 8, 12, 16): ax.text(hx + v / tmax * hw, hy - 1.8, f'{v}', fontsize=4.3, ha='center', va='top')
    ax.text(hx + hw - 1, hy + hh - 2, 'F(t) = F₀ (1 − I t / Q₀)²', fontsize=4.6, ha='right', va='top')
    rows = [('STEP', 'ACTION', 'EXPECT IF ELECTROSTATIC'),
            ('1', 'Config A, X1 on: measure F and Q (ESV, collector)', 'F ≈ c Q², sign of F follows geometry'),
            ('2', 'UV discharge at 1, 10, 100 nA; log F(t), Q(t)', 'F falls as (1 − It/Q₀)²; 0 at Q = 0'),
            ('3', 'Re-charge with e-flood or UV2; repeat', 'same F–Q curve (fit c)'),
            ('4', 'Config B: X1 in sealed grounded box, X1 on/off', 'F = 0 within ±1 µN'),
            ('5', 'Float the box, charge to known Q', 'F = c_box Q²: calibrates the method'),
            ('6', 'Reversals: X1 rotated 180°, thrust axis swapped', 'any residual follows the lab, not X1')]
    table(ax, 232, 150, [10, 92, 72], rows, fs=4.6, title='PROCEDURE')
    rows2 = [('VERDICT', ''), ('electrostatic', 'F ∝ Q² and F → 0 as the charge is removed: X1 cut'),
             ('anomalous', 'a force that stays with the charge removed, inside a sealed box, in vacuum, through reversals: send to an outside lab for replication')]
    table(ax, 232, 102, [30, 144], rows2, fs=4.7)
    notes(ax, 24, 84, 204, [
        'The claimed 4.46 mN at 228 µW is 5.7×10⁵ times what ejected ions could give, and equals the pull of 5.6 µC/m² of trapped charge, which relaxes in minutes (polyimide) to days (PTFE).',
        'UV photocurrent from Au at 250 nm is small (quantum yield ~10⁻⁵–10⁻⁴); budget ≈ 1 mW optical per nA-scale current and verify on the collector before the test.',
        'Hold every configuration at constant chamber pressure and temperature; outgassing jets and radiometric forces can mimic µN forces.'], fs=4.8)
    save(fig, 'PTP-502')
print('ok')
