"""T4 · Gap 4 / K4 null test: T4a nN vacuum torsion balance with shielded battery modules; T4b 42 Hz resonant beam detector"""
import math, json, pickle, time
import numpy as np
from ptp import *
t0 = time.time(); NUM = {}

# ======================================================================= numbers
E, rho, L, h, b = 114e9, 4430.0, 1.2, 0.0116, 0.150
NUM['f1_Hz'] = 4.7300 ** 2 / (2 * math.pi * L ** 2) * math.sqrt(E * h ** 2 / (12 * rho))
NUM['beam_kg'] = rho * L * b * h; NUM['node_from_end_mm'] = 0.2242 * L * 1e3
w0 = 2 * math.pi * 42; Q = 1e4
NUM['tau_s'] = Q / (math.pi * 42)
NUM['F_1pm_pN'] = [m * w0 ** 2 * 1e-12 / Q * 1e12 for m in (1, 4)]
NUM['F_thermal_1000s_pN'] = [math.sqrt(4 * 1.38e-23 * 293 * m * w0 / (Q * 1000)) * 1e12 for m in (1, 4)]
# T4a rig (run-2 Pais rig) and image force
eps0 = 8.854e-12; R_d = 0.15; Cdisk = 8 * eps0 * R_d
NUM['C_disk_pF'] = Cdisk * 1e12; NUM['V_kV'] = 1e-6 / Cdisk / 1e3
NUM['field_mass_kg'] = 5.2e-19; NUM['rad_thrust_N'] = 3.7e-16
print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in NUM.items()})

# ======================================================================= T4a CAD (axis Z = balance axis, origin at the pivot)
bl = Rig('T4a_vacuum_balance')
bl.add('CHAMBER', tube(820, 810, 1200, (0, 0, -700)), (0.74, 0.76, 0.80), '304L Ø1640 × 1200')
bl.add('CHAMBER FLOOR', cyl(820, 20, (0, 0, -720)), SS, '304L 20')
bl.add('LID', cyl(840, 25, (0, 0, 500)), SS, '304L lid 25, O-ring')
bl.add('POST', tube(60, 50, 690, (0, 0, -700)), DSTEEL, 'Invar post Ø120')
bl.add('PIVOT', cyl(18, 40, (0, 0, -10)), (0.80, 0.70, 0.35), 'crossed-blade flexure pivot ×2 (C-Flex type)')
bl.add('PIVOT FORK', box(-45, -45, 30, 90, 90, 20), ALU, 'Al hub')
bl.add('ARM', box(-660, -30, 50, 1320, 60, 60).cut(box(-650, -26, 54, 1300, 52, 52)), (0.25, 0.27, 0.30), 'CFRP box beam 60 × 60')
for sx, nm in ((1, 'TEST MODULE'), (-1, 'DUMMY MODULE')):
    cx = sx * 600
    can = tube(260, 259, 520, (cx, 0, -480)).fuse(cyl(260, 1, (cx, 0, -480))).fuse(cyl(260, 1, (cx, 0, 39)))
    bl.add(f'{nm} CAN', can, ALU, 'Al can Ø520 × 520 × 1, grounded to arm (co-moving shield)', 1)
    bl.add(f'{nm} MOUNT', box(cx - 60, -30, 40, 120, 60, 10), ALU, 'Al mount plate')
    if sx > 0:
        bl.add('DISK', cyl(150, 10, (cx, -5, -220), (0, 1, 0)), (0.86, 0.87, 0.90), 'Al disk Ø300 × 10, polished, 94 kV / 1 µC')
        bl.add('PIEZO STACK', cyl(40, 30, (cx, 5, -220), (0, 1, 0)), (0.85, 0.80, 0.55), 'piezo stack, 100 MHz drive')
        bl.add('HV BUSHING', cyl(20, 120, (cx, 35, -220), (0, 1, 0)), (0.95, 0.95, 0.90), 'PTFE / alumina bushing')
        bl.add('ROTARY STAGE', cyl(70, 25, (cx, 0, -460)), (0.35, 0.36, 0.40), '180° stage (battery, fibre-less IR command)')
        bl.add('HV MODULE', box(cx - 90, 150, -440, 180, 90, 110), (0.80, 0.30, 0.25), 'Cockcroft–Walton 100 kV, battery-fed')
        bl.add('BATTERY', box(cx - 100, 140, -150, 200, 100, 80), (0.20, 0.45, 0.25), 'Li-ion 24 V, 10 Ah')
        bl.add('RF + MCU', box(cx - 80, 150, -60, 160, 90, 60), (0.30, 0.32, 0.36), '100 MHz oscillator + 10 W PA, MCU, IR link')
    else:
        bl.add('DUMMY MASS', box(cx - 100, -60, -300, 200, 120, 160), (0.55, 0.45, 0.30), 'brass trim mass (matched)')
bl.add('MIRROR', box(640, -36, 60, 20, 6, 40), GOLD, 'Au mirror on arm end')
bl.add('INTERFEROMETER', box(620, -240, 60, 60, 60, 40), BLACK, 'fibre interferometer head')
bl.add('IFM POST', box(635, -225, -700, 30, 30, 760), DSTEEL, 'post')
bl.add('COMB MOVING', box(-660, 30, 60, 40, 40, 40), (0.85, 0.75, 0.40), 'electrostatic comb (moving)')
bl.add('COMB FIXED', box(-660, 72, 60, 40, 30, 40), (0.55, 0.50, 0.40), 'electrostatic comb (fixed), calibration')
bl.add('DAMPER VANE', box(-700, -3, 40, 40, 6, 80), CU, 'Cu vane')
bl.add('DAMPER MAGNETS', box(-720, -40, 20, 80, 30, 120).cut(box(-721, -30, 19, 82, 20, 122)), (0.40, 0.42, 0.50), 'NdFeB pair on frame (eddy damping)')
bl.add('CAGE', box(-60, -120, 10, 120, 40, 140), (0.65, 0.60, 0.45), 'motorised arm lock (caging)')
bl.add('IR LINK', cyl(25, 60, (300, 790, 200), (0, -1, 0)), (0.40, 0.40, 0.70), 'free-space IR command link at wall')
bl.add('PUMP PORT', tube(80, 75, 200, (0, -820, -400), (0, -1, 0)), SS, 'DN160 to turbo 700 l/s')
bl.add('BASE', box(-1000, -1000, -1020, 2000, 2000, 300), (0.62, 0.62, 0.60), 'seismic block (concrete)')
print('balance parts', len(bl.parts), f'{time.time() - t0:.1f}s')

PJ = {}
inside = bl.compound(exclude=('CHAMBER', 'LID', 'BASE', 'PUMP PORT', 'IR LINK'))
PJ['bal_plan'] = hlr(cq.Compound.makeCompound([inside.wrapped and inside] + [bl.sel(('CHAMBER',))[0]['shape']]) if False else bl.compound(exclude=('LID', 'BASE')), (0, 0, 1), (1, 0, 0), defl=0.6)
SP = []
for p in bl.parts:
    if p['name'].startswith(('BASE',)): continue
    try:
        pol, _ = section_polys(p['shape'], (0, 0, 0), (0, -1, 0), (1, 0, 0), defl=0.4)
        for q in pol: SP.append((p['name'], q))
    except Exception: pass
PJ['bal_sec_polys'] = SP
# beyond-the-plane geometry for the section (y > 0 half), without chamber
half = []
for p in bl.parts:
    if p['name'].startswith(('BASE', 'CHAMBER', 'LID')): continue
    try:
        s = p['shape'].cut(box(-3000, -3000, -3000, 6000, 3000, 6000))
        if s.Volume() > 1e-3: half.append(s)
    except Exception: pass
PJ['bal_sec'] = hlr(cq.Compound.makeCompound(half), (0, -1, 0), (1, 0, 0), defl=0.4)
print('balance views', f'{time.time() - t0:.1f}s')
N, Vx = iso(-60, 28)
cutp = []
for p in bl.parts:
    try:
        s = p['shape'].cut(box(-3000, -3000, -3000, 6000, 3000, 6000)) if p['name'].startswith(('CHAMBER', 'LID', 'TEST MODULE CAN', 'DUMMY MODULE CAN', 'BASE')) else p['shape']
        if p['name'].startswith('LID'): continue
        if s.Volume() > 1e-3: cutp.append(dict(p, shape=s))
    except Exception: pass
render(cutp, N, Vx, size=1500, zoom=1.0).save(f'{OUT}/renders/T4a_balance_cutaway.png')

# ======================================================================= T4b CAD (beam along X, vibrating in Z)
dt = Rig('T4b_resonant_detector')
Lmm, hmm_, bmm = 1200.0, 11.6, 150.0
dt.add('BEAM', cbox(0, 0, 0, Lmm, bmm, hmm_), TI, 'Ti-6Al-4V 1200 × 150 × 11.6')
xn = Lmm / 2 - NUM['node_from_end_mm']
for sx in (-1, 1):
    dt.add(f'NODE SUPPORT {sx:+d}', cbox(sx * xn, 0, -25, 8, 170, 38), (0.55, 0.57, 0.62), 'knife-edge / wire loop at nodal line')
    dt.add(f'SUPPORT POST {sx:+d}', cbox(sx * xn, 0, -150, 60, 200, 212), DSTEEL, 'post on isolation stack')
dt.add('STACK PLATE', cbox(0, 0, -270, 1400, 300, 30), DSTEEL, 'top of 3-stage passive isolation stack')
for k in range(3): dt.add(f'STACK LAYER {k + 1}', cbox(0, 0, -305 - 45 * k, 1300 - 60 * k, 280, 20 if k % 2 else 30), (0.30, 0.30, 0.32) if k % 2 == 0 else DSTEEL, 'viton / steel layers')
dt.add('VACUUM TUBE', tube(300, 292, 1700, (-850, 0, -150), (1, 0, 0)), (0.74, 0.76, 0.80), 'chamber Ø600 × 1700')
for sx in (-1, 1): dt.add(f'END FLANGE {sx:+d}', cyl(330, 25, (sx * 850 if sx > 0 else -875, 0, -150), (1, 0, 0)), SS, 'end flange')
dt.add('IFM HEAD', cyl(15, 60, (0, 0, 70), (0, 0, -1)), BLACK, 'interferometer over beam centre (antinode)')
dt.add('IFM BRACKET', box(-20, -20, 70, 40, 40, 40), DSTEEL, 'bracket from chamber')
dt.add('SOURCE SHIELD', cbox(0, 520, -150, 500, 300, 300), (0.55, 0.60, 0.70), 'Cu + mu-metal shield box (separate support)')
dt.add('SOURCE', cyl(80, 200, (-100, 520, -150), (1, 0, 0)), (0.85, 0.55, 0.25), 'EM source: capacitor/coil set, drive 21 Hz')
dt.add('SOURCE ACCEL', box(-30, 640, -40, 30, 30, 20), BLACK, 'accelerometers on source (×3 axes)')
dt.add('SOURCE STAND', cbox(0, 520, -480, 300, 260, 360), (0.62, 0.62, 0.60), 'separate stand on its own foundation')
print('detector parts', len(dt.parts), f'{time.time() - t0:.1f}s')
PJ['det_side'] = hlr(dt.compound(exclude=('VACUUM TUBE', 'END FLANGE')), (0, -1, 0), (1, 0, 0), defl=0.4)
PJ['det_plan'] = hlr(dt.compound(exclude=('VACUUM TUBE', 'END FLANGE', 'IFM')), (0, 0, 1), (1, 0, 0), defl=0.4)
SPd = []
for p in dt.parts:
    try:
        pol, _ = section_polys(p['shape'], (0, 0, 0), (1, 0, 0), (0, 1, 0), defl=0.3)
        for q in pol: SPd.append((p['name'], q))
    except Exception: pass
PJ['det_cross_polys'] = SPd
N2, Vx2 = iso(-55, 25)
cutd = []
for p in dt.parts:
    try:
        s = p['shape'].cut(box(-3000, -3000, -150, 6000, 3000, 3000)) if p['name'].startswith(('VACUUM', 'END')) else p['shape']
        if p['name'].startswith('SOURCE SHIELD'): s = p['shape'].cut(box(-3000, 300, -150, 6000, 3000, 3000))
        if s.Volume() > 1e-3: cutd.append(dict(p, shape=s))
    except Exception: pass
render(cutd, N2, Vx2, size=1500, zoom=1.0).save(f'{OUT}/renders/T4b_detector_cutaway.png')
print(bl.step(), dt.step())
write_dxf('T4a_balance', [('PLAN', *PJ['bal_plan'], None, (0, 0)), ('SECTION y=0', *PJ['bal_sec'], [q for _, q in SP], (0, 2000))])
write_dxf('T4b_detector', [('SIDE', *PJ['det_side'], None, (0, 0)), ('PLAN', *PJ['det_plan'], None, (0, 1200)), ('CROSS SECTION x=0', [], [], [q for _, q in SPd], (2000, 0))])
pickle.dump(dict(PJ=PJ, NUM=NUM, bparts=[(p['name'], p['mat']) for p in bl.parts], dparts=[(p['name'], p['mat']) for p in dt.parts]), open(f'{OUT}/t4.pkl', 'wb'))
json.dump(NUM, open(f'{OUT}/t4_numbers.json', 'w'), indent=1)
print('done', f'{time.time() - t0:.1f}s')
