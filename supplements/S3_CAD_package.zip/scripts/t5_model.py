"""T5 · X1 (Exodus) with UV charge control on a µN vacuum torsion balance - numbers, CAD, projections, renders"""
import math, json, pickle, time
import numpy as np
from ptp import *
t0 = time.time(); NUM = {}
Q0, c = 1.41e-8, 2.26e13
NUM.update(Q0=Q0, c=c, F0_mN=c * Q0 ** 2 * 1e3, e_count=Q0 / 1.602e-19)
NUM['t_dis_s'] = {I: Q0 / (I * 1e-9) for I in (1, 10, 100)}
NUM['F_frac_uN'] = {f: c * (f * Q0) ** 2 * 1e6 for f in (0.30, 0.10, 0.067, 0.01)}
NUM['frac_20uN'] = math.sqrt(20e-6 / (c * Q0 ** 2))
NUM['photon_eV_254'] = 1239.84 / 254
# balance numbers: W suspension alternative vs flexure + feedback
print({k: v for k, v in NUM.items()})

xb = Rig('T5_X1_balance')
xb.add('CHAMBER', tube(455, 445, 700, (0, 0, -400)), (0.74, 0.76, 0.80), '304L Ø900 × 700')
xb.add('FLOOR', cyl(455, 15, (0, 0, -415)), SS, '304L 15')
xb.add('LID', cyl(470, 20, (0, 0, 300)), SS, 'lid with feedthroughs')
xb.add('POST', tube(40, 32, 390, (0, 0, -400)), DSTEEL, 'Invar post Ø80')
xb.add('PIVOT', cyl(14, 30, (0, 0, -10)), (0.80, 0.70, 0.35), 'flexure pivots (C-Flex type), conductive to ground')
xb.add('ARM', box(-380, -20, 20, 760, 40, 40).cut(box(-370, -17, 23, 740, 34, 34)), (0.25, 0.27, 0.30), 'CFRP box beam 40 × 40')
# sealed box with X1 (+x end)
bx = box(250, -75, -130, 200, 150, 100).cut(box(253, -72, -127, 194, 144, 94))
xb.add('BOX', bx, ALU, 'Al box 200 × 150 × 100, 3 wall, sealed, conductive gasket')
xb.add('BOX LID', box(250, -75, -30, 200, 150, 3).translate(V(0, 0, 0)) if False else box(248, -77, -30, 204, 154, 3), (0.70, 0.72, 0.76), 'lid, conductive gasket')
xb.add('BOX HANGER', box(330, -15, -27, 40, 30, 47), ALU, 'hanger to arm')
xb.add('X1 DEVICE', box(300, -30, -115, 100, 60, 40), (0.85, 0.55, 0.25), 'X1 thruster (claimed 4.46 mN at 228 µW)')
xb.add('X1 BATTERY', box(410, -25, -120, 30, 50, 15), (0.20, 0.45, 0.25), 'cell + driver, IR-commanded')
xb.add('SENSE PATCH', box(450, -30, -110, 1, 60, 60), GOLD, 'Au sense patch on box face (+x)')
xb.add('GROUND SWITCH', box(350, 18, 20, 20, 15, 12), BLACK, 'vacuum reed relay: box to arm ground / float')
# counter end (-x): counterweight + moving magnet of the voice-coil
xb.add('COUNTERWEIGHT', box(-360, -40, -80, 80, 80, 90), (0.55, 0.45, 0.30), 'brass, trimmed')
xb.add('VC MAGNET', cyl(15, 30, (-380, 0, 40), (-1, 0, 0)), (0.40, 0.42, 0.50), 'NdFeB moving magnet (on arm)')
xb.add('VC COIL', tube(30, 20, 40, (-420, 0, 40), (-1, 0, 0)), CU, 'feedback coil on frame, ±10 mN')
xb.add('VC BRACKET', box(-470, -30, -400, 30, 60, 470), DSTEEL, 'coil bracket')
xb.add('CAP SENSOR', box(380, 25, 25, 20, 10, 30), (0.30, 0.30, 0.55), 'capacitive / fibre displacement sensor')
xb.add('SENSOR POST', box(380, 35, -400, 20, 20, 440), DSTEEL, 'post')
# charge control and measurement around the box
def aim(p, tgt, L=60, r=8, name='', col=BLACK, mat=''):
    d = unit(np.array(tgt) - np.array(p)); xb.add(name, cyl(r, L, tuple(np.array(p) - d * L), tuple(d)), col, mat)
aim((520, -160, -80), (450, -40, -80), 50, 9, 'UV1 COLLIMATOR', (0.45, 0.35, 0.75), '250 nm LED via fibre → box / X1 surfaces, grounded mesh')
aim((520, 160, -80), (470, 80, -80), 50, 9, 'UV2 COLLIMATOR', (0.45, 0.35, 0.75), '250 nm LED via fibre → collector (charges box −)')
xb.add('COLLECTOR', box(468, 40, -125, 3, 90, 90), GOLD, 'Au collector electrode → electrometer')
aim((300, -330, -80), (350, -75, -80), 120, 22, 'E FLOOD GUN', (0.35, 0.36, 0.40), 'electron flood gun 1–100 eV, µA')
xb.add('ESV PROBE', box(453, -20, -95, 30, 40, 30), (0.20, 0.20, 0.22), 'non-contact ESV probe, 3 mm gap')
xb.add('ESV POST', box(470, -10, -400, 15, 20, 305), DSTEEL, 'post')
xb.add('FIBRE FT', cyl(20, 40, (0, -455, 150), (0, -1, 0)), (0.40, 0.40, 0.70), 'UV fibre feedthrough (solarisation-resistant)')
xb.add('PUMP PORT', tube(52, 49, 160, (-200, -455, -250), (0, -1, 0)), SS, 'CF100 to turbo 300 l/s')
print('parts', len(xb.parts), f'{time.time() - t0:.1f}s')
PJ = {}
SP = []
for p in xb.parts:
    try:
        pol, _ = section_polys(p['shape'], (0, 0, 0), (0, -1, 0), (1, 0, 0), defl=0.3)
        for q in pol: SP.append((p['name'], q))
    except Exception: pass
PJ['sec_polys'] = SP
half = []
for p in xb.parts:
    if p['name'].startswith(('CHAMBER', 'LID', 'FLOOR')): continue
    try:
        s = p['shape'].cut(box(-3000, -3000, -3000, 6000, 3000, 6000))
        if s.Volume() > 1e-3: half.append(s)
    except Exception: pass
PJ['sec'] = hlr(cq.Compound.makeCompound(half), (0, -1, 0), (1, 0, 0), defl=0.3)
PJ['plan'] = hlr(xb.compound(exclude=('LID',)), (0, 0, 1), (1, 0, 0), defl=0.3)
boxparts = [p for p in xb.parts if p['name'].startswith(('BOX', 'X1', 'SENSE', 'GROUND', 'UV', 'COLLECTOR', 'E FLOOD', 'ESV PROBE'))]
PJ['box_plan'] = hlr(cq.Compound.makeCompound([p['shape'] for p in boxparts if not p['name'].startswith('BOX LID')]), (0, 0, 1), (1, 0, 0), defl=0.1)
print('views', f'{time.time() - t0:.1f}s')
cutp = []
for p in xb.parts:
    if p['name'].startswith('LID'): continue
    try:
        s = p['shape'].cut(box(-3000, -3000, -3000, 6000, 3000, 6000)) if p['name'].startswith(('CHAMBER', 'FLOOR')) else p['shape']
        if p['name'].startswith('BOX LID'): continue
        if s.Volume() > 1e-3: cutp.append(dict(p, shape=s))
    except Exception: pass
render(cutp, *iso(-65, 30), size=1500, zoom=1.0, opacity={'BOX': 0.45}).save(f'{OUT}/renders/T5_balance_cutaway.png')
render(boxparts, *iso(-40, 35), size=1100, zoom=1.0, opacity={'BOX': 0.35, 'BOX LID': 0.3}).save(f'{OUT}/renders/T5_box_iso.png')
print(xb.step())
write_dxf('T5_X1_balance', [('SECTION y=0', *PJ['sec'], [q for _, q in SP], (0, 0)), ('PLAN', *PJ['plan'], None, (0, 1200))])
pickle.dump(dict(PJ=PJ, NUM=NUM, parts=[(p['name'], p['mat']) for p in xb.parts]), open(f'{OUT}/t5.pkl', 'wb'))
json.dump(NUM, open(f'{OUT}/t5_numbers.json', 'w'), indent=1, default=str)
print('done', f'{time.time() - t0:.1f}s')
