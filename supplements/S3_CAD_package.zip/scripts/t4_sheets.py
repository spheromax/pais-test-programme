"""T4 sheets PTP-401..403 (reads out/t4.pkl)"""
import pickle, math, sys
import numpy as np
from PIL import Image
from ptp import *
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'
D = pickle.load(open(f'{OUT}/t4.pkl', 'rb')); PJ, NUM = D['PJ'], D['NUM']
TT = 'TEST T4 · GAP 4 / K4 NULL TEST · III.3, III.9'
ONLY = sys.argv[1:]
cols = {'CHAMBER': ('#c9ccd2', '////'), 'LID': ('#c9ccd2', '////'), 'POST': ('#9aa0a8', '////'), 'PIVOT': ('#e0c070', ''), 'ARM': ('#41444a', ''),
        'TEST MODULE CAN': ('#d9dde3', ''), 'DUMMY MODULE CAN': ('#d9dde3', ''), 'DISK': ('#f0f0f4', '////'), 'PIEZO': ('#e6d38a', ''), 'HV': ('#d9776a', ''),
        'BATTERY': ('#7fb38c', ''), 'RF': ('#555a62', ''), 'ROTARY': ('#5a5d64', ''), 'DUMMY MASS': ('#c9a46a', ''), 'MIRROR': ('#e6b84a', ''), 'INTERF': ('#333333', ''),
        'IFM': ('#9aa0a8', ''), 'COMB': ('#d5bf7a', ''), 'DAMPER': ('#d58b52', ''), 'CAGE': ('#b8ab86', ''), 'PUMP': ('#c9ccd2', ''), 'MOUNT': ('#cfd3d8', ''),
        'BEAM': ('#b4b6c0', '////'), 'NODE': ('#8a8f99', ''), 'SUPPORT': ('#9aa0a8', '////'), 'STACK': ('#7a7d84', ''), 'VACUUM': ('#c9ccd2', '////'),
        'END': ('#c9ccd2', ''), 'SOURCE SHIELD': ('#b9c3d6', '\\\\\\\\'), 'SOURCE STAND': ('#bdbdb8', ''), 'SOURCE ACCEL': ('#333333', ''), 'SOURCE': ('#d58b52', ''), 'PIVOT FORK': ('#cfd3d8', '')}
def dsect(ax, polys, den, mc, c, clip=None, lw=0.35):
    k = 1.0 / den; cp = Rectangle((clip[0], clip[1]), clip[2] - clip[0], clip[3] - clip[1], transform=ax.transData) if clip else None
    for name, (outer, holes) in polys:
        fc, h = next((v for kk, v in sorted(cols.items(), key=lambda kv: -len(kv[0])) if name.startswith(kk)), ('#dddddd', ''))
        verts, codes = [], []
        for w in [outer] + holes:
            q = c + (np.asarray(w) - mc) * k; verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
        pa = ax.add_patch(PathPatch(Path(verts, codes), facecolor=fc, edgecolor='k', lw=lw, hatch=h))
        if cp is not None: pa.set_clip_path(cp)
    return lambda u, v: c + (np.array([u, v]) - mc) * k

# =====================================================================================  PTP-401
if not ONLY or '401' in ONLY:
    fig, ax = sheet('T4a · nN VACUUM TORSION BALANCE WITH SHIELDED RIG · GA', 'PTP-401', 14, '1:20', TT)
    label(ax, 24, 279, 'SECTION A–A  1:20', 'vertical plane through the arm (y = 0), from −y; items beyond shown')
    vS = View(ax, PJ['bal_sec'], 20, 0, 0); vS.mc = np.array([0.0, -250.0]); vS.c = np.array([74.0, 222.0]); vS.draw(hidden=False, lw=0.3)
    PA = dsect(ax, PJ['bal_sec_polys'], 20, np.array([0.0, -250.0]), np.array([74.0, 222.0]))
    leader(ax, PA(600, -220), (118, 268), 'test module: Ø300 disk, 94 kV,\n±80 nm at 100 MHz, in Ø520 can', fs=4.4, ha='right') if False else leader(ax, PA(600, -220), (104, 268), 'test module (disk in can)', fs=4.5)
    leader(ax, PA(-600, -220), (26, 268), 'dummy module', fs=4.5)
    leader(ax, PA(0, 0), (70, 266), 'flexure pivot', fs=4.5)
    leader(ax, PA(0, -400), (42, 178), 'Invar post', fs=4.5)
    leader(ax, PA(640, 80), (114, 252), 'mirror + interferometer', fs=4.5) if False else None
    dim(ax, PA(-820, -720), PA(820, -720), -5, 'Ø1 640', fs=4.5, mode='h')
    dim(ax, PA(-600, -480), PA(600, -480), -3, '1 200 module centres', fs=4.5, mode='h') if False else dim(ax, PA(-600, 60), PA(600, 60), 14, '1 200 between module centres', fs=4.5, mode='h')
    label(ax, 130, 279, 'PLAN  1:20', 'lid removed')
    vP = View(ax, PJ['bal_plan'], 20, 0, 0); vP.mc = np.array([0.0, 0.0]); vP.c = np.array([180.0, 226.0]); vP.draw(hidden=False, lw=0.3)
    leader(ax, vP.P(650, -240), (222, 270), 'interferometer → mirror', fs=4.5, ha='right')
    leader(ax, vP.P(-680, 90), (136, 270), 'comb calibrator', fs=4.5)
    leader(ax, vP.P(-700, -25), (136, 186), 'eddy damper', fs=4.5)
    leader(ax, vP.P(300, 790), (226, 186), 'IR command link', fs=4.5, ha='right') if False else leader(ax, vP.P(300, 790), (214, 274), 'IR link', fs=4.5)
    leader(ax, vP.P(0, -900), (166, 184), 'DN160 to turbo', fs=4.5)
    ax.annotate('', xy=vP.P(600, 380), xytext=vP.P(600, 120), arrowprops=dict(arrowstyle='<|-|>', lw=0.6, color=BL, mutation_scale=5)); ax.text(*(vP.P(640, 250)), 'F (±y)', fontsize=4.6, color=BL)
    put_image(ax, Image.open(f'{OUT}/renders/T4a_balance_cutaway.png'), 232, 182, 174, 96, title='CUTAWAY · chamber and cans half removed')
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'NOTE'),
            ('1', '1', 'Vacuum chamber Ø1640 × 1200, lid, DN160 to turbo 700 l/s', '≤ 1e-6 mbar'),
            ('2', '1', 'Invar post + crossed-blade flexure pivots', 'torsion axis z'),
            ('3', '1', 'CFRP arm 60 × 60, 1.32 m', 'module centres ±600'),
            ('4', '2', 'Co-moving shield cans Ø520 × 520 × 1 Al, grounded to arm', 'image forces internal'),
            ('5', '1', 'Disk Ø300 × 10 Al on piezo stack + PTFE/alumina bushing', f"C = {NUM['C_disk_pF']:.1f} pF"),
            ('6', '1', 'Battery 24 V; Cockcroft–Walton 100 kV; 100 MHz osc. + PA; MCU', 'inside can 4'),
            ('7', '1', '180° rotary stage inside the can (IR-commanded)', 'reversal by rotation'),
            ('8', '1', 'Dummy module: same can + matched brass mass', 'symmetry'),
            ('9', '1', 'Fibre interferometer + Au mirror on arm end', '≤ 1 nm, ~pm/√Hz'),
            ('10', '1', 'Electrostatic comb calibrator (nN–µN)', 'F = ½ (dC/dx) V²'),
            ('11', '1', 'Eddy-current damper (Cu vane, NdFeB on frame)', '0.6 m from rig'),
            ('12', '1', 'Motorised caging lock; tiltmeters; fluxgate; thermometers', 'monitors'),
            ('13', '1', 'Free-space IR command link (no cables to the arm)', '—'),
            ('14', '1', 'Seismic block', '—')]
    table(ax, 232, 176, [8, 8, 116, 42], rows, fs=4.5, title='PARTS')
    rows2 = [('RUN', 'WHAT CHANGES', 'WHAT IT TESTS'),
             ('0 baseline', 'dummy only, rig off', 'noise floor (target ≤ 1 nN, 100 s)'),
             ('1 charged', '+94 kV steady (1 µC)', 'steady-field coupling'),
             ('2 reversed', '−94 kV', 'force odd in field sign'),
             ('3 rotated', 'module 180° in vacuum', 'force fixed to the device, not the lab'),
             ('4 vibrated', '±80 nm at 100 MHz on/off', 'Pais high-frequency claim'),
             ('5 spin only', 'spin, no charge', 'mechanical/thermal artefacts'),
             ('6 discharged', '0 V, vibration on', 'vibration artefacts'),
             ('repeat', '≥ 10 cycles, randomised order', 'drift separation')]
    table(ax, 24, 172, [30, 64, 110], rows2, fs=4.7, title='PROTOCOL (III.3)')
    rows3 = [('QUANTITY', 'VALUE'),
             ('disk charge, potential', f"1 µC at {NUM['V_kV']:.0f} kV (C = 8ε₀R = {NUM['C_disk_pF']:.1f} pF)"),
             ('image pull per face (open rig)', '0.050 N: face symmetry must beat 2×10⁻⁶ for < 0.1 µN'),
             ('with the co-moving can', 'image forces act inside one rigid body and cancel'),
             ('known-physics prediction', 'field mass +5.2×10⁻¹⁹ kg; radiated thrust ≤ 3.7×10⁻¹⁶ N'),
             ('prior result', 'TU Dresden: no coupling at ≈ 1 nN with steady fields')]
    table(ax, 24, 108, [56, 148], rows3, fs=4.7, title='NUMBERS')
    notes(ax, 24, 62, 204, ['No wires cross the pivot: power, HV and RF are on the arm; commands by IR link; data only from the interferometer.',
                            'Demonstrate the noise floor with both dummy cans before installing the rig.'], fs=4.8)
    save(fig, 'PTP-401')

# =====================================================================================  PTP-402
if not ONLY or '402' in ONLY:
    fig, ax = sheet('T4b · 42 Hz RESONANT BEAM DETECTOR WITH SHIELDED EM SOURCE · GA', 'PTP-402', 15, '1:10', TT)
    label(ax, 24, 279, 'SIDE VIEW  1:10', 'from −y; chamber phantom; source behind (y +520)')
    vS = View(ax, PJ['det_side'], 10, 0, 0); vS.mc = np.array([0.0, -200.0]); vS.c = np.array([110.0, 234.0]); vS.draw(hidden=False, lw=0.35)
    for zz in (-450, 150):
        p, q = vS.P(-850, zz), vS.P(850, zz); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.5', lw=0.35, ls=(0, (6, 2, 1, 2)))
    for xx in (-850, 850):
        p, q = vS.P(xx, -450), vS.P(xx, 150); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.5', lw=0.35, ls=(0, (6, 2, 1, 2)))
    xn = 600 - NUM['node_from_end_mm']
    dim(ax, vS.P(-600, 5.8), vS.P(600, 5.8), 9, '1 200 beam', fs=4.5, mode='h')
    dim(ax, vS.P(-xn, -60), vS.P(xn, -60), -14, f'{2 * xn:.0f} between nodal supports', fs=4.5, mode='h')
    leader(ax, vS.P(0, 80), (130, 274), 'interferometer at antinode', fs=4.5)
    leader(ax, vS.P(-500, -270), (40, 196), 'isolation stack (3 stages)', fs=4.5)
    ax.text(*(vS.P(-840, 120) + (0.5, -2)), 'vacuum chamber Ø600 × 1700 (phantom)', fontsize=4.4, color='0.4')
    label(ax, 24, 186, 'MODE SHAPE (free–free, mode 1)', f"f₁ = {NUM['f1_Hz']:.1f} Hz · nodes at 0.224 L = {NUM['node_from_end_mm']:.0f} mm from each end")
    gx, gy, gw, gh = 34, 150, 180, 26
    xs = np.linspace(0, 1, 300); bl_ = 4.7300; sg = (math.cosh(bl_) - math.cos(bl_)) / (math.sinh(bl_) - math.sin(bl_))
    ph = np.cosh(bl_ * xs) + np.cos(bl_ * xs) - sg * (np.sinh(bl_ * xs) + np.sin(bl_ * xs)); ph = ph / np.abs(ph).max()
    ax.plot([gx, gx + gw], [gy, gy], color='k', lw=0.3, ls=(0, (8, 2, 2, 2)))
    ax.plot(gx + xs * gw, gy + ph * gh / 2, color=BL, lw=0.9)
    for xnode in (0.2242, 0.7758): ax.plot(gx + xnode * gw, gy, 'o', ms=2.5, color=RD); ax.text(gx + xnode * gw, gy - 3.5, 'node', fontsize=4.4, ha='center', color=RD)
    ax.text(gx + gw / 2, gy + gh / 2 + 2, 'antinode: interferometer', fontsize=4.4, ha='center', color=BL)
    label(ax, 24, 132, 'PLAN  1:10', 'beam, supports and the source box beside the chamber')
    vP = View(ax, PJ['det_plan'], 10, 0, 0); vP.mc = np.array([0.0, 260.0]); vP.c = np.array([120.0, 88.0]); vP.draw(hidden=False, lw=0.35)
    for yy in (-300, 300):
        p, q = vP.P(-850, yy), vP.P(850, yy); ax.plot([p[0], q[0]], [p[1], q[1]], color='0.5', lw=0.35, ls=(0, (6, 2, 1, 2)))
    dim(ax, vP.P(250, 75), vP.P(250, 370), 6, '≈ 300 beam edge to shield face', fs=4.4, mode='v')
    leader(ax, vP.P(-100, 520), (40, 124), 'EM source in Cu + mu-metal box,\non its own stand and foundation', fs=4.5)
    leader(ax, vP.P(-15, 655), (190, 126), 'source accelerometers', fs=4.5)
    label(ax, 232, 279, 'CROSS SECTION x = 0  1:10', None)
    PX = dsect(ax, PJ['det_cross_polys'], 10, np.array([260.0, -250.0]), np.array([282.0, 232.0]))
    leader(ax, PX(0, 0), (240, 270), 'beam 150 × 11.6', fs=4.5)
    leader(ax, PX(520, -150), (318, 270), 'source + shield', fs=4.5, ha='right')
    put_image(ax, Image.open(f'{OUT}/renders/T4b_detector_cutaway.png'), 334, 196, 72, 80, title='CUTAWAY')
    rows = [('QUANTITY', 'VALUE'),
            ('beam', f"Ti-6Al-4V 1200 × 150 × 11.6, {NUM['beam_kg']:.2f} kg, f₁ {NUM['f1_Hz']:.1f} Hz"),
            ('Q, ring-down', f"≈ 10⁴; τ = Q/(πf) = {NUM['tau_s']:.0f} s"),
            ('readout floor 1 pm → force', f"F = m ω² x / Q = {NUM['F_1pm_pN'][0]:.0f}–{NUM['F_1pm_pN'][1]:.0f} pN (m_eff 1–4 kg)"),
            ('thermal floor, 1000 s', f"{NUM['F_thermal_1000s_pN'][0]:.1f}–{NUM['F_thermal_1000s_pN'][1]:.1f} pN: readout-limited"),
            ('vs nN balance', '36–140× finer'),
            ('source drive', '21 Hz, so the field energy (∝ E², B²) oscillates at 42 Hz; linear coupling stays off resonance'),
            ('systematics', 'source vibration at 42 Hz from Maxwell stress; its Newtonian signal is computed from the measured motion and subtracted'),
            ('precedent', 'ETH: dynamic gravity measured to ≈ 3 % of theory with this detector class')]
    table(ax, 232, 190, [46, 128], rows, fs=4.5, title='NUMBERS (estimates)')
    rows2 = [('ITEM', 'QTY', 'DESCRIPTION'),
             ('1', '1', 'Ti-6Al-4V beam 1200 × 150 × 11.6, stress-relieved, polished centre'),
             ('2', '2', 'nodal supports (knife edge or wire loop) on posts'),
             ('3', '1', '3-stage passive isolation stack, steel + viton'),
             ('4', '1', 'vacuum chamber Ø600 × 1700, ≤ 1e-5 mbar (gas damping)'),
             ('5', '1', 'fibre interferometer at the antinode, ~1 pm'),
             ('6', '1', 'EM source (capacitor/coil set) in Cu + mu-metal box'),
             ('7', '3', 'source accelerometers + 1 interferometer on the source'),
             ('8', '1', 'separate stand and foundation for the source')]
    table(ax, 232, 128, [8, 8, 158], rows2, fs=4.5, title='PARTS')
    notes(ax, 232, 75, 174, ['Swap ETH’s moving-mass transmitter for the shielded EM source; keep the detector unchanged so its calibration (dynamic Newtonian gravity) still holds.',
                            'A real effect must lock to the 42 Hz field-energy phase, scale as the drive squared, and survive shield changes.'], fs=4.5, title=None)
    save(fig, 'PTP-402')

# =====================================================================================  PTP-403
if not ONLY or '403' in ONLY:
    fig, ax = sheet('T4 · RIG, BALANCE AND DETECTOR · SCHEMATICS', 'PTP-403', 16, 'NTS', TT)
    label(ax, 24, 281, 'A · ON-ARM TEST MODULE (inside the grounded can)', 'battery powered; no conductors cross the pivot')
    ax.add_patch(Rectangle((24, 196), 204, 74, fill=False, lw=0.7, ls=(0, (5, 2)))); ax.text(26, 266.5, 'CO-MOVING SHIELD (can, item 4)', fontsize=4.6, weight='bold')
    m1 = blk(ax, 30, 238, 34, 22, 'BATTERY', ['Li-ion 24 V', '10 Ah'])
    m2 = blk(ax, 72, 238, 40, 22, 'HV CONVERTER', ['DC-DC + Cockcroft–', 'Walton, 0–±100 kV'], fc='#fdecea')
    m3 = blk(ax, 120, 238, 34, 22, 'DISK Ø300', ['C 10.6 pF', '1 µC at 94 kV'], fc='#f1f2f6')
    m4 = blk(ax, 162, 238, 60, 22, 'HV DIVIDER + ADC', ['1000:1, monitors V(t)', 'and leakage current'])
    m5 = blk(ax, 72, 204, 40, 24, 'RF OSC. + PA', ['100 MHz, 10 W', 'drives piezo stack'])
    m6 = blk(ax, 120, 204, 34, 24, 'PIEZO STACK', ['±80 nm', 'at 100 MHz'])
    m7 = blk(ax, 30, 204, 34, 24, 'MCU', ['sequencer, logs', 'T, V, I, state'], fc='#eaf1fb')
    m8 = blk(ax, 162, 204, 60, 24, 'IR LINK RX/TX + STAGE', ['commands in, status out', '180° stage, spin motor (opt.)'])
    for a_, b_ in ((m1, m2), (m2, m3)): route(ax, [a_.p('R'), b_.p('L')], kind='power')
    route(ax, [m3.p('R'), m4.p('L')], kind='signal'); route(ax, [m5.p('R'), m6.p('L')], kind='rf')
    route(ax, [m1.p('B'), (47, 232), (92, 232), m5.p('T')], kind='power'); route(ax, [m6.p('T'), m3.p('B')], kind='mech')
    route(ax, [m7.p('R', 0.7), (68, 220.8), (68, 252), m2.p('L', 0.6)], kind='data', arrow=True) if False else route(ax, [m7.p('R', 0.8), (70, 223.2), (70, 220), m5.p('L', 0.65)], kind='data')
    route(ax, [m8.p('B', 0.5), (192, 200), (47, 200), m7.p('B')], kind='data', both=True)
    route(ax, [m4.p('B', 0.3), (180, 232), (160, 232), (160, 228)], kind='data', arrow=False) if False else None
    label(ax, 232, 281, 'B · BALANCE READOUT AND CONTROL (outside)', None)
    o1 = blk(ax, 232, 244, 54, 24, 'INTERFEROMETER', ['fibre head at arm end', 'pm/√Hz, 10 kHz'])
    o2 = blk(ax, 292, 244, 54, 24, 'COMB HV SUPPLY', ['0–1 kV, 20 bit', 'calibration force'])
    o3 = blk(ax, 352, 244, 54, 24, 'IR LINK TX/RX', ['window in chamber', 'commands/status'])
    o4 = blk(ax, 232, 212, 54, 24, 'ENVIRONMENT', ['2 tiltmeters, fluxgate,', '8 thermometers, gauge'])
    o5 = blk(ax, 292, 212, 54, 24, 'DAQ + PC', ['24 bit, 1 kHz', 'protocol scheduler'], fc='#eaf1fb')
    o6 = blk(ax, 352, 212, 54, 24, 'CAGING + VACUUM', ['motor lock', 'turbo, gauges'])
    route(ax, [o1.p('B', 0.5), (259, 240), (305, 240), o5.p('T', 0.25)], kind='signal'); route(ax, [o2.p('B', 0.6), o5.p('T', 0.6)], kind='signal') if False else route(ax, [o5.p('T', 0.6), o2.p('B', 0.6)], kind='signal')
    route(ax, [o3.p('B', 0.4), (373.6, 240), (335, 240), o5.p('T', 0.85)], kind='data', both=True); route(ax, [o4.p('R'), o5.p('L')], kind='signal'); route(ax, [o5.p('R'), o6.p('L')], kind='data')
    ax.text(232, 205, 'Force from the interferometer: F = κ θ / r_arm, κ from comb calibration before and after each run.', fontsize=4.6)
    label(ax, 24, 186, 'C · T4b DRIVE AND LOCK-IN', '2f detection: the effect, if any, sits at 42 Hz; linear crosstalk at 21 Hz')
    d1 = blk(ax, 24, 146, 40, 28, 'SIGNAL GENERATOR', ['21.000 Hz', 'ref out'])
    d2 = blk(ax, 70, 146, 40, 28, 'POWER AMPLIFIER', ['to source', 'V or I monitor'])
    d3 = blk(ax, 116, 146, 46, 28, 'EM SOURCE', ['in shield, own stand', 'accelerometers ×3'], fc='#fff3e3')
    d4 = blk(ax, 168, 146, 60, 28, 'DETECTOR BEAM', ['42 Hz, Q ≈ 10⁴', 'interferometer at antinode'], fc='#f1f2f6')
    d5 = blk(ax, 24, 108, 40, 28, 'FREQUENCY ×2', ['42.000 Hz ref', 'phase locked'])
    d6 = blk(ax, 116, 108, 46, 28, 'LOCK-IN (2 ch)', ['X, Y at 42 Hz', 'τ = 100–1000 s'], fc='#eaf1fb')
    d7 = blk(ax, 168, 108, 60, 28, 'NEWTONIAN MODEL', ['from measured source motion', 'predicted 42 Hz signal'])
    route(ax, [d1.p('R'), d2.p('L')], kind='signal'); route(ax, [d2.p('R'), d3.p('L')], kind='power'); route(ax, [d3.p('R'), d4.p('L')], kind='mech')
    route(ax, [d1.p('B'), d5.p('T')], kind='trigger'); route(ax, [d5.p('R'), d6.p('L')], kind='trigger')
    route(ax, [d4.p('B', 0.3), (186, 140), (150, 140), d6.p('T', 0.73)], kind='signal')
    route(ax, [d3.p('B', 0.2), (125.2, 140), (128, 140), d6.p('T', 0.25)], kind='signal') if False else route(ax, [d3.p('B', 0.25), d6.p('T', 0.25)], kind='signal')
    route(ax, [d6.p('R', 0.5), d7.p('L', 0.5)], kind='data', both=True)
    ax.text(26, 99, 'Result = lock-in X, Y minus the Newtonian prediction and the measured EM crosstalk.', fontsize=4.6)
    sig_legend(ax, 232, 196, ['power', 'signal', 'trigger', 'rf', 'data', 'mech'], cols=3, colw=58)
    rows = [('PASS / FAIL', ''),
            ('new physics', 'a reproducible signal that survives polarity reversal, 180° rotation and shield changes, and exceeds the computed Newtonian and EM crosstalk'),
            ('null', 'bounds the coupling at the instrument floor (≈ 1 nN balance; ≈ 7–28 pN resonant) and closes the Pais premise experimentally'),
            ('known physics', 'field mass +5.2×10⁻¹⁹ kg; radiated thrust ≤ 3.7×10⁻¹⁶ N: nothing measurable expected')]
    table(ax, 232, 170, [30, 144], rows, fs=4.7)
    notes(ax, 232, 118, 174, ['Every run is logged with the module state from the MCU (V, I, RF, stage angle) time-aligned with the interferometer.',
                              'Randomise run order; blind the analysis to state labels until the noise model is frozen.'], fs=4.8)
    save(fig, 'PTP-403')
print('ok')
