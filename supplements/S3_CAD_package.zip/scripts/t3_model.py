"""T3 · B7 K3C60 film in an FEL cavity (FELICE-type intracavity station) - numbers, CAD, projections, renders"""
import math, json, pickle, time
import numpy as np
from ptp import *
t0 = time.time(); NUM = {}

# ============================================================== optics + thermal budget
lam = 30e-3                                   # mm (30 um, 10 THz)
n_d = 2.38; thB = math.degrees(math.atan(n_d)); cB = math.cos(math.radians(thB))
E_micro = 0.400                               # mJ intracavity micropulse (FELICE)
F_hold = 0.4                                  # mJ/cm2
NUM.update(theta_B=thB, cos_B=cB, elong=1 / cB)
cases = []
for F_focus in (53.0, 33.0):                  # mJ/cm2 peak at focus -> waist
    w0 = math.sqrt(2 * E_micro / (math.pi * F_focus)) * 10      # cm -> mm
    zR = math.pi * w0 ** 2 / lam
    w_beam = math.sqrt(2 * E_micro / (math.pi * F_hold)) * 10   # 0.4 mJ/cm2 peak in the beam
    w_film = math.sqrt(2 * E_micro * cB / (math.pi * F_hold)) * 10   # 0.4 mJ/cm2 peak on the tilted film
    z = lambda w: zR * math.sqrt((w / w0) ** 2 - 1)
    cases.append(dict(F_focus=F_focus, w0=w0, zR=zR, w_beam=w_beam, z_beam=z(w_beam), w_film=w_film, z_film=z(w_film)))
NUM['cases'] = cases
wf = cases[0]['w_film']; NUM['footprint_mm'] = (2 * wf / cB, 2 * wf)
# heat per macropulse: 2 passes per ns (forward + return), 8 us, A = 0.1-0.2
passes = 2 * 8e-6 / 1e-9
NUM['passes'] = passes
NUM['E_abs_J'] = [A * E_micro * 1e-3 * passes for A in (0.1, 0.2)]
NUM['P_avg_W'] = [e * 10 for e in NUM['E_abs_J']]
area = math.pi * (wf / 10) * (wf / 10 / cB)                   # cm2 within 1/e2 footprint
mass = area * 0.05 * 3.51                                      # g, 0.5 mm diamond column
NUM['footprint_cm2'] = area; NUM['column_g'] = mass
def T_after(E, T0):        # Debye T^3 heat capacity of diamond (Theta 2200 K) - lower bound on c -> upper bound on dT
    k = 12 * math.pi ** 4 / 5 * 8.314 / 12.01 / 2200 ** 3       # J/(g K^4)
    return ((E / mass) * 4 / k + T0 ** 4) ** 0.25
NUM['T_end_100K'] = [T_after(E, 100.0) for E in NUM['E_abs_J']]
NUM['T_end_10K'] = [T_after(E, 10.0) for E in NUM['E_abs_J']]
NUM['T_end_100K_2us'] = [T_after(E / 4, 100.0) for E in NUM['E_abs_J']]
print(json.dumps(NUM, indent=0, default=lambda o: round(o, 3))[:900])

# ============================================================== CAD (station at origin, beam along +X, z up)
st = Rig('T3_FEL_film_station')
psi = -(90 - thB)                       # rotate holder local frame: local Y -> plate normal n (azimuth thB)
nvec = np.array([math.cos(math.radians(thB)), math.sin(math.radians(thB)), 0.0])
def H(s): return rot(s, (0, 0, 1), psi)
# holder, local frame: u along X (in-plane, near beam), w along Y (normal), v along Z
st.add('PLATE', H(box(-15, 0, -8, 30, 0.5, 16)), DIAM, 'CVD diamond 30 × 16 × 0.5')
st.add('FILM', H(box(-13, 0.5, -5, 26, 0.02, 10)), (0.12, 0.10, 0.10), 'K3C60 10–20 nm (drawn 20 µm)')
for su in (-1, 1): st.add(f'CPW PAD {su:+d}', H(box(su * 13.5 - 1.5, 0.5, -1.5, 3, 0.03, 3)), GOLD, 'Au 100 nm pad')
st.add('FARADAY SENSOR', H(box(-2, 0.5, 5.4, 4, 0.06, 1.0)), (0.55, 0.85, 0.55), 'GaP 50 µm sensor')
fr = box(-21, -3, -13, 42, 3, 26).cut(box(-14, -4, -6.5, 28, 5, 13))
st.add('FRAME', H(fr), CU, 'OFHC Cu frame, Au plated')
cl = box(-21, 0.5, -13, 42, 1.0, 26).cut(box(-14, 0, -6.5, 28, 2, 13))
st.add('CLAMP', H(cl), CU, 'Cu clamp, Au plated')
coil = box(-18, -4, -10.5, 36, 1.0, 21).cut(box(-16, -5, -8.5, 32, 3, 17))
st.add('FIELD COIL', H(coil), (0.85, 0.55, 0.25), 'planar coil 20 t, Kapton Cu')
st.add('RTD', H(box(15.5, 0.5, -3, 3, 0.05, 6)), (0.75, 0.75, 0.80), 'Pt thin-film RTD on diamond')
st.add('CERNOX', H(box(-19, -5, 8, 3, 2, 2)), BLACK, 'Cernox')
st.add('RECEIVER', H(box(-25, -9, 13, 50, 11, 12)), CU, 'Cu receiver, dovetail along n')
st.add('COLD FINGER', cyl(10, 125, (0, 0, 25)), CU, 'OFHC Cu Ø20')
st.add('SHIELD', tube(24, 22, 110, (0, 0, 40)), (0.80, 0.62, 0.40), 'Cu radiation shield')
for k, off in enumerate((-4, 4)):
    st.add(f'COAX {k + 1}', cyl(1.1, 140, (off * 0.92, off * -0.39 + 3, 25)), (0.75, 0.75, 0.78), 'semi-rigid 40 GHz')
# chamber
st.add('CHAMBER', tube(127, 124, 300, (0, 0, -150)), (0.74, 0.76, 0.80), '316LN, Ø254')
st.add('TOP FLANGE', cyl(127, 25, (0, 0, 150)).cut(cyl(30, 25, (0, 0, 150))), SS, 'CF200')
st.add('BOTTOM PLATE', cyl(127, 3, (0, 0, -153)).cut(cyl(50, 3, (0, 0, -153))), SS, '316LN')
st.add('CRYOSTAT', cyl(40, 330, (0, 0, 175)), (0.62, 0.64, 0.68), 'UHV LHe flow cryostat 5–300 K')
st.add('TRANSFER LINE', cyl(12, 260, (40, 0, 430), (1, 0, 0)), (0.62, 0.64, 0.68), 'LHe transfer line')
st.add('RF FEEDTHROUGH', cyl(18, 40, (80, 40, 175)), BLACK, 'CF40, 2 × SMA 40 GHz')
for sx in (-1, 1):
    st.add(f'BEAM PORT {sx:+d}', tube(52, 49.5, 110, (sx * 120, 0, 0), (sx, 0, 0)), SS, 'CF100 port')
    st.add(f'BEAM FLANGE {sx:+d}', tube(76, 49.5, 22, (sx * 230, 0, 0), (sx, 0, 0)), SS, 'CF100')
    st.add(f'GATE VALVE {sx:+d}', cbox(sx * 287, 0, 0, 70, 190, 210).cut(cyl(50, 80, (sx * 247, 0, 0), (sx, 0, 0))), (0.45, 0.50, 0.58), 'CF100 gate valve (open when lasing)')
    st.add(f'BEAM PIPE {sx:+d}', tube(50, 47, 160, (sx * 322, 0, 0), (sx, 0, 0)), SS, 'to cavity')
def port(az, L, r_o, r_i, flange_r, name, mat, z=0.0):
    a = math.radians(az); d = (math.cos(a), math.sin(a), 0)
    p0 = (118 * d[0], 118 * d[1], z)
    st.add(name, tube(r_o, r_i, L, p0, d), SS, mat)
    pe = (p0[0] + d[0] * L, p0[1] + d[1] * L, z)
    st.add(name + ' FLANGE', tube(flange_r, r_i, 13, pe, d), SS, 'CF40')
    return pe, d
pe, d = port(thB - 30, 70, 21, 19, 35, 'VIEWPORT IN', 'CF40 port')
st.add('WINDOW IN', cyl(19, 2, (pe[0] + d[0] * 13, pe[1] + d[1] * 13, 0), d), DIAM, 'diamond (or ZnSe) window')
pe, d = port(thB + 30, 70, 21, 19, 35, 'VIEWPORT OUT', 'CF40 port')
st.add('WINDOW OUT', cyl(19, 2, (pe[0] + d[0] * 13, pe[1] + d[1] * 13, 0), d), DIAM, 'diamond (or ZnSe) window')
pe, d = port(thB, 90, 21, 19, 35, 'TRANSFER PORT', 'CF40 port', z=19)
a = math.radians(thB); c = np.array(pe) + np.array(d) * 13
st.add('LL VALVE', mv(rot(cbox(25, 0, 0, 50, 70, 80), (0, 0, 1), thB), c[0], c[1], 19), (0.45, 0.50, 0.58), 'CF40 gate valve')
c2 = c + np.array(d) * 50
st.add('LOAD LOCK', mv(rot(cbox(40, 0, 0, 80, 80, 80), (0, 0, 1), thB), c2[0], c2[1], 19), SS, 'CF40 6-way cross, turbo-pumped')
c3 = c2 + np.array(d) * 80
st.add('TRANSFER ARM', cyl(20, 520, (c3[0], c3[1], 19), d), (0.70, 0.72, 0.76), 'magnetic linear transfer, 600 mm')
st.add('SUITCASE PORT', cyl(35, 30, (c2[0] - 0, c2[1], 59), (0, 0, 1)), SS, 'CF40 to UHV suitcase (top)')
st.add('PUMP PORT', tube(52, 49, 150, (0, 0, -153), (0, 0, -1)), SS, 'CF100')
st.add('ION PUMP', cbox(0, 0, -400, 220, 160, 200), (0.30, 0.34, 0.40), 'ion pump 300 l/s + NEG')
st.add('TURBO', cyl(65, 160, (130, 0, -300 - 80), (1, 0, 0)), (0.55, 0.58, 0.62), 'turbo 300 l/s (valved)')
print('station parts', len(st.parts), f'{time.time() - t0:.1f}s')

PJ = {}
SPa, kept = [], []
for p in st.parts:
    if p['name'].startswith(('CRYOSTAT', 'TRANSFER LINE', 'RF FEED', 'ION', 'TURBO', 'PUMP PORT', 'SUITCASE', 'COAX', 'SHIELD', 'COLD FINGER')): continue
    try:
        pol, k = section_polys(p['shape'], (0, 0, 0), (0, 0, 1), (1, 0, 0), defl=0.05)
        for q in pol: SPa.append((p['name'], q))
        if k is not None: kept.append(k)
    except Exception as ex: print('sect', p['name'], ex)
PJ['secZ_polys'] = SPa
PJ['secZ'] = hlr(cq.Compound.makeCompound(kept), (0, 0, 1), (1, 0, 0), defl=0.2)
PJ['elev'] = hlr(st.compound(exclude=('BEAM PIPE', 'GATE VALVE -1')), (0, -1, 0), (1, 0, 0), defl=0.3)
print('station views', f'{time.time() - t0:.1f}s')
hold = [p for p in st.parts if p['name'].startswith(('PLATE', 'FILM', 'CPW', 'FARADAY', 'FRAME', 'CLAMP', 'FIELD COIL', 'RTD', 'CERNOX', 'RECEIVER'))]
hc = cq.Compound.makeCompound([p['shape'] for p in hold])
PJ['hold_front'] = hlr(hc, tuple(nvec), (-math.sin(math.radians(thB)), math.cos(math.radians(thB)), 0), defl=0.01)   # viewer on +n, z up; view x = -u
HS = []
for p in hold:
    try:
        pol, _ = section_polys(p['shape'], (0, 0, 0), (0, 0, 1), tuple(nvec), defl=0.005)
        for q in pol: HS.append((p['name'], q))
    except Exception: pass
PJ['hold_sec_polys'] = HS
print('holder views', f'{time.time() - t0:.1f}s')
N, Vx = iso(-60, 30)
cutp = []
for p in st.parts:
    try:
        s = p['shape'].cut(box(-1000, -1000, -1000, 2000, 1000, 2000)) if p['name'].startswith(('CHAMBER', 'TOP FLANGE', 'BOTTOM', 'SHIELD')) else p['shape']
        if s.Volume() > 1e-3: cutp.append(dict(p, shape=s))
    except Exception: pass
render(cutp, N, Vx, size=1500, zoom=1.0, opacity={'PLATE': 0.55, 'WINDOW IN': 0.5, 'WINDOW OUT': 0.5}).save(f'{OUT}/renders/T3_station_cutaway.png')
render(hold, *iso(40, 25), size=1100, zoom=0.95, opacity={'PLATE': 0.6}).save(f'{OUT}/renders/T3_holder_iso.png')
print(st.step())
write_dxf('T3_station', [('SECTION Z=0 (beam height)', *PJ['secZ'], [q for _, q in SPa], (0, 0)), ('ELEVATION from -y', *PJ['elev'], None, (0, 1400))])
pickle.dump(dict(PJ=PJ, NUM=NUM, parts=[(p['name'], p['mat']) for p in st.parts]), open(f'{OUT}/t3.pkl', 'wb'))
json.dump(NUM, open(f'{OUT}/t3_numbers.json', 'w'), indent=1, default=str)
print('done', f'{time.time() - t0:.1f}s')
