"""ptp.py - shared CAD + drawing helpers for the Pais test-programme drawing set (PTP-xxx).
Models in mm.  Sheets A3 landscape 420 x 297 mm, paper units mm, third-angle projection."""
import math, os, textwrap, json
import numpy as np
import cadquery as cq
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Arc, Polygon, Ellipse, PathPatch
from matplotlib.path import Path
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.gp import gp_Ax2, gp_Pnt, gp_Dir
from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_CompCurve
from OCP.GCPnts import GCPnts_QuasiUniformDeflection
from OCP.BRepLib import BRepLib
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE
from OCP.TopoDS import TopoDS
import ezdxf

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'out')
for d in ('', 'step', 'dxf', 'renders', 'png', 'pdf'): os.makedirs(os.path.join(OUT, d), exist_ok=True)
DATE = '13 NOV 2026'
NSHEETS = 20
PROJ = 'PAIS GAP LOOP · TEST PROGRAMME'
MONO = 'DejaVu Sans Mono'

# ------------------------------------------------------------------ colours (render)
STEEL = (0.60, 0.62, 0.66); DSTEEL = (0.42, 0.44, 0.48); ALU = (0.80, 0.82, 0.85); CU = (0.82, 0.50, 0.30)
G10 = (0.55, 0.68, 0.42); POLY = (0.90, 0.88, 0.76); LINER = (0.30, 0.26, 0.24); COIL = (0.22, 0.32, 0.62)
GOLD = (0.92, 0.76, 0.30); DIAM = (0.80, 0.90, 0.98); TI = (0.62, 0.62, 0.68); RED = (0.80, 0.22, 0.20)
BLACK = (0.16, 0.16, 0.18); GREEN = (0.25, 0.60, 0.35); PVDF = (0.95, 0.80, 0.15); SS = (0.70, 0.72, 0.75)

# ------------------------------------------------------------------ solids (mm)
def V(*a): return cq.Vector(*a)
def box(x, y, z, dx, dy, dz): return cq.Solid.makeBox(dx, dy, dz, V(x, y, z))
def cbox(cx, cy, cz, dx, dy, dz): return box(cx - dx / 2, cy - dy / 2, cz - dz / 2, dx, dy, dz)
def cyl(r, h, p=(0, 0, 0), d=(0, 0, 1), ang=360): return cq.Solid.makeCylinder(r, h, V(*p), V(*d), ang)
def tube(ro, ri, h, p=(0, 0, 0), d=(0, 0, 1)): return cyl(ro, h, p, d).cut(cyl(ri, h, p, d))
def cone(r1, r2, h, p=(0, 0, 0), d=(0, 0, 1)): return cq.Solid.makeCone(r1, r2, h, V(*p), V(*d))
def sph(r, p=(0, 0, 0)): return cq.Solid.makeSphere(r, V(*p), angleDegrees1=-90, angleDegrees2=90)
def torus(R, r, p=(0, 0, 0), d=(0, 0, 1)): return cq.Solid.makeTorus(R, r, V(*p), V(*d))
def sector(ri, ro, z0, h, a0, a1):
    """annular sector about Z: radii ri..ro, z0..z0+h, angles a0..a1 deg measured from +X."""
    s = cyl(ro, h, (0, 0, z0), ang=a1 - a0)
    if ri > 0: s = s.cut(cyl(ri, h, (0, 0, z0), ang=a1 - a0))
    return s.rotate(V(0, 0, 0), V(0, 0, 1), a0)
def rot(s, axis, ang, c=(0, 0, 0)): return s.rotate(V(*c), V(*c) + V(*axis), ang)
def mv(s, *d): return s.translate(V(*d))
def fuse(*ss):
    out = ss[0]
    for s in ss[1:]: out = out.fuse(s)
    return out.clean()

class Rig:
    """named, coloured parts; STEP, HLR projections, VTK renders"""
    def __init__(s, name): s.name, s.parts = name, []
    def add(s, name, shape, col, mat='', qty=1):
        s.parts.append(dict(name=name, shape=shape, col=col, mat=mat, qty=qty)); return shape
    def sel(s, names=None, exclude=()):
        return [p for p in s.parts if (names is None or any(p['name'].startswith(n) for n in names)) and not any(p['name'].startswith(e) for e in exclude)]
    def compound(s, names=None, exclude=()):
        return cq.Compound.makeCompound([p['shape'] for p in s.sel(names, exclude)])
    def step(s, fname=None):
        a = cq.Assembly(name=s.name.replace(' ', '_'))
        for i, p in enumerate(s.parts):
            a.add(cq.Workplane().add(p['shape']), name=f"{i:02d}_{p['name']}".replace(' ', '_').replace('/', '-'), color=cq.Color(*p['col']))
        fn = os.path.join(OUT, 'step', (fname or s.name.replace(' ', '_')) + '.step')
        try: a.save(fn)
        except Exception: cq.exporters.export(cq.Workplane().add(s.compound()), fn)
        return fn
    def mass(s, name, rho):  # rho g/cm3 -> g
        sh = [p for p in s.parts if p['name'] == name][0]['shape']; return sh.Volume() * rho / 1000.0

# ------------------------------------------------------------------ HLR
def unit(v): v = np.asarray(v, float); return v / np.linalg.norm(v)
def _edges_to_polylines(comp, defl):
    out = []
    if comp is None or comp.IsNull(): return out
    BRepLib.BuildCurves3d_s(comp, 1e-6)
    ex = TopExp_Explorer(comp, TopAbs_EDGE)
    while ex.More():
        e = TopoDS.Edge_s(ex.Current()); ex.Next()
        try:
            c = BRepAdaptor_Curve(e); d = GCPnts_QuasiUniformDeflection(c, defl)
            if d.IsDone() and d.NbPoints() >= 2:
                out.append(np.array([[d.Value(i).X(), d.Value(i).Y()] for i in range(1, d.NbPoints() + 1)])); continue
            u0, u1 = c.FirstParameter(), c.LastParameter()
            out.append(np.array([[c.Value(u).X(), c.Value(u).Y()] for u in np.linspace(u0, u1, 24)]))
        except Exception:
            pass
    return out
def hlr(shape, N, Vx, defl=None):
    sh = shape.wrapped if hasattr(shape, 'wrapped') else shape
    if defl is None:
        bb = cq.Shape.cast(sh).BoundingBox(); defl = max(0.01, 4e-4 * bb.DiagonalLength)
    a = HLRBRep_Algo(); a.Add(sh)
    a.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(0, 0, 0), gp_Dir(*map(float, N)), gp_Dir(*map(float, Vx)))))
    a.Update(); a.Hide(); h = HLRBRep_HLRToShape(a)
    vis = _edges_to_polylines(h.VCompound(), defl) + _edges_to_polylines(h.OutLineVCompound(), defl)
    hid = _edges_to_polylines(h.HCompound(), defl) + _edges_to_polylines(h.OutLineHCompound(), defl)
    return vis, hid

def section_polys(shape, origin, normal, Vx, defl=0.05):
    """cut `shape` by the plane (origin, normal), keep the side the normal points away from (viewer on +normal side),
    return 2D polygons [(outer, [holes])] of the cut faces in the view frame (x along Vx, y along normal x Vx)."""
    o, n, vx = np.array(origin, float), unit(normal), unit(Vx); vy = np.cross(n, vx)
    big = 1e5
    hs = cq.Solid.makeBox(2 * big, 2 * big, big, V(-big, -big, 0))
    # orient half-space box so that it occupies the +normal side, then cut it away
    z = np.array([0, 0, 1.0]); ax = np.cross(z, n); ang = math.degrees(math.acos(np.clip(np.dot(z, n), -1, 1)))
    if np.linalg.norm(ax) < 1e-9: ax = np.array([1.0, 0, 0])
    hs = hs.rotate(V(0, 0, 0), V(*ax), ang).translate(V(*o))
    out, kept = [], []
    for sol in (shape.Solids() if hasattr(shape, 'Solids') else [shape]):
        try: cut = sol.cut(hs)
        except Exception: continue
        kept.append(cut)
        for f in cut.Faces():
            if f.geomType() != 'PLANE': continue
            fn = np.array(f.normalAt().toTuple())
            if abs(abs(np.dot(fn, n)) - 1) > 1e-6 or abs(np.dot(np.array(f.Center().toTuple()) - o, n)) > 1e-4: continue
            def wire2d(w):
                c = BRepAdaptor_CompCurve(w.wrapped); d = GCPnts_QuasiUniformDeflection(c, defl)
                P = np.array([[d.Value(i).X(), d.Value(i).Y(), d.Value(i).Z()] for i in range(1, d.NbPoints() + 1)])
                return np.stack([(P - o) @ vx + o @ vx, (P - o) @ vy + o @ vy], 1)
            out.append((wire2d(f.outerWire()), [wire2d(w) for w in f.innerWires()]))
    return out, (cq.Compound.makeCompound(kept) if kept else None)

def write_dxf(name, views):
    """views: list of (label, vis, hid, sect_polys, (dx, dy)) in model mm; one DXF, views offset by (dx, dy)."""
    doc = ezdxf.new('R2010'); msp = doc.modelspace()
    doc.layers.add('VISIBLE', color=7); doc.layers.add('HIDDEN', color=8, linetype='DASHED'); doc.layers.add('SECTION', color=1); doc.layers.add('TEXT', color=3)
    for lab, vis, hid, sect, (dx, dy) in views:
        for pl in vis: msp.add_lwpolyline([(x + dx, y + dy) for x, y in pl], dxfattribs={'layer': 'VISIBLE'})
        for pl in hid: msp.add_lwpolyline([(x + dx, y + dy) for x, y in pl], dxfattribs={'layer': 'HIDDEN'})
        for outer, holes in (sect or []):
            for w in [outer] + holes: msp.add_lwpolyline([(x + dx, y + dy) for x, y in w], close=True, dxfattribs={'layer': 'SECTION'})
        allp = np.vstack(vis) if vis else np.zeros((1, 2))
        msp.add_text(lab, dxfattribs={'layer': 'TEXT', 'height': max(5, 0.02 * np.ptp(allp[:, 0]))}).set_placement((allp[:, 0].min() + dx, allp[:, 1].max() + dy + 20))
    fn = os.path.join(OUT, 'dxf', name + '.dxf'); doc.saveas(fn); return fn

# ------------------------------------------------------------------ VTK shaded render
def render(parts, N, Vx, size=1400, zoom=1.0, edges=True, opacity=None, label=None, bg=((0.98, 0.98, 0.99), (0.83, 0.85, 0.88)), tol=None):
    import vtk
    from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray, vtk_to_numpy
    from PIL import Image, ImageDraw, ImageFont
    N, Vx = unit(N), unit(Vx); Vy = np.cross(N, Vx)
    ren = vtk.vtkRenderer(); rw = vtk.vtkRenderWindow(); rw.SetOffScreenRendering(1); rw.AddRenderer(ren)
    rw.SetSize(size, size); rw.SetMultiSamples(0); ren.UseFXAAOn()
    ren.GradientBackgroundOn(); ren.SetBackground(*bg[1]); ren.SetBackground2(*bg[0])
    ren.SetUseDepthPeeling(1); ren.SetMaximumNumberOfPeels(8); rw.SetAlphaBitPlanes(1)
    allb = cq.Compound.makeCompound([p['shape'] for p in parts]).BoundingBox(); t0 = tol or max(0.02, allb.DiagonalLength * 6e-4)
    for p in parts:
        try: vs, ts = p['shape'].tessellate(t0, 0.25)
        except Exception: continue
        if not ts: continue
        pts = np.array([v.toTuple() for v in vs], float); tri = np.array(ts, np.int64)
        poly = vtk.vtkPolyData(); P = vtk.vtkPoints(); P.SetData(numpy_to_vtk(pts, deep=True)); poly.SetPoints(P)
        cells = np.hstack([np.full((len(tri), 1), 3, np.int64), tri]).ravel()
        ca = vtk.vtkCellArray(); ca.SetCells(len(tri), numpy_to_vtkIdTypeArray(cells, deep=True)); poly.SetPolys(ca)
        cl = vtk.vtkCleanPolyData(); cl.SetInputData(poly); cl.SetTolerance(1e-6); cl.Update()
        nm = vtk.vtkPolyDataNormals(); nm.SetInputConnection(cl.GetOutputPort()); nm.SetFeatureAngle(35); nm.SplittingOn(); nm.Update()
        mp = vtk.vtkPolyDataMapper(); mp.SetInputConnection(nm.GetOutputPort())
        a = vtk.vtkActor(); a.SetMapper(mp); pr = a.GetProperty(); pr.SetColor(*p['col'])
        pr.SetAmbient(0.18); pr.SetDiffuse(0.78); pr.SetSpecular(0.28); pr.SetSpecularPower(28); pr.SetInterpolationToPhong()
        op = (opacity or {}).get(p['name'], p.get('opacity', 1.0))
        if op < 1: pr.SetOpacity(op)
        ren.AddActor(a)
        if edges and op >= 0.6:
            fe = vtk.vtkFeatureEdges(); fe.SetInputConnection(cl.GetOutputPort()); fe.BoundaryEdgesOn(); fe.FeatureEdgesOn(); fe.SetFeatureAngle(32)
            fe.ManifoldEdgesOff(); fe.NonManifoldEdgesOff(); fe.ColoringOff()
            em = vtk.vtkPolyDataMapper(); em.SetInputConnection(fe.GetOutputPort()); em.SetResolveCoincidentTopologyToPolygonOffset()
            em.SetRelativeCoincidentTopologyLineOffsetParameters(-2, -2)
            ea = vtk.vtkActor(); ea.SetMapper(em); ea.GetProperty().SetColor(0.08, 0.08, 0.10); ea.GetProperty().SetLineWidth(1.3); ea.GetProperty().SetLighting(False)
            ren.AddActor(ea)
    lk = vtk.vtkLightKit(); lk.SetKeyLightIntensity(0.95); lk.AddLightsToRenderer(ren)
    cam = ren.GetActiveCamera(); cam.ParallelProjectionOn()
    c = np.array([(allb.xmin + allb.xmax) / 2, (allb.ymin + allb.ymax) / 2, (allb.zmin + allb.zmax) / 2])
    cam.SetFocalPoint(*c); cam.SetPosition(*(c + N * allb.DiagonalLength * 3)); cam.SetViewUp(*Vy)
    ren.ResetCamera(); cam.Zoom(zoom); ren.ResetCameraClippingRange()
    rw.Render()
    w2i = vtk.vtkWindowToImageFilter(); w2i.SetInput(rw); w2i.SetInputBufferTypeToRGB(); w2i.ReadFrontBufferOff(); w2i.Update()
    im = w2i.GetOutput(); wv, hv, _ = im.GetDimensions()
    arr = vtk_to_numpy(im.GetPointData().GetScalars()).reshape(hv, wv, -1)[::-1]
    img = Image.fromarray(arr[:, :, :3].copy())
    if label:
        d = ImageDraw.Draw(img); f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', int(size * 0.024))
        d.text((int(size * 0.03), int(size * 0.025)), label, fill=(40, 42, 48), font=f)
    return img

def iso(az, el):
    a, e = math.radians(az), math.radians(el)
    N = np.array([math.cos(e) * math.cos(a), math.cos(e) * math.sin(a), math.sin(e)])
    Vx = unit(np.cross([0, 0, 1], N)); return N, Vx

# ------------------------------------------------------------------ sheet + title block
LW_V, LW_H, LW_T = 0.8, 0.4, 0.28
def sheet(title, dwg, no, scale, test, rev='A'):
    fig = plt.figure(figsize=(420 / 25.4, 297 / 25.4)); ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 420); ax.set_ylim(0, 297); ax.axis('off')
    ax.add_patch(Rectangle((5, 5), 410, 287, fill=False, lw=0.3)); ax.add_patch(Rectangle((20, 10), 390, 277, fill=False, lw=1.1))
    for i in range(8):
        x = 20 + (i + 0.5) * 390 / 8
        for y in (7.5, 289.5): ax.text(x, y, str(i + 1), fontsize=5, ha='center', va='center')
        if i: ax.plot([20 + i * 390 / 8] * 2, [5, 10], 'k', lw=0.3); ax.plot([20 + i * 390 / 8] * 2, [287, 292], 'k', lw=0.3)
    for j in range(6):
        y = 10 + (j + 0.5) * 277 / 6
        ax.text(12.5, y, 'FEDCBA'[j], fontsize=5, ha='center', va='center'); ax.text(412.5, y, 'FEDCBA'[j], fontsize=5, ha='center', va='center')
        if j: ax.plot([5, 20], [10 + j * 277 / 6] * 2, 'k', lw=0.3); ax.plot([410, 415], [10 + j * 277 / 6] * 2, 'k', lw=0.3)
    x0 = 230
    ax.add_patch(Rectangle((x0, 10), 180, 52, fill=False, lw=0.9))
    for yy in (24, 34, 46, 56): ax.plot([x0, 410], [yy, yy], 'k', lw=0.35)
    ax.add_patch(Rectangle((x0, 56), 180, 6, color='#fbe9e7', lw=0))
    ax.text(x0 + 90, 59, 'CONCEPT DESIGN FOR REVIEW · NOT FOR MANUFACTURE · FACILITY ITEMS INDICATIVE', fontsize=5.2, ha='center', va='center', color='#b03a2e', weight='bold')
    ax.text(x0 + 3, 51, PROJ, fontsize=8.6, weight='bold', va='center')
    ax.text(407, 51, 'project s_crafts_e', fontsize=5, va='center', ha='right', color='0.3')
    ax.text(x0 + 3, 40, title, fontsize=7.6 if len(title) < 52 else 6.6, weight='bold', va='center')
    ax.plot([345, 345], [24, 34], 'k', lw=0.35)
    ax.text(x0 + 3, 29, test, fontsize=5.8, va='center')
    ax.text(347, 31.5, 'DWG NO', fontsize=4.2, va='center', color='0.35'); ax.text(378, 28.6, dwg, fontsize=10, weight='bold', va='center', ha='center')
    cells = [('SCALE', scale, 30), ('SHEET', f'{no} / {NSHEETS}', 26), ('REV', rev, 16), ('DATE', DATE, 30), ('UNITS', 'mm', 22), ('DRAWN', 'Claude (AI)', 26), ('PROJ.', '', 30)]
    x = x0
    for k, v, w in cells:
        ax.text(x + 1.5, 21.7, k, fontsize=4.2, va='center', color='0.35'); ax.text(x + w / 2, 15.5, v, fontsize=6.2, va='center', ha='center')
        if x > x0: ax.plot([x, x], [10, 24], 'k', lw=0.35)
        x += w
    # third-angle symbol in the last cell
    cx, cy = 396, 16
    ax.add_patch(Polygon([[cx - 9, cy - 3], [cx - 9, cy + 3], [cx - 1.5, cy + 4.5], [cx - 1.5, cy - 4.5]], closed=True, fill=False, lw=0.5))
    ax.add_patch(Circle((cx + 5, cy), 4.5, fill=False, lw=0.5)); ax.add_patch(Circle((cx + 5, cy), 3.0, fill=False, lw=0.5))
    ax.plot([cx - 10, cx + 10.5], [cy, cy], 'k', lw=0.2, ls=(0, (6, 1.5, 1, 1.5)))
    return fig, ax

def save(fig, dwg, pdf=None, dpi=None):
    fig.savefig(os.path.join(OUT, 'pdf', dwg + '.pdf'))
    fig.savefig(os.path.join(OUT, 'png', dwg + '.png'), dpi=dpi or 110)
    if pdf is not None: pdf.savefig(fig)
    plt.close(fig)

class View:
    """orthographic view of HLR polylines on paper; model mm -> paper mm by 1/scale; centred at (cx, cy)."""
    def __init__(s, ax, proj, den, cx, cy, sect=None, clip=None):
        s.ax, s.vis, s.hid, s.k = ax, proj[0], proj[1], 1.0 / den
        allp = np.vstack(s.vis) if s.vis else np.zeros((1, 2))
        s.mc = np.array([(allp[:, 0].min() + allp[:, 0].max()) / 2, (allp[:, 1].min() + allp[:, 1].max()) / 2])
        s.c = np.array([cx, cy]); s.sect = sect or []; s.bb = (allp[:, 0].min(), allp[:, 0].max(), allp[:, 1].min(), allp[:, 1].max())
    def P(s, u, v): return s.c + (np.array([u, v], float) - s.mc) * s.k
    def PP(s, pl): return s.c + (np.asarray(pl, float) - s.mc) * s.k
    def draw(s, hidden=True, lw=LW_V, hatch_cols=None, clip=None):
        cp = None
        if clip is not None:
            cp = Rectangle((clip[0], clip[1]), clip[2] - clip[0], clip[3] - clip[1], transform=s.ax.transData)
        arts = []
        for i, (outer, holes) in enumerate(s.sect):
            verts, codes = [], []
            for w in [outer] + holes:
                q = s.PP(w); verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
            arts.append(s.ax.add_patch(PathPatch(Path(verts, codes), facecolor=(hatch_cols[i % len(hatch_cols)] if hatch_cols else '0.93'), edgecolor='k', lw=0.15,
                                     hatch=('////', '\\\\\\\\', '////', 'xx')[i % 4] if not hatch_cols else '////')))
        for pl in s.vis:
            q = s.PP(pl); arts += s.ax.plot(q[:, 0], q[:, 1], color='k', lw=lw, solid_capstyle='round', solid_joinstyle='round')
        if hidden:
            for pl in s.hid:
                q = s.PP(pl); arts += s.ax.plot(q[:, 0], q[:, 1], color='0.25', lw=LW_H, ls=(0, (4, 2.2)))
        if cp is not None:
            for a in arts: a.set_clip_path(cp)
    def cline(s, a, b, lw=0.25):
        p, q = s.P(*a), s.P(*b); s.ax.plot([p[0], q[0]], [p[1], q[1]], color='k', lw=lw, ls=(0, (14, 2.5, 2, 2.5)))
    def extent(s): return s.P(s.bb[0], s.bb[2]), s.P(s.bb[1], s.bb[3])

def dim(ax, p1, p2, off, text, fs=5.6, mode='aligned', tshift=0.0, col='k'):
    p1, p2 = np.array(p1, float), np.array(p2, float)
    if mode == 'h':
        base = max(p1[1], p2[1]) if off > 0 else min(p1[1], p2[1]); a1 = np.array([p1[0], base + off]); a2 = np.array([p2[0], base + off]); n = np.array([0, 1.0])
    elif mode == 'v':
        base = max(p1[0], p2[0]) if off > 0 else min(p1[0], p2[0]); a1 = np.array([base + off, p1[1]]); a2 = np.array([base + off, p2[1]]); n = np.array([1.0, 0])
    else:
        u = unit(p2 - p1); n = np.array([-u[1], u[0]]); a1 = p1 + n * off; a2 = p2 + n * off
    sg = 1 if off >= 0 else -1
    for p, a in ((p1, a1), (p2, a2)):
        d = a - p; ln = np.linalg.norm(d)
        if ln > 1.2: dd = d / ln; ax.plot([p[0] + dd[0] * 0.8, a[0] + dd[0] * 1.5], [p[1] + dd[1] * 0.8, a[1] + dd[1] * 1.5], color=col, lw=LW_T)
    ax.annotate('', xy=a2, xytext=a1, arrowprops=dict(arrowstyle='<|-|>', lw=LW_T, color=col, shrinkA=0, shrinkB=0, mutation_scale=5))
    dv = a2 - a1; ang = math.degrees(math.atan2(dv[1], dv[0]))
    if ang > 90: ang -= 180
    if ang <= -90: ang += 180
    m = (a1 + a2) / 2 + unit(dv) * tshift + n * sg * 1.8
    ax.text(m[0], m[1], text, fontsize=fs, rotation=ang, ha='center', va='center', rotation_mode='anchor', color=col,
            bbox=dict(fc='white', ec='none', pad=0.15, alpha=0.85))

def leader(ax, tgt, at, text, fs=5.6, ha='left', va='center', col='k'):
    ax.annotate(text, xy=tgt, xytext=at, fontsize=fs, ha=ha, va=va, color=col,
                arrowprops=dict(arrowstyle='-|>', lw=LW_T, color=col, shrinkA=1.2, shrinkB=0, mutation_scale=5))
def balloon(ax, tgt, at, n, r=2.6):
    ax.add_patch(Circle(at, r, fill=True, fc='white', ec='k', lw=0.5, zorder=5)); ax.text(at[0], at[1], str(n), fontsize=5.6, ha='center', va='center', zorder=6)
    v = unit(np.array(tgt) - np.array(at)); s = np.array(at) + v * r
    ax.plot([s[0], tgt[0]], [s[1], tgt[1]], 'k', lw=0.3); ax.add_patch(Circle(tgt, 0.45, color='k'))
def label(ax, x, y, title, sub=None, fs=7.6):
    ax.text(x, y, title, fontsize=fs, weight='bold', ha='left', va='bottom')
    ax.plot([x, x + len(title) * fs * 0.235], [y - 0.7, y - 0.7], 'k', lw=0.6)
    if sub: ax.text(x, y - 3.8, sub, fontsize=5.2, ha='left', va='bottom', color='0.25')
def angle_mark(ax, c, r, a0, a1, text, fs=5.6):
    ax.add_patch(Arc(c, 2 * r, 2 * r, theta1=a0, theta2=a1, lw=LW_T))
    am = math.radians((a0 + a1) / 2); ax.text(c[0] + (r + 3.2) * math.cos(am), c[1] + (r + 3.2) * math.sin(am), text, fontsize=fs, ha='center', va='center')
def section_arrows(ax, p, q, lab, d=5):
    """cutting-plane line from p to q with view arrows pointing along +normal (left of p->q)"""
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]])
    ax.plot([p[0], q[0]], [p[1], q[1]], 'k', lw=0.3, ls=(0, (12, 2, 2, 2)))
    for e in (p, q):
        ax.plot([e[0], e[0] + u[0] * 0.01], [e[1], e[1] + u[1] * 0.01], 'k', lw=1.2)
        ax.annotate('', xy=e + n * d, xytext=e, arrowprops=dict(arrowstyle='-|>', lw=0.7, color='k', mutation_scale=7))
        ax.text(*(e + n * (d + 2.5)), lab, fontsize=7.5, weight='bold', ha='center', va='center')

def chars_for(width_mm, fs): return max(8, int(width_mm / (0.52 * fs * 0.3528)))
def table(ax, x, y, colw, rows, fs=5.2, rh=None, header=True, title=None, wrap=True, aligns=None, shade_first=True):
    """rows: list of tuples; returns bottom y. Cells wrap to column width."""
    rh = rh or fs * 0.3528 * 1.55 + 0.9
    if title: ax.text(x, y + 1.2, title, fontsize=fs + 1.4, weight='bold', va='bottom');
    W = sum(colw); yy = y
    for ri, r in enumerate(rows):
        cells = []
        for ci, c in enumerate(r):
            txt = str(c); lines = textwrap.wrap(txt, chars_for(colw[ci] - 1.6, fs)) if wrap and txt else [txt]
            cells.append(lines or [''])
        nl = max(len(c) for c in cells); h = rh + (nl - 1) * fs * 0.3528 * 1.25
        if ri == 0 and header and shade_first: ax.add_patch(Rectangle((x, yy - h), W, h, color='0.90', lw=0))
        xx = x
        for ci, lines in enumerate(cells):
            al = (aligns[ci] if aligns else 'l')
            tx = xx + 0.8 if al == 'l' else (xx + colw[ci] / 2 if al == 'c' else xx + colw[ci] - 0.8)
            ax.text(tx, yy - 0.75, '\n'.join(lines), fontsize=fs, va='top', ha={'l': 'left', 'c': 'center', 'r': 'right'}[al],
                    weight='bold' if (ri == 0 and header) else 'normal', linespacing=1.15)
            xx += colw[ci]
        ax.plot([x, x + W], [yy - h, yy - h], 'k', lw=0.25 if ri else 0.5)
        yy -= h
    ax.plot([x, x + W], [y, y], 'k', lw=0.5)
    xx = x
    for w in [0] + list(colw): xx += w; ax.plot([xx, xx], [y, yy], 'k', lw=0.25)
    ax.plot([x, x], [y, yy], 'k', lw=0.25)
    return yy

def notes(ax, x, y, w, items, fs=5.4, title='NOTES', numbered=True, lsp=1.22):
    if title: ax.text(x, y, title, fontsize=fs + 1.2, weight='bold', va='top'); y -= fs * 0.3528 * 2.0
    for i, it in enumerate(items):
        pre = f'{i + 1}. ' if numbered else ''
        lines = textwrap.wrap(pre + it, chars_for(w, fs), subsequent_indent='   ' if numbered else '')
        ax.text(x, y, '\n'.join(lines), fontsize=fs, va='top', linespacing=lsp)
        y -= len(lines) * fs * 0.3528 * lsp * 1.02 + fs * 0.3528 * 0.45
    return y

def put_image(ax, img, x, y, w, h=None, frame=True, title=None, crop=True):
    a = np.asarray(img)
    if crop:  # trim near-uniform background rows/cols
        g = a[:, :, :3].astype(float).mean(2); bgv = np.median(np.concatenate([g[0], g[-1], g[:, 0], g[:, -1]]))
        m = np.abs(g - np.linspace(g[0].mean(), g[-1].mean(), g.shape[0])[:, None]) > 6
        ys, xs = np.where(m)
        if len(xs): pad = 12; a = a[max(0, ys.min() - pad):ys.max() + pad, max(0, xs.min() - pad):xs.max() + pad]
    hh = h if h is not None else w * a.shape[0] / a.shape[1]
    if h is not None and w / h > a.shape[1] / a.shape[0]:  # fit inside box
        ww = h * a.shape[1] / a.shape[0]; x += (w - ww) / 2; w = ww
    elif h is not None:
        hh2 = w * a.shape[0] / a.shape[1]; y += (h - hh2) / 2; hh = hh2
    ax.imshow(a, extent=(x, x + w, y, y + hh), zorder=0, interpolation='antialiased')
    if frame: ax.add_patch(Rectangle((x, y), w, hh, fill=False, lw=0.3, ec='0.5'))
    if title: ax.text(x, y + hh + 1.2, title, fontsize=5.4, va='bottom', weight='bold', color='0.15')
    return x, y, w, hh

# ------------------------------------------------------------------ block diagrams & schematics
SIG = {'power': dict(color='#c0392b', lw=1.0, ls='-'), 'signal': dict(color='k', lw=0.55, ls='-'),
       'trigger': dict(color='#1f5fbf', lw=0.6, ls=(0, (4, 1.6))), 'optical': dict(color='#d98200', lw=0.85, ls=(0, (5, 1.5, 1, 1.5))),
       'vacuum': dict(color='0.5', lw=1.7, ls='-'), 'cryo': dict(color='#119a9a', lw=1.2, ls='-'),
       'rf': dict(color='#7b3fa0', lw=0.8, ls='-'), 'data': dict(color='#2e7d32', lw=0.6, ls=(0, (1.2, 1.2))),
       'mech': dict(color='0.35', lw=0.8, ls=(0, (6, 2)))}
SIGNAME = {'power': 'power / current', 'signal': 'analogue signal', 'trigger': 'trigger / timing', 'optical': 'optical fibre / beam',
           'vacuum': 'vacuum line', 'cryo': 'cryogen / cooling', 'rf': 'RF / coax', 'data': 'digital data', 'mech': 'mechanical link'}
class Box:
    def __init__(s, x, y, w, h): s.x, s.y, s.w, s.h = x, y, w, h
    def p(s, side, f=0.5):
        return {'L': (s.x, s.y + s.h * f), 'R': (s.x + s.w, s.y + s.h * f), 'T': (s.x + s.w * f, s.y + s.h), 'B': (s.x + s.w * f, s.y)}[side]
    @property
    def c(s): return (s.x + s.w / 2, s.y + s.h / 2)
def blk(ax, x, y, w, h, title, lines=(), fc='white', ec='k', fs=5.6, tag=None, lw=0.7, dash=False):
    ax.add_patch(Rectangle((x, y), w, h, fc=fc, ec=ec, lw=lw, ls=(0, (3, 1.5)) if dash else '-', zorder=2))
    t = textwrap.wrap(title, chars_for(w - 2, fs + 0.4))
    body = []
    for l in lines: body += textwrap.wrap(l, chars_for(w - 2, fs - 0.6)) or ['']
    ty = y + h - 1.3
    ax.text(x + w / 2, ty, '\n'.join(t), fontsize=fs + 0.3, weight='bold', ha='center', va='top', zorder=3, linespacing=1.1)
    if body:
        ax.text(x + w / 2, ty - len(t) * (fs + 0.3) * 0.3528 * 1.18 - 0.7, '\n'.join(body), fontsize=fs - 0.6, ha='center', va='top', zorder=3, linespacing=1.12, color='0.12')
    if tag: ax.text(x + 0.8, y + 0.8, tag, fontsize=4.4, ha='left', va='bottom', color='0.35', zorder=3)
    return Box(x, y, w, h)
def route(ax, pts, kind='signal', arrow=True, both=False, label=None, li=0, loff=(0, 1.1), fs=4.6, lha='center'):
    st = SIG[kind]; pts = [np.array(p, float) for p in pts]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    ax.plot(xs, ys, color=st['color'], lw=st['lw'], ls=st['ls'], zorder=1.5, solid_capstyle='butt')
    if arrow:
        a, b = pts[-2], pts[-1]; d = unit(b - a)
        ax.annotate('', xy=b, xytext=b - d * 2.2, arrowprops=dict(arrowstyle='-|>', color=st['color'], lw=st['lw'], mutation_scale=6), zorder=4)
    if both:
        a, b = pts[1], pts[0]; d = unit(b - a)
        ax.annotate('', xy=b, xytext=b - d * 2.2, arrowprops=dict(arrowstyle='-|>', color=st['color'], lw=st['lw'], mutation_scale=6), zorder=4)
    if label:
        a, b = pts[li], pts[li + 1]; m = (a + b) / 2 + np.array(loff)
        ax.text(m[0], m[1], label, fontsize=fs, ha=lha, va='center', color=st['color'], zorder=5, bbox=dict(fc='white', ec='none', pad=0.1, alpha=0.9))
def sig_legend(ax, x, y, kinds, fs=5.0, cols=1, colw=46):
    ax.text(x, y + 1.5, 'LINE KEY', fontsize=fs + 0.8, weight='bold', va='bottom')
    for i, k in enumerate(kinds):
        cx, cy = x + (i % cols) * colw, y - 3.6 * (i // cols) - 2
        st = SIG[k]; ax.plot([cx, cx + 10], [cy, cy], color=st['color'], lw=st['lw'], ls=st['ls'])
        ax.text(cx + 12, cy, SIGNAME[k], fontsize=fs, va='center')
def dot(ax, p, r=0.55, col='k'): ax.add_patch(Circle(p, r, color=col, zorder=4))
def wire(ax, pts, col='k', lw=0.6): ax.plot([p[0] for p in pts], [p[1] for p in pts], color=col, lw=lw, zorder=1.5)
def sym_R(ax, p, q, lab=None, col='k', lw=0.6, w=1.6, lab_side=1):
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]]); L = np.linalg.norm(q - p)
    a, b = p + u * L * 0.25, p + u * L * 0.75; zz = [p, a]
    for i in range(1, 7): zz.append(a + u * (L * 0.5) * i / 7 + n * w * (1 if i % 2 else -1))
    zz += [b, q]; wire(ax, zz, col, lw)
    if lab: m = (p + q) / 2 + n * (w + 2.6) * lab_side; ax.text(*m, lab, fontsize=4.8, ha='center', va='center')
def sym_C(ax, p, q, lab=None, lw=0.6):
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]]); m = (p + q) / 2
    wire(ax, [p, m - u * 0.7], lw=lw); wire(ax, [m + u * 0.7, q], lw=lw)
    for s in (-0.7, 0.7): wire(ax, [m + u * s - n * 2.4, m + u * s + n * 2.4], lw=lw * 1.4)
    if lab: ax.text(*(m + n * 4.6), lab, fontsize=4.8, ha='center', va='center')
def sym_L(ax, p, q, n_=4, lab=None, lw=0.6, col='k'):
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]]); L = np.linalg.norm(q - p)
    a = p + u * L * 0.15; seg = L * 0.7 / n_; wire(ax, [p, a], col, lw)
    for i in range(n_):
        c = a + u * seg * (i + 0.5); t = np.linspace(math.pi, 0, 14)
        pts = [c + u * (seg / 2) * math.cos(tt) + n * (seg / 2) * math.sin(tt) for tt in t]; wire(ax, pts, col, lw)
    wire(ax, [a + u * seg * n_, q], col, lw)
    if lab: ax.text(*((p + q) / 2 + n * (seg + 2.6)), lab, fontsize=4.8, ha='center', va='center')
def sym_gnd(ax, p, lw=0.6):
    x, y = p; wire(ax, [(x, y), (x, y - 2)], lw=lw)
    for i, w in enumerate((2.4, 1.6, 0.8)): wire(ax, [(x - w, y - 2 - i * 0.8), (x + w, y - 2 - i * 0.8)], lw=lw)
def sym_meter(ax, c, txt, r=3.2, fs=5.2, col='k'):
    ax.add_patch(Circle(c, r, fill=True, fc='white', ec=col, lw=0.6, zorder=3)); ax.text(*c, txt, fontsize=fs, ha='center', va='center', zorder=4, weight='bold')
def sym_src(ax, c, kind='I', r=3.4, lab=None):
    ax.add_patch(Circle(c, r, fill=True, fc='white', ec='k', lw=0.6, zorder=3))
    if kind == 'I': ax.annotate('', xy=(c[0], c[1] + r * 0.7), xytext=(c[0], c[1] - r * 0.7), arrowprops=dict(arrowstyle='-|>', lw=0.6, mutation_scale=5), zorder=4)
    elif kind == 'V': ax.text(c[0], c[1] + 1.1, '+', fontsize=5, ha='center', va='center', zorder=4); ax.text(c[0], c[1] - 1.3, '−', fontsize=5, ha='center', va='center', zorder=4)
    else:
        t = np.linspace(-1, 1, 30); ax.plot(c[0] + t * r * 0.6, c[1] + 0.9 * np.sin(t * math.pi), 'k', lw=0.6, zorder=4)
    if lab: ax.text(c[0] - r - 1.2, c[1], lab, fontsize=4.8, ha='right', va='center')
def sym_sw(ax, p, q, lab=None, lw=0.6):
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]]); L = np.linalg.norm(q - p)
    a, b = p + u * L * 0.3, p + u * L * 0.7; wire(ax, [p, a], lw=lw); wire(ax, [b, q], lw=lw)
    wire(ax, [a, b + n * 2.2], lw=lw); dot(ax, a, 0.5); dot(ax, b, 0.5)
    if lab: ax.text(*((p + q) / 2 + n * 4.5), lab, fontsize=4.8, ha='center', va='center')
def sym_D(ax, p, q, lab=None, lw=0.6):
    p, q = np.array(p, float), np.array(q, float); u = unit(q - p); n = np.array([-u[1], u[0]]); m = (p + q) / 2
    wire(ax, [p, m - u * 1.4], lw=lw); wire(ax, [m + u * 1.4, q], lw=lw)
    ax.add_patch(Polygon([m - u * 1.4 + n * 1.8, m - u * 1.4 - n * 1.8, m + u * 1.4], closed=True, fc='k', ec='k', lw=0.3))
    wire(ax, [m + u * 1.4 + n * 1.8, m + u * 1.4 - n * 1.8], lw=lw * 1.3)
    if lab: ax.text(*(m + n * 4.2), lab, fontsize=4.8, ha='center', va='center')

def fmt(x, n=3):
    return f'{x:.{n}g}'

def flag(ax, p, txt, side='R', col='k', fs=4.5):
    """net label: body extends from p toward `side`, tip points that way"""
    x, y = p; w = len(txt) * fs * 0.3528 * 0.62 + 2.2; h = 3.3; s = 1 if side == 'R' else -1
    pts = [(x, y - h / 2), (x + s * w, y - h / 2), (x + s * (w + 1.5), y), (x + s * w, y + h / 2), (x, y + h / 2)]
    ax.add_patch(Polygon(pts, closed=True, fc='white', ec=col, lw=0.5, zorder=4))
    ax.text(x + s * w / 2, y, txt, fontsize=fs, ha='center', va='center', color=col, zorder=5)
    return (x + s * (w + 1.5), y)
