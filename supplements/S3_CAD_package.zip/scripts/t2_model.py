"""T2 · B6 conductor (T2a I_c probe) and stator field map (T2b REBCO ring + mapping arm) - models, numbers, projections, renders"""
import math, json, pickle, time
import numpy as np
from scipy.special import ellipk, ellipe
from ptp import *
t0 = time.time(); NUM = {}

# =========================================================================== T2a probe (axis Z, field along Z, sample at z = 0)
pr = Rig('T2a_Ic_probe')
head = tube(18, 16, 110, (0, 0, -40)).cut(box(-10, -20, -13, 20, 6, 26))          # G10 head tube with a front window
for sx in (-1, 1): head = head.cut(cyl(2.2, 6, (sx * 15, 0, 0) if sx < 0 else (13, 0, 0), (1, 0, 0)))
pr.add('HEAD TUBE', head, G10, 'G10 tube 36 × 2')
rotor = cyl(10.5, 22, (-11, 0, 0), (1, 0, 0))
rotor = rotor.cut(box(-11.5, -11, -7, 23, 11, 14))                               # front pocket, open to -y
for sx in (-1, 1): rotor = rotor.cut(box(5.3 if sx > 0 else -11.7, 0, -5.2, 6.4, 6.2, 10.4))   # Cu block seats
for sx in (-1, 1): rotor = rotor.cut(box(5.5 if sx > 0 else -10.5, 2, 4, 5, 7, 7))             # braid slots
pr.add('ROTOR', rotor, G10, 'G10, Ø21 × 22')
for sx in (-1, 1):
    pr.add(f'CU BLOCK {"+" if sx > 0 else "-"}', box(5.5 if sx > 0 else -11.5, 0, -5, 6, 6, 10), CU, 'OFHC Cu')
    pr.add(f'BRAID {"+" if sx > 0 else "-"}', box(6 if sx > 0 else -10, 3, 5, 4, 5, 9), (0.85, 0.62, 0.40), 'Cu braid 25 mm²')
    pr.add(f'CERNOX {"+" if sx > 0 else "-"}', box(7.5 if sx > 0 else -9.5, 6, -1, 2, 0.9, 3), BLACK, 'Cernox SD')
    pr.add(f'HEATER {"+" if sx > 0 else "-"}', box(5.8 if sx > 0 else -11.2, 1, 5, 5.4, 4, 0.3), RED, 'film heater 25 Ω')
tape = box(-11, -0.1, -2, 22, 0.1, 4)
for zz in ((0.25, 1.75), (-2.0, 1.75)): tape = tape.cut(box(-2, -0.2, zz[0], 4, 0.3, zz[1]))
pr.add('SAMPLE', tape, (0.15, 0.15, 0.17), 'REBCO tape, 0.5 mm bridge')
pr.add('HALL', box(-1, -0.7, 6.0, 2, 0.6, 2), GOLD, 'cryogenic Hall sensor')
pr.add('AXLE', cyl(2, 32, (-16, 0, 0), (1, 0, 0)), TI, 'Ti rod Ø4')
pr.add('WORM WHEEL', cyl(5, 2.5, (11.5, 0, 0), (1, 0, 0)), (0.80, 0.70, 0.35), 'brass, m 0.3')
pr.add('WORM', cyl(2.0, 8, (12.75, -7, -4)), (0.80, 0.70, 0.35), 'brass worm')
pr.add('DRIVE ROD', cyl(1.5, 1680, (12.75, -7, 4)), G10, 'G10 rod Ø3 to top')
for sx in (-1, 1):
    pr.add(f'LEAD {"+" if sx > 0 else "-"}', box(sx * 8 - 2.5, 6, 14, 5, 5, 66), CU, 'OFHC Cu 5 × 5')
    pr.add(f'HTS LEAD {"+" if sx > 0 else "-"}', box(sx * 8 - 2, 7, 80, 4, 1.2, 320), (0.30, 0.30, 0.55), 'Bi-2223 stack, 1 kA')
    pr.add(f'VC LEAD {"+" if sx > 0 else "-"}', cyl(4, 1350, (sx * 8, 8.5, 400)), CU, 'Cu tube Ø8, vapour cooled')
pr.add('TERMINAL DISC', cyl(16, 10, (0, 0, 70)), G10, 'G10')
pr.add('HTS BOARD', box(-14, 8.4, 80, 28, 2, 320), G10, 'G10 board')
pr.add('PROBE TUBE', tube(18, 17.5, 1680, (0, 0, 70)), SS, '316L Ø36 × 0.5')
for zb in (600, 800, 1000, 1200, 1400): pr.add(f'BAFFLE {zb}', cyl(17.4, 1, (0, 0, zb)), CU, 'Cu baffle')
pr.add('FLANGE', cyl(50, 15, (0, 0, 1750)), SS, 'top flange (to suit VTI)')
pr.add('HEAD BOX', tube(50, 46, 80, (0, 0, 1765)).fuse(cyl(50, 6, (0, 0, 1845))), ALU, 'Al head box')
for sx in (-1, 1): pr.add(f'TERMINAL {"+" if sx > 0 else "-"}', cyl(10, 60, (sx * 22, 0, 1851)), CU, 'Cu terminal 1 kA')
pr.add('CONNECTOR 1', cyl(7.5, 25, (0, 30, 1851)), BLACK, '19-pin, V taps')
pr.add('CONNECTOR 2', cyl(7.5, 25, (0, -30, 1851)), BLACK, '19-pin, thermometry/Hall')
pr.add('ROTATOR MOTOR', box(-8, -38, 1851, 26, 20, 50), (0.30, 0.32, 0.36), 'stepper + encoder')
print('probe', len(pr.parts), f'{time.time() - t0:.1f}s')

PJ = {}
headc = pr.compound(exclude=('PROBE TUBE', 'BAFFLE', 'FLANGE', 'HEAD BOX', 'TERMINAL ', 'CONNECTOR', 'ROTATOR', 'VC LEAD', 'HTS', 'DRIVE'))
headc2 = cq.Compound.makeCompound([p['shape'].intersect(box(-40, -40, -45, 80, 80, 130)) for p in pr.parts if p['name'] not in ('PROBE TUBE', 'HEAD TUBE') and not p['name'].startswith(('BAFFLE', 'FLANGE', 'HEAD BOX', 'TERMINAL +', 'TERMINAL -', 'CONNECTOR', 'ROTATOR', 'VC LEAD'))])
PJ['head_front'] = hlr(headc2, (0, -1, 0), (1, 0, 0), defl=0.02)
PJ['head_side'] = hlr(headc2, (1, 0, 0), (0, 1, 0), defl=0.02)
PJ['probe_front'] = hlr(pr.compound(), (0, -1, 0), (1, 0, 0), defl=0.2)
PJ['sample_front'] = hlr(cq.Compound.makeCompound([tape]), (0, -1, 0), (1, 0, 0), defl=0.005)
print('probe views', f'{time.time() - t0:.1f}s')
N, Vx = iso(-60, 22)
cut = []
for p in pr.parts:
    try:
        s = p['shape'].intersect(box(-40, -40, -45, 80, 80, 100))
        if s.Volume() > 1e-6: cut.append(dict(p, shape=s))
    except Exception: pass
render(cut, N, Vx, size=1300, zoom=1.0, opacity={'HEAD TUBE': 0.28, 'PROBE TUBE': 0.28}).save(f'{OUT}/renders/T2a_head_iso.png')
N2, Vx2 = iso(-110, 28)
render([p for p in pr.parts if p['name'].startswith(('FLANGE', 'HEAD BOX', 'TERMINAL +', 'TERMINAL -', 'CONNECTOR', 'ROTATOR'))], N2, Vx2, size=700).save(f'{OUT}/renders/T2a_top_iso.png')

# bridge numbers
Jc = 36.3e6 * 1e4      # A/m2 (36.3 MA/cm2) at 30 T, B||ab, 4.2 K
NUM['Ic_bridge_A'] = Jc * 4e-6 * 0.5e-3
NUM['Ic_full_tape_A'] = Jc * 4e-6 * 4e-3
NUM['Je_pass'] = 5.856 / 0.506

# =========================================================================== T2b ring coil: field, inductance, stress
mu0 = 4e-7 * math.pi
RI, RO, HZ, NP, NPANC, GAP = 0.500, 0.530, 0.012, 250, 4, 0.001       # winding: r 500-530 mm, 4 pancakes of 12 mm tape, 250 turns each
zc = [(-1.5 * (HZ + GAP)), (-0.5 * (HZ + GAP)), (0.5 * (HZ + GAP)), (1.5 * (HZ + GAP))]
NTURN = NP * NPANC
def loop_B(a, zl, r, z, I=1.0):
    """field (Br, Bz) of a circular loop radius a at height zl, at (r, z)"""
    dz = z - zl; r = max(r, 1e-9)
    m = 4 * a * r / ((a + r) ** 2 + dz ** 2); K, E = ellipk(m), ellipe(m)
    den = math.sqrt((a + r) ** 2 + dz ** 2)
    Bz = mu0 * I / (2 * math.pi * den) * (K + (a * a - r * r - dz * dz) / ((a - r) ** 2 + dz ** 2) * E)
    Br = mu0 * I / (2 * math.pi * r * den) * dz * (-K + (a * a + r * r + dz * dz) / ((a - r) ** 2 + dz ** 2) * E)
    return Br, Bz
def coil_B(r, z, I, nr=12, nzs=4):
    Br = Bz = 0.0; per = NP / nr / nzs
    for zc_ in zc:
        for i in range(nr):
            a = RI + (i + 0.5) * (RO - RI) / nr
            for j in range(nzs):
                zl = zc_ - HZ / 2 + (j + 0.5) * HZ / nzs
                br, bz = loop_B(a, zl, r, z, I * per); Br += br; Bz += bz
    return Br, Bz
orbit = 0.450
for I in (200, 300, 400):
    NUM[f'B_orbit_{I}A'] = float(coil_B(orbit, 0, I)[1])
    NUM[f'B_centre_{I}A'] = float(coil_B(1e-6, 0, I)[1])
    Bmax = max(math.hypot(*coil_B(RI - 0.002, z, I, nr=30, nzs=8)) for z in np.linspace(-0.027, 0.027, 7))
    NUM[f'Br_end_{I}A'] = float(abs(coil_B(RI + 0.015, 0.0265, I, nr=30, nzs=8)[0]))
    NUM[f'B_max_winding_{I}A'] = Bmax
    J = I / (0.12e-3 * 12e-3)            # A/m2 over tape + insulation (0.12 mm pitch)
    NUM[f'hoop_MPa_{I}A'] = Bmax * J * RI / 1e6 * 0.75     # simple BJR estimate x 0.75 (field falls through the build)
prof = [(r, float(coil_B(r, 0, 300)[1])) for r in np.linspace(0.0, 0.465, 16)]
NUM['Bz_profile_300A'] = prof
a_eq = math.sqrt((RO - RI) * (NPANC * HZ + 3 * GAP) / math.pi); am = (RI + RO) / 2
L = mu0 * NTURN ** 2 * am * (math.log(8 * am / a_eq) - 2)
NUM.update(dict(N_turns=NTURN, L_H=L, tape_km=NTURN * 2 * math.pi * am / 1e3, a_eq_mm=a_eq * 1e3))
for I in (200, 300, 400): NUM[f'E_kJ_{I}A'] = 0.5 * L * I ** 2 / 1e3
NUM['R_dump_ohm_400A_500V'] = 500 / 400; NUM['tau_s'] = L / (500 / 400)
# requirement: 6-80 ppm of B0 at n = 1  -> at the rig's orbit field
NUM['req_ppm'] = (6, 80)
print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in NUM.items() if 'profile' not in k})

# =========================================================================== T2b CAD (axis Z, midplane z = 0, mm)
rg = Rig('T2b_ring_and_mapper')
for i, zc_ in enumerate(zc):
    rg.add(f'PANCAKE {i + 1}', cyl(530, 12, (0, 0, zc_ * 1e3 - 6)).cut(cyl(500, 12, (0, 0, zc_ * 1e3 - 6))), COIL, 'REBCO 12 mm, 250 turns')
rg.add('FORMER', tube(500, 488, 76, (0, 0, -38)).fuse(tube(545, 488, 6, (0, 0, -44))).fuse(tube(545, 488, 6, (0, 0, 38))), SS, '316L bobbin + flanges')
rg.add('OVERBAND', tube(536, 530, 54, (0, 0, -27)), SS, '316L overband 6')
rg.add('SHIELD', tube(620, 617, 190, (0, 0, -95)).fuse(tube(481, 478, 190, (0, 0, -95))).fuse(tube(620, 478, 3, (0, 0, 92))).fuse(tube(620, 478, 3, (0, 0, -95))), ALU, 'Al 1100 shield + MLI')
vv = tube(645, 640, 220, (0, 0, -110)).fuse(tube(470, 465, 220, (0, 0, -110))).fuse(tube(645, 465, 10, (0, 0, 100))).fuse(tube(645, 465, 10, (0, 0, -110)))
rg.add('VACUUM VESSEL', vv, (0.74, 0.76, 0.80), '316L annular vessel')
for k in range(4):
    a = math.radians(45 + 90 * k); x, y = 520 * math.cos(a), 520 * math.sin(a)
    rg.add(f'STRUT {k + 1}', cyl(8, 56, (x, y, -100)), G10, 'G10 strut Ø16')
    lx, ly = 600 * math.cos(a), 600 * math.sin(a)
    rg.add(f'LEG {k + 1}', box(lx - 30, ly - 30, -710, 60, 60, 600), ALU, 'Al 6061 leg 60 × 60')
for k, ang in enumerate((0, 180)):
    a = math.radians(ang); x, y = 580 * math.cos(a), 580 * math.sin(a)
    rg.add(f'COLD HEAD {k + 1}', cyl(45, 260, (x, y, 110)), (0.55, 0.57, 0.62), 'GM cold head, single stage')
    rg.add(f'COOLER MOTOR {k + 1}', cyl(70, 140, (x, y, 370)), (0.30, 0.32, 0.36), 'cold-head motor')
    rg.add(f'THERMAL LINK {k + 1}', box(x - 25 if ang == 0 else x - 25, y - 15, 44, 50, 30, 56), CU, 'Cu link to former')
rg.add('LEAD TURRET', cyl(55, 280, (0, 580, 110)), (0.62, 0.64, 0.68), 'Cu + HTS leads 600 A')
rg.add('LEAD TOP', cyl(70, 20, (0, 580, 390)), ALU, 'lead terminals')
for k in range(8):
    a = math.radians(22.5 + 45 * k)
    for zs, nm in ((112, 'U'), (-128, 'L')):
        tc = cbox(560, 0, zs + 8, 80, 120, 16).cut(cbox(560, 0, zs + 8, 50, 90, 16))
        rg.add(f'TRIM {nm}{k + 1}', rot(tc, (0, 0, 1), math.degrees(a)), (0.85, 0.55, 0.25), 'Cu trim coil 200 t')
rg.add('COLUMN', tube(75, 65, 640, (0, 0, -710)), ALU, 'Al column Ø150')
rg.add('ROTARY STAGE', cyl(95, 50, (0, 0, -70)), (0.35, 0.36, 0.40), 'non-magnetic piezo stage + encoder')
rg.add('HUB', cyl(45, 20, (0, 0, -20)), ALU, 'hub')
rg.add('ARM', box(0, -20, -10, 455, 40, 20), (0.25, 0.27, 0.30), 'CFRP arm 40 × 20')
rg.add('COUNTERARM', box(-300, -20, -10, 300, 40, 20), (0.25, 0.27, 0.30), 'CFRP')
rg.add('COUNTERWEIGHT', cbox(-280, 0, 0, 40, 60, 40), (0.55, 0.45, 0.30), 'brass')
rg.add('PROBE HEAD', box(380, -25, -14, 75, 50, 28), (0.95, 0.95, 0.92), 'G10 head: Hall array + search coil')
for i, rr in enumerate((395, 410, 425, 440, 452)): rg.add(f'HALL {i + 1}', cbox(rr, 0, 14.5, 6, 6, 1.2), GOLD, '3-axis Hall')
rg.add('SEARCH COIL', cbox(417, 0, -14.5, 20, 20, 1.5), CU, 'search coil 20 × 20, 200 t')
rg.add('NMR PROBE', cyl(10, 60, (0, 0, 20)), (0.85, 0.30, 0.30), 'NMR probe on axis')
rg.add('FLOOR PLATE', cbox(0, 0, -720, 1500, 1500, 20), (0.70, 0.70, 0.66), 'floor / base plate')
print('ring parts', len(rg.parts), f'{time.time() - t0:.1f}s')

# half section r-z at phi = 90 deg plane x = 0 ... use plane through axis containing +X; keep y > 0 half? view from -y
SPOL = []
for p in rg.parts:
    if p['name'].startswith(('FLOOR', 'COUNTER')): continue
    try:
        pol, _ = section_polys(p['shape'], (0, 0, 0), (0, -1, 0), (1, 0, 0), defl=0.3)
        for q in pol: SPOL.append((p['name'], q))
    except Exception as ex: print('sect fail', p['name'], ex)
PJ['ring_sect_polys'] = SPOL
PJ['ring_plan'] = hlr(rg.compound(exclude=('FLOOR',)), (0, 0, 1), (1, 0, 0), defl=0.4)
print('ring views', f'{time.time() - t0:.1f}s')
N3, Vx3 = iso(-55, 28)
cutc = []
for p in rg.parts:
    try:
        s = p['shape'].cut(box(0, -2000, -100, 2000, 2000, 1000)) if not p['name'].startswith(('ARM', 'PROBE HEAD', 'HALL', 'SEARCH', 'FLOOR', 'NMR', 'HUB', 'ROTARY', 'COLUMN')) else p['shape']
        if s.Volume() > 1e-3: cutc.append(dict(p, shape=s))
    except Exception: pass
render(cutc, N3, Vx3, size=1500, zoom=1.0).save(f'{OUT}/renders/T2b_ring_cutaway.png')
render(rg.parts, iso(-35, 35)[0], iso(-35, 35)[1], size=1000, zoom=1.0).save(f'{OUT}/renders/T2b_ring_iso.png')
print(pr.step(), rg.step())
write_dxf('T2a_probe', [('PROBE (front)', *PJ['probe_front'], None, (0, 0)), ('HEAD front', *PJ['head_front'], None, (200, 0)), ('HEAD side', *PJ['head_side'], None, (300, 0))])
write_dxf('T2b_ring', [('PLAN', *PJ['ring_plan'], None, (0, 0)), ('HALF SECTION', [], [], [q for _, q in SPOL], (0, 1600))])
pickle.dump(dict(PJ=PJ, NUM=NUM, parts=[(p['name'], p['mat']) for p in pr.parts], rparts=[(p['name'], p['mat']) for p in rg.parts]), open(f'{OUT}/t2.pkl', 'wb'))
json.dump(NUM, open(f'{OUT}/t2_numbers.json', 'w'), indent=1, default=str)
print('done', f'{time.time() - t0:.1f}s')
