"""T1 sheets PTP-101..105 (reads out/t1.pkl from t1_model.py)"""
import pickle, math, sys
import numpy as np
from PIL import Image
from ptp import *

D = pickle.load(open(f'{OUT}/t1.pkl', 'rb')); PJ, NUM = D['PJ'], D['NUM']; R = D['R']
Pend, e, nrm, pp = (np.array(D[k]) for k in ('Pend', 'e', 'nrm', 'pp'))
TEST = 'TEST T1 · B6 TANGENTIAL COUPON SHOT · tests I.30 · design I.34'
A = lambda ph: ph - 90.0
def P_arc(ph, r=R): a = math.radians(A(ph)); return np.array([r * math.cos(a), r * math.sin(a)])
def along(s, lat=0.0): return Pend + e * s + nrm * lat
geo = {int(r['g']): r for r in NUM['entry']}
SY = lambda g: -(R - g)
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'
M = NUM['mass_kg']; MT = NUM['fixture_mass_kg']
ONLY = sys.argv[1:]

def chain(ax, pts, col=RD, lw=0.7):
    pts = np.array(pts); ax.plot(pts[:, 0], pts[:, 1], color=col, lw=lw, ls=(0, (10, 2, 2, 2)), zorder=6)
def shot_path(v, g=5, s_end=950, n=40):
    th = geo[g]['theta']; xi = geo[g]['x_imp']
    p1 = [v.P(-2250, SY(g)), v.P(xi, SY(g))]
    arc = [v.P(*P_arc(ph, R)) for ph in np.linspace(th, 40, n)]
    ex = [v.P(*along(s)) for s in (0, s_end)]
    return p1 + arc + ex
def fx_h(ax, a, b, lab, side='l'):
    a, b = np.array(a), np.array(b); ax.plot([a[0], b[0]], [a[1], b[1]], color=BL, lw=0.5, ls=(0, (2, 1.2)), zorder=6)
    u = unit(b - a); n = np.array([-u[1], u[0]])
    ax.add_patch(Polygon([a - u * 2.6 + n * 1.6, a - u * 2.6 - n * 1.6, a], closed=True, fc=BL, ec=BL, zorder=7))
    ax.add_patch(Polygon([b + n * 2.2, b - n * 2.2, b - n * 2.2 + u * 1.2, b + n * 2.2 + u * 1.2], closed=True, fc='white', ec=BL, lw=0.6, zorder=7))
    ax.text(*(a - u * 4.5), lab, fontsize=4.6, color=BL, ha='center', va='center')
def fx_v(ax, p, lab):
    ax.add_patch(Circle(p, 1.6, fc='white', ec=BL, lw=0.6, zorder=7)); ax.plot([p[0] - 1.1, p[0] + 1.1], [p[1] - 1.1, p[1] + 1.1], color=BL, lw=0.5, zorder=8)
    ax.plot([p[0] - 1.1, p[0] + 1.1], [p[1] + 1.1, p[1] - 1.1], color=BL, lw=0.5, zorder=8); ax.text(p[0] + 2.2, p[1] - 2.4, lab, fontsize=4.6, color=BL)
def camera(ax, p, tgt, lab, half=14):
    p, tgt = np.array(p), np.array(tgt); u = unit(tgt - p); n = np.array([-u[1], u[0]])
    ax.add_patch(Polygon([p - u * 5 + n * 1.8, p - u * 5 - n * 1.8, p - u * 1 - n * 1.8, p - u * 1 + n * 1.8], closed=True, fc='0.2', ec='k', lw=0.4, zorder=7))
    ax.add_patch(Polygon([p - u * 1 + n * 0.9, p - u * 1 - n * 0.9, p - n * 1.6, p + n * 1.6], closed=True, fc='0.45', ec='k', lw=0.3, zorder=7))
    d = np.linalg.norm(tgt - p)
    for s in (-1, 1): ax.plot([p[0], tgt[0] + n[0] * half * s], [p[1], tgt[1] + n[1] * half * s], color='0.45', lw=0.3, ls=(0, (1.5, 1.5)), zorder=5)
    ax.text(*(p - u * 7.5), lab, fontsize=4.6, ha='center', va='center')

# =====================================================================================  PTP-101
if not ONLY or '101' in ONLY:
    fig, ax = sheet('T1 · LIGHT-GAS-GUN RANGE · GENERAL ARRANGEMENT', 'PTP-101', 2, '≈1:125 / 1:25', TEST)
    label(ax, 24, 277, 'RANGE ELEVATION (schematic)', 'lengths ≈ 1:125 · diameters not to scale · gun, tanks and bunker are facility items (large two-stage gun class, e.g. SwRI)')
    yc = 246
    segs = [(1.2, 6.5, '0.66', 'POWDER BREECH', 'gun-powder charge'), (12.0, 3.6, '0.80', 'PUMP TUBE', 'piston · H₂ or He fill'),
            (1.0, 7.5, '0.58', 'HIGH-PRESSURE SECTION', 'rupture disc'), (7.0, 2.0, '0.86', 'LAUNCH TUBE', 'bore ≥ Ø38, smooth'),
            (2.0, 10.0, '0.92', 'BLAST TANK', 'sabot stripper Ø30 · sabot catch'), (2.0, 3.0, '0.92', 'FLIGHT TUBE', 'laser screens LS1, LS2 (0.5 m)'),
            (3.6, 13.0, '0.97', 'TARGET TANK', '≤ 1 mbar · track fixture · catcher')]
    x = 34; XS = []
    for L, hh, fc, nm, sub in segs:
        w = L * 8; ax.add_patch(Rectangle((x, yc - hh), w, 2 * hh, fc=fc, ec='k', lw=0.6, zorder=2)); XS.append((x, x + w, hh, nm, sub)); x += w
    ax.add_patch(Polygon([[XS[2][0], yc + 7.5], [XS[2][1], yc + 2.0], [XS[2][1], yc - 2.0], [XS[2][0], yc - 7.5]], closed=True, fc='0.5', ec='k', lw=0.5, zorder=3))
    ax.plot([28, XS[-1][1] + 6], [yc, yc], color='k', lw=0.3, ls=(0, (14, 2.5, 2, 2.5)), zorder=4)
    lab_at = [(XS[0][0] + 6, yc + 17, 'c'), (XS[1][0] + 48, yc + 13, 'c'), (XS[2][0] + 4, yc - 17, 'c'), (XS[3][0] + 28, yc + 13, 'c'),
              (XS[4][0] + 8, yc - 19, 'c'), (XS[5][0] - 2, yc + 17, 'c'), (XS[6][0] + 14, yc - 21, 'c')]
    for (x0, x1, hh, nm, sub), (tx, ty, _) in zip(XS, lab_at):
        up = ty > yc; tgt = ((x0 + x1) / 2, yc + (hh if up else -hh))
        ax.annotate(f'{nm}\n{sub}', xy=tgt, xytext=(tx, ty), fontsize=4.9, ha='center', va='bottom' if up else 'top', linespacing=1.15,
                    arrowprops=dict(arrowstyle='-', lw=0.3, color='k', shrinkA=0.5, shrinkB=0))
    # stations in the flight tube and tank
    for xx, nm in ((XS[5][0] + 4, 'LS1'), (XS[5][0] + 8, 'LS2')):
        ax.plot([xx, xx], [yc - 4.5, yc + 4.5], color=RD, lw=0.8, zorder=5)
    tx0 = XS[6][0]
    ax.add_patch(Arc((tx0 + 11, yc + 20), 32, 40, theta1=246, theta2=291, lw=1.0, color='0.25', zorder=4))
    ax.add_patch(Rectangle((tx0 + 22, yc - 6), 4.5, 8, fc='0.35', ec='k', lw=0.4, zorder=4))
    for xx in (tx0 + 5, tx0 + 17):
        ax.add_patch(Polygon([[xx - 1.5, yc + 16.5], [xx + 1.5, yc + 16.5], [xx, yc + 13.6]], closed=True, fc=BL, ec=BL, zorder=5))
        ax.plot([xx, xx], [yc + 13.6, yc - 13], color=BL, lw=0.4, ls=(0, (2, 1.2)), zorder=4)
    ax.text(tx0 + 25, yc + 15.5, 'FX heads ×4\n(2 pairs)', fontsize=4.4, color=BL, ha='left')
    # vacuum
    for i in (4, 5, 6):
        xm = (XS[i][0] + XS[i][1]) / 2; ax.plot([xm, xm], [yc - XS[i][2], 206], color='0.5', lw=1.4, zorder=1)
    ax.plot([(XS[4][0] + XS[4][1]) / 2, (XS[6][0] + XS[6][1]) / 2], [206, 206], color='0.5', lw=1.4)
    ax.plot([(XS[6][0] + XS[6][1]) / 2, 266], [206, 206], color='0.5', lw=1.4); blk(ax, 266, 201.5, 36, 9, 'ROOTS + ROTARY PUMPS', fs=4.6)
    ax.plot([XS[6][1], 287], [206, 206], color='0.5', lw=1.4) if False else None
    # bunker
    b = blk(ax, 338, 226, 66, 40, 'INSTRUMENTATION BUNKER', ['trigger computer · DG645 · FX pulsers', 'PDV rack · digitizers · TIC', 'Rb 10 MHz · DAQ PC · safety PLC', 'gun control (facility)'], fs=5.2)
    for dy, kind, lab in ((10, 'rf', 'coax: PVDF ×9, LS ×2'), (4, 'optical', 'fibre: PDV, cameras'), (-2, 'trigger', 'triggers'), (-8, 'power', 'FX HV cables')):
        route(ax, [(XS[6][1], yc + dy * 0.6), (338, 246 + dy)], kind=kind, arrow=False)
        ax.text(301, 246 + dy * 0.8 + 1.3, lab, fontsize=4.3, ha='center', color=SIG[kind]['color'])
    # dimension chain
    yd = 219
    for x0, x1, hh, nm, sub in XS:
        dim(ax, (x0, yc - hh), (x1, yc - hh), yd - (yc - hh), f'{(x1 - x0) / 8:g} m', fs=4.6, mode='h')
    ax.text(150, 212.5, 'overall ≈ 29 m (indicative)', fontsize=5.0, ha='center')

    # ---------------------------------------------------------------- target tank plan 1:25
    label(ax, 24, 205, 'TARGET TANK · PLAN 1:25', 'to scale · coupon path shown for g = 5 mm')
    v = View(ax, PJ['plan'], 25, 136, 145); v.mc = np.array([600.0, -1425.0])
    TX0, TX1, TY0, TY1 = -1200, 2400, -2425, -425
    p0, p1 = v.P(TX0, TY0), v.P(TX1, TY1)
    ax.add_patch(Rectangle(p0, *(p1 - p0), fill=False, lw=1.2)); ax.add_patch(Rectangle(p0 - 0.9, *(p1 - p0 + 1.8), fill=False, lw=0.4))
    v.draw(hidden=False, lw=0.35)
    f0, f1 = v.P(-2250, SY(5) - 150), v.P(TX0, SY(5) + 150)
    ax.add_patch(Rectangle(f0, *(f1 - f0), fill=False, lw=0.7))
    chain(ax, shot_path(v, 5))
    for xx, nm in ((-2200, 'LS1'), (-1700, 'LS2')):
        a_, b_ = v.P(xx, SY(5) - 150), v.P(xx, SY(5) + 150); ax.plot([a_[0], b_[0]], [a_[1], b_[1]], color=RD, lw=0.9); ax.text(a_[0], a_[1] - 2.6, nm, fontsize=4.6, ha='center', color=RD)
    fx_h(ax, v.P(-500, TY1), v.P(-500, TY0), 'FX1')
    fx_v(ax, v.P(-500, SY(5)), 'FX2 (vert.)')
    q = along(200); tN = (TY1 - q[1]) / nrm[1]; tS = (q[1] - TY0) / nrm[1]
    fx_h(ax, v.P(*(q + nrm * tN)), v.P(*(q - nrm * tS)), 'FX3')
    fx_v(ax, v.P(*q), 'FX4')
    camera(ax, v.P(180, TY1 + 60), v.P(180, -1990), 'HSC-1', half=7)
    camera(ax, v.P(1050, TY1 + 60), v.P(*P_arc(28, R)), 'HSC-2', half=9)
    route(ax, [v.P(*pp), v.P(pp[0], TY1)], kind='optical', arrow=False)
    fb = v.P(pp[0], TY1); ax.add_patch(Rectangle(fb - (1.5, 0.5), 3, 2, fc=OR, ec='k', lw=0.3, zorder=7))
    gq = v.P(*P_arc(20, 2160)); gw = v.P(gq[0] * 0 + 650, TY0)
    route(ax, [v.P(*P_arc(20, 2106)), v.P(*P_arc(20, 2200)), v.P(650, -2300), v.P(650, TY0)], kind='rf', arrow=False)
    ax.add_patch(Rectangle(v.P(650, TY0) - (1.5, 1.5), 3, 2, fc='#7b3fa0', ec='k', lw=0.3, zorder=7))
    route(ax, [v.P(TX1, -700), v.P(TX1 + 200, -700)], kind='vacuum', arrow=False); ax.text(*(v.P(TX1 + 230, -700) + (0.5, 0)), 'to pumps', fontsize=4.4, va='center')
    L = [((-150, SY(5)), (-950, -900), 'coupon (g = 5)'), ((P_arc(12, 2106)), (300, -2800), 'track fixture  PTP-102'),
         (tuple(along(1000)), (2050, -320), 'catcher'), (tuple(pp), (1500, -250), 'PDV probe, fibre feedthrough'),
         (tuple(v.P(650, TY0)), None, None)]
    leader(ax, v.P(-150, SY(5)), v.P(-1100, -1150), 'coupon (g = 5)', fs=4.8)
    leader(ax, v.P(*P_arc(12, 2106)), v.P(250, -2780), 'track fixture (PTP-102)', fs=4.8)
    leader(ax, v.P(*along(1000)), v.P(2000, -300), 'catcher', fs=4.8)
    leader(ax, v.P(*pp), v.P(1350, -300), 'PDV probe', fs=4.8, ha='right')
    ax.text(*(v.P(650, TY0) + (2.5, -3.2)), 'PVDF coax feedthrough', fontsize=4.6)
    ax.text(*(v.P(*Pend) + (2.0, -3.6)), 'E (exit, φ 40°)', fontsize=4.6, color=RD)
    ax.text(*(v.P(0, -2000) + (-1.5, -3.6)), 'T', fontsize=5.2, color=RD, weight='bold')
    dim(ax, v.P(TX0, TY0), v.P(TX1, TY0), -7, '3 600 internal', fs=4.8, mode='h')
    dim(ax, v.P(TX1, TY0), v.P(TX1, TY1), 14, '2 000', fs=4.8, mode='v')
    t_ = v.P(0, -2000); ax.annotate('', xy=t_ + (0, 9), xytext=t_ + (0, 2.5), arrowprops=dict(arrowstyle='-|>', lw=0.4, mutation_scale=5)); ax.text(t_[0] + 1, t_[1] + 8, 'to O (2 000)', fontsize=4.4)

    rows = [('ITEM', 'REQUIREMENT (T1)'),
            ('Gun', 'two-stage light-gas gun, smooth launch tube bore ≥ Ø38; shots at 3.0 and 6.28 km/s ±2 %; package 26–31 g (coupon 8.8 g + sabot 17.6–22.4 g)'),
            ('Energy', f"muzzle KE 0.12–0.14 MJ (3.0 km/s), 0.52–0.62 MJ (6.28 km/s); class ref.: SwRI large gun 7 km/s top, 0.5 kg at 3 km/s"),
            ('Sabot', 'blast tank with stripper plate (Ø30 aperture), sabot catch; coupon attitude checked by FX1/FX2'),
            ('Tank', 'internal ≥ 3.6 × 2.0 × 1.2 m, ≤ 1 mbar (at 1 atm drag would cost ~0.3 % of speed per metre); entry axis 570 mm off the tank centre-line'),
            ('Floor', f'fixture {MT:.0f} kg on a 0.34 × 1.9 m footprint + catcher ≈ 400 kg; shot impulse ≈ 40 N·s'),
            ('Ports', '4 X-ray ports (2 orthogonal pairs), 2 optical windows (HSC-1, HSC-2), 1 fibre feedthrough (PDV, 4 fibres), 1 coax feedthrough (≥ 12), 2 thermocouples'),
            ('Diagnostics', 'laser screens LS1/LS2 (0.5 m), 4 flash X-ray heads, 2 high-speed cameras ≥ 5 Mfps, 1550 nm PDV, 9 PVDF gauges, 16 digitizer channels — see PTP-105'),
            ('Rate', '≈ 1 shot per day (liner, lips, witness plates and gauges replaced each shot)'),
            ('Matrix', '2 speeds × 3 gaps × 2 liners × 2 repeats = 24 shots, plus 4 free-flight calibration shots (no track)')]
    table(ax, 232, 196, [24, 150], rows, fs=5.0, title='FACILITY AND RANGE REQUIREMENTS')
    notes(ax, 24, 86, 200, [
        'Elevation is schematic: segment lengths are indicative (≈1:125) and set by the host facility; diameters are not to scale. The tank plan is to scale.',
        'Coordinates: origin O at the track centre; wall radius R 2000 to the liner face; x along the shot line; tangent point T at x = 0. The shot line is the path of the coupon’s outer face, offset g = 1, 5 or 20 mm inside the wall at T (PTP-103).',
        'Entry speed: LS1–LS2 time of flight plus FX1/FX2 (also attitude). Exit speed: PDV along the exit tangent (5° probe) plus FX3/FX4. Friction μ = −ln(v_out/v_in)/θ_contact.',
        'Cameras view the channel through the transparent PC witness plates (PTP-102 item 6).',
        'Hazards: hypervelocity fragments and metal vapour, flash X-ray, high voltage, high-pressure light gas. Follow host-range procedures; no entry while the gun is armed.'], fs=5.1)
    save(fig, 'PTP-101')

# =====================================================================================  PTP-102
if not ONLY or '102' in ONLY:
    fig, ax = sheet('T1 · CURVED TRACK FIXTURE R 2000 · ASSEMBLY', 'PTP-102', 3, '1:20', TEST)
    label(ax, 24, 277, 'PLAN', 'from +Z · shot along +x · coupon shown at g = 5 · items 10–11 under the plates')
    v = View(ax, PJ['plan'], 20, 132, 222); v.mc = np.array([973.0, -1430.0])
    v.draw(hidden=True, lw=0.5)
    chain(ax, shot_path(v, 5, s_end=950)[1:], lw=0.6); chain(ax, [v.P(-700, SY(5)), v.P(geo[5]['x_imp'], SY(5))], lw=0.6)
    a_ = v.P(-700, SY(5)); ax.annotate('', xy=a_ + (9, 0), xytext=a_, arrowprops=dict(arrowstyle='-|>', color=RD, lw=0.8, mutation_scale=7)); ax.text(a_[0], a_[1] + 2.2, 'SHOT', fontsize=5.2, color=RD, weight='bold')
    for ph in D['STN']:
        q1, q2, q3 = v.P(*P_arc(ph, 2185)), v.P(*P_arc(ph, 2245)), v.P(*P_arc(ph, 2330))
        ax.plot([q1[0], q2[0]], [q1[1], q2[1]], 'k', lw=0.3); ax.text(*q3, f'{ph}°', fontsize=4.3, ha='center', va='center', rotation=ph)
    ax.text(*v.P(*P_arc(-6, 2380)), 'φ', fontsize=5.5, ha='center', va='center', style='italic')
    section_arrows(ax, v.P(*P_arc(20, 1800)), v.P(*P_arc(20, 2230)), 'A', d=4)
    t_ = v.P(0, -2000); ax.plot(*t_, 'o', ms=2, color=RD); ax.text(t_[0] - 1, t_[1] + 1.8, 'T', fontsize=5.5, color=RD, weight='bold')
    E_ = v.P(*Pend); ax.plot(*E_, 'o', ms=2, color=RD); ax.text(E_[0] - 4.5, E_[1] + 1.6, 'E', fontsize=5.5, color=RD, weight='bold')
    dim(ax, v.P(*Pend), v.P(*along(950)), -5, '950 to catcher face', fs=4.6)
    leader(ax, v.P(*P_arc(33, 2000)), v.P(1180, -1180), 'R 2000 to liner face (wall)\ncentre O 2000 north of T', fs=4.7, ha='right')
    leader(ax, v.P(*along(380, 25)), v.P(2150, -1250), 'exit tangent at φ = 40°\nPDV at 700, 5° to the line', fs=4.7)
    items = [(1, P_arc(12, 2090), P_arc(12, 2530)), (2, P_arc(31, 2003), P_arc(36, 1690)), (3, P_arc(24, 1992), P_arc(26, 1690)),
             (5, P_arc(5, 2006), P_arc(1, 2530)), (6, P_arc(17, 1898), P_arc(17, 1690)), (7, P_arc(80 / 3, 1885), P_arc(21, 1640)),
             (8, P_arc(42.5, 2120), P_arc(43, 2560)), (9, P_arc(43.6, 2170), P_arc(39.5, 2600)), (10, np.array([175.0, -2240.0]), np.array([-180.0, -2330.0])),
             (11, np.array([175.0, -1742.0]), np.array([-30.0, -1600.0])), (12, along(1050), along(1050, 330)), (13, pp, pp + np.array([-330.0, 160.0])),
             (14, np.array([-150.0, SY(5) + 1.0]), np.array([-330.0, -1780.0]))]
    for n, tg, at in items: balloon(ax, v.P(*tg), v.P(*at), n)
    img = Image.open(f'{OUT}/renders/T1_fixture_iso.png')
    put_image(ax, img, 232, 182, 174, 96, title='ISOMETRIC · fixture without catcher (view from inside the arc)')
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'MATERIAL', 'kg (CAD)'),
            ('1', '3', 'Backing block, 15° segment, R2006–2106 × 160, gauge pockets', '4340/EN24 Q&T', f"{M['BLOCK 1']:.1f} ea"),
            ('2', '1/shot', 'Test liner 45°, 6 thick × 60 (the wall under test)', 'A: 4340 · B: ablator on stator metal', f"{M['LINER']:.1f}"),
            ('3', '1/shot', 'Guide lip, upper, 15 deep × 19.5; channel 21.0', '4340', f"{M['LIP UPPER']:.1f}"),
            ('4', '1/shot', 'Guide lip, lower (mirror of 3)', '4340', f"{M['LIP LOWER']:.1f}"),
            ('5', '9/shot', 'PVDF stress gauge, 25 µm, φ 0–40° every 5°', 'PVDF film', '—'),
            ('6', '3/shot', 'Witness plate R1900, 3 × 120 high (cameras see through)', 'polycarbonate', f"{M['WITNESS 1']:.2f} ea"),
            ('7', '4', 'Witness post Ø16 × 140', 'steel', f"{M['POST 1']:.2f} ea"),
            ('8', '1', 'Base plate, sector, 60 thick', 'S355', f"{M['BASE PLATE']:.0f}"),
            ('9', '1', 'Slide plate, sector, 40 thick', 'S355', f"{M['SLIDE PLATE']:.0f}"),
            ('10', '2', 'Linear rail + carriages along Y (sets gap g)', 'std', '—'),
            ('11', '2', 'Shim pack 1 / 5 / 20 + push-pull screws', 'ground steel', '—'),
            ('12', '1', 'Catcher: 50 honeycomb + PC face, 350 steel box, sand fill', '—', '≈ 400'),
            ('13', '1', 'PDV collimator Ø25 on post, 5° to exit line', '—', '—'),
            ('14', '1/shot', 'Coupon 25 × 20 × 2.2 (PTP-104)', 'tape stack', '0.0088'),
            ('', '', 'Fixture items 1–9 (CAD)', '', f'{MT:.0f}')]
    table(ax, 232, 177, [8, 11, 83, 46, 26], rows, fs=4.7, title=None)
    ve = View(ax, PJ['elev_s'], 20, 132, 160); ve.mc = np.array([973.0, -20.0]); ve.draw(hidden=False, lw=0.45)
    label(ax, 24, 177, 'ELEVATION', 'from −y (outside of the arc) · catcher beyond')
    dim(ax, ve.P(-300, -80), ve.P(-300, 80), -4, '160', fs=4.4, mode='v'); dim(ax, ve.P(-300, -215), ve.P(-300, -80), -4, '135', fs=4.4, mode='v')
    notes(ax, 24, 140, 200, [
        'Track: concave wall R 2000 (liner face), 45° arc from φ = −5° (lead-in) to +40°. The coupon meets the wall at θ = 1.8 / 4.0 / 8.1° (g = 1 / 5 / 20) and slides to the exit E, a contact arc of 38.2 / 36.0 / 31.9°.',
        'Gap g is set by sliding the whole fixture along Y on the rails (10) against the shim pack (11). Survey g with a laser tracker to ±0.1 mm before each shot; record it on the shot sheet.',
        'Consumables per shot: liner 2, lips 3–4, gauges 5, witness plates 6. Re-use blocks 1 unless gouged deeper than 0.5 mm (then re-skim and re-survey R).',
        'Fasteners stay outside the coupon band (|z| > 12): M8 countersunk for liner and lips, flush to −0.05; M16 for blocks to base plate.',
        f'Fixture mass {MT:.0f} kg (items 1–9). Wall load at 6.28 km/s: N ≈ 174 kN on the coupon face (≈ 350 MPa) for ≈ 0.2 ms; shot impulse ≈ 40 N·s, recoil < 0.1 m/s.',
        'Witness plates are polycarbonate so the cameras see the channel; survey craters after each shot for inward debris and its energy.',
        'Optional 90° track: add three block segments (blocks 4–6) and extend the base and slide plates.'], fs=5.0)
    put_image(ax, Image.open(f'{OUT}/renders/T1_assembly_iso.png'), 232, 66, 174, 50, title='ASSEMBLY WITH CATCHER')
    save(fig, 'PTP-102')

# =====================================================================================  PTP-103
def draw_sect(ax, polys, den, mc, c, clip=None, lw=0.5):
    cols = {'BLOCK': ('#9aa0a8', '////'), 'LINER': ('#5d4a42', '\\\\\\\\'), 'LIP': ('#c4c8ce', '\\\\\\\\'), 'PVDF': ('#f2cc33', ''),
            'WITNESS': ('#dcecf5', '....'), 'BASE': ('#b8bcc2', '////'), 'SLIDE': ('#d4d7db', '\\\\\\\\'), 'POST': ('#9aa0a8', 'xx'),
            'SABOT': ('#f1ecd2', '////'), 'COUPON': ('#d65c4a', 'xxxx')}
    k = 1.0 / den; cp = Rectangle((clip[0], clip[1]), clip[2] - clip[0], clip[3] - clip[1], transform=ax.transData) if clip else None
    for name, (outer, holes) in polys:
        fc, h = next(v for kk, v in cols.items() if name.startswith(kk))
        verts, codes = [], []
        for w in [outer] + holes:
            q = c + (np.asarray(w) - mc) * k; verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
        pa = ax.add_patch(PathPatch(Path(verts, codes), facecolor=fc, edgecolor='k', lw=lw, hatch=h))
        if cp is not None: pa.set_clip_path(cp)
    return lambda u, vv: c + (np.array([u, vv]) - mc) * k

if not ONLY or '103' in ONLY:
    fig, ax = sheet('T1 · TRACK SECTION A–A, CHANNEL DETAIL, ENTRY GEOMETRY', 'PTP-103', 4, '1:5 · 2:1 · 5:1', TEST)
    SP = PJ['secAA_polys']
    label(ax, 24, 277, 'SECTION A–A  1:5', 'at φ = 20°, looking downstream · removed section')
    PA = draw_sect(ax, SP, 5, np.array([2010.0, -50.0]), np.array([66.0, 238.0]))
    ax.plot(*zip(PA(2000, -32), PA(2000, 32)), color='k', lw=0)  # anchor
    dim(ax, PA(1840, -180), PA(2180, -180), -5, '340', fs=4.6, mode='h')
    dim(ax, PA(2106, -80), PA(2106, 80), 4, '160', fs=4.6, mode='v')
    dim(ax, PA(1897, -60), PA(1897, 60), -4, '120', fs=4.6, mode='v')
    leader(ax, PA(1898, 40), PA(1800, 75), 'R1900 witness (6)', fs=4.5, ha='left')
    leader(ax, PA(2056, 70), PA(2120, 105), 'block (1)', fs=4.5)
    leader(ax, PA(2000, -130), PA(1830, -115), 'base (8)', fs=4.5, ha='right')
    leader(ax, PA(2100, -165), PA(2220, -150), 'slide (9)', fs=4.5)
    bc = PA(1995, 0); ax.add_patch(Circle(bc, 5.2, fill=False, lw=0.5, ls=(0, (3, 1.5)))); ax.text(bc[0] + 4.4, bc[1] + 5.4, 'B', fontsize=7, weight='bold')
    ax.text(*PA(2240, -45), 'O ←\n(axis)', fontsize=4.4, ha='left', va='center') if False else None
    ax.annotate('', xy=PA(1840, 95), xytext=PA(1960, 95), arrowprops=dict(arrowstyle='-|>', lw=0.4, mutation_scale=5)); ax.text(*(PA(1840, 95) + (0, 2.2)), 'to O', fontsize=4.5)

    label(ax, 118, 277, 'DETAIL B  2:1', 'channel at φ = 20° · coupon drawn sliding on the liner')
    clipB = (118, 128, 226, 268)
    PB = draw_sect(ax, SP, 0.5, np.array([1996.0, 10.0]), np.array([172.0, 198.0]), clip=clipB, lw=0.6)
    ax.add_patch(Rectangle(clipB[:2], clipB[2] - clipB[0], clipB[3] - clipB[1], fill=False, lw=0.3, ls=(0, (4, 2))))
    c0, c1 = PB(1997.8, -10), PB(2000, 10); ax.add_patch(Rectangle(c0, *(c1 - c0), fc='#d65c4a', ec='k', lw=0.6, hatch='xxxx', zorder=4))
    dim(ax, PB(1985, 10.5), PB(1985, -10.5), -6, '21.0 channel', fs=4.6, mode='v')
    dim(ax, PB(1985, 30), PB(2000, 30), 4, '15.0', fs=4.6, mode='h')
    dim(ax, PB(2000, -12), PB(2006, -12), 0, '', fs=4.4, mode='h') if False else None
    dim(ax, PB(2000, 32), PB(2006, 32), 9, '6.0 liner', fs=4.6, mode='h')
    dim(ax, PB(1997.8, 10), PB(2000, 10), 13, '2.2', fs=4.6, mode='h')
    leader(ax, PB(1999, 10.25), PB(1975, 16), '0.5 clearance (each side)', fs=4.6, ha='left')
    leader(ax, PB(1999, 0), PB(1975, -6), 'coupon 2.2 × 20\n(tape stack, PTP-104)', fs=4.6, ha='left')
    leader(ax, PB(2006.25, -2), (200, 121), 'PVDF gauge 0.5 thick in 1.0 pocket (5)', fs=4.6, ha='center', va='top')
    leader(ax, PB(2003, 26), PB(1975, 31), 'liner (2)', fs=4.6, ha='left')
    leader(ax, PB(1992, 22), PB(1975, 25), 'lip (3)', fs=4.6, ha='left')
    ax.plot(*zip(PB(1975, 0), PB(2012, 0)), color='k', lw=0.25, ls=(0, (12, 2, 2, 2)))

    label(ax, 24, 177, 'DETAIL C  5:1', 'PVDF gauge station, liner removed (view on block face)')
    cx, cy = 66, 150
    ax.add_patch(Rectangle((cx - 30, cy - 24), 60, 44, fc='#9aa0a8', ec='k', lw=0.5, hatch='////'))
    ax.add_patch(Rectangle((cx - 6 * 2.5 / 2.5 * 2.5 / 2.5 * 2.5, cy - 15), 30, 30, fc='white', ec='k', lw=0.6))
    ax.add_patch(Rectangle((cx - 12.5, cy - 12.5), 25, 25, fc='#f2cc33', ec='k', lw=0.5))
    ax.add_patch(Rectangle((cx - 4, cy - 4), 8, 8, fc='#e0a800', ec='k', lw=0.4))
    ax.add_patch(Rectangle((cx + 12.5, cy - 2.5), 17.5, 5, fc='white', ec='k', lw=0.4))
    dim(ax, (cx - 15, cy + 15), (cx + 15, cy + 15), 4, '12 pocket', fs=4.5, mode='h')
    dim(ax, (cx - 12.5, cy - 12.5), (cx + 12.5, cy - 12.5), -14, '10 gauge', fs=4.5, mode='h')
    leader(ax, (cx - 2, cy - 2), (cx - 42, cy - 10), 'active\n3 × 3 (typ.)', fs=4.5)
    leader(ax, (cx + 22, cy), (cx + 14, cy + 22), 'lead slot 2 wide × 1 deep → back face', fs=4.5)
    ax.text(cx, cy - 33, 'pocket 1.0 deep · gauge between 25 µm PTFE films · epoxy 10 µm', fontsize=4.5, ha='center')

    label(ax, 24, 108, 'ENTRY GEOMETRY', 'not to scale: x at 0.42:1, radial direction at 1.8:1 · wall R, shot line at R − g')
    ox, oy, kx, ky = 92, 30, 0.42, 1.8
    xs = np.linspace(-150, 320, 200); yw = xs ** 2 / (2 * R)
    ax.plot(ox + xs * kx, oy + (yw - 0) * ky, color='k', lw=1.1)
    ax.fill_between(ox + xs * kx, oy + yw * ky, oy + yw * ky - 4, color='0.55', hatch='////', lw=0)
    for g, col in ((5, RD), (20, BL)):
        th = geo[g]['theta']; xi = geo[g]['x_imp']
        ax.plot([ox - 150 * kx, ox + xi * kx], [oy + g * ky, oy + g * ky], color=col, lw=0.8)
        ax.plot(ox + xi * kx, oy + g * ky, 'o', ms=2.2, color=col)
        ax.text(ox + xi * kx - 2, oy + g * ky + 3.0, f'I (g = {g}): θ = {th:.1f}°, x = {xi:.0f}', fontsize=4.7, color=col, ha='right')
    dim(ax, (ox, oy), (ox, oy + 20 * ky), -8, 'g', fs=5, mode='v')
    ax.plot(ox, oy, 'o', ms=2, color='k'); ax.text(ox - 1, oy - 4, 'T', fontsize=5.5, weight='bold')
    ax.text(ox + 40 * kx, oy - 7.5, 'wall (liner face), radius R about O', fontsize=4.7)
    ax.text(ox - 148 * kx, oy + 20 * ky + 3, 'shot line (coupon outer face) →', fontsize=4.7, color=BL)
    eqs = ['cos θ = (R − g) / R',
           'radial impact  v_r = v sin θ',
           'impact point  x = R sin θ',
           'contact arc  θ_c = 40° − θ',
           'capstan  v_out = v_in · exp(−μ θ_c)',
           'μ = ln(v_in / v_out) / θ_c',
           'wall load  N = m v² / R']
    ax.text(24, 92, '\n'.join(eqs), fontsize=4.9, va='top', family=MONO, linespacing=1.5)

    rows = [('g mm', 'θ °', 'x_imp', 'v_r 3.0', 'v_r 6.28', 'θ_c °', 'μ 0.1', 'μ 0.3', 'μ 0.5')]
    for g in (1, 5, 20):
        r = geo[g]
        rows.append((g, f"{r['theta']:.2f}", f"{r['x_imp']:.0f}", f"{r['vr']['3000'] if '3000' in r['vr'] else r['vr'][3000]:.0f}",
                     f"{r['vr'][6280]:.0f}", f"{r['arc']:.1f}", *(f"{r['ratio'][mu]:.3f}" for mu in (0.1, 0.3, 0.5))))
    yb = table(ax, 232, 279, [17, 17, 18, 21, 21, 18, 20, 21, 21], rows, fs=5.0, title='ENTRY CASES (wall R 2000)', aligns=['c'] * 9)
    ax.text(232, yb - 2.5, 'v_r in m/s at 3.0 / 6.28 km/s.  μ columns: v_out / v_in over θ_c.  I.30 used the line radius (882 m/s at g = 20); the drawing uses\nthe wall radius (886 m/s), < 0.5 % apart.  1 % velocimetry resolves μ to about ±0.027.', fontsize=4.5, va='top', linespacing=1.3)
    put_image(ax, Image.open(f'{OUT}/renders/T1_entry_closeup.png'), 232, 150, 174, 84, title='ENTRY REGION · witness plates and posts removed')
    notes(ax, 232, 145, 174, [
        'Section A–A is a removed section at φ = 20°. Background edges of the curved track are omitted.',
        'Channel height 21.0 +0.1/−0 between lips; lip faces parallel within 0.05 over the arc; lip leading ends chamfered 2 × 30° at φ = −5°.',
        'Liner face: profile of R 2000 within 0.1 over 45°; Ra ≤ 0.8 µm (steel liner) or as supplied (ablator liner); record the surface before each shot.',
        'Gauges: calibrate PVDF sensitivity in situ with a reference gas-gun or drop-weight shot; record each gauge’s lot and active area.'], fs=4.9)
    save(fig, 'PTP-103')

# =====================================================================================  PTP-104
if not ONLY or '104' in ONLY:
    fig, ax = sheet('T1 · COUPON AND SEPARATING SABOT · DETAILS', 'PTP-104', 5, '2:1', TEST)
    C3 = PJ['coupon3']
    label(ax, 24, 277, 'COUPON  2:1', 'cut from the rotor tape stack; flown along its 25 mm length')
    vf = View(ax, C3['front'], 0.5, 34, 238); vf.draw(); vs = View(ax, C3['side'], 0.5, 78, 238); vs.draw(); vt = View(ax, C3['top'], 0.5, 78, 205); vt.draw()
    ax.text(34, 213, 'FRONT (from +x)', fontsize=4.8, ha='center'); ax.text(92, 214 - 30 + 18, '', fontsize=1)
    ax.text(78, 261, 'SIDE (from −y)', fontsize=4.8, ha='center'); ax.text(78, 197, 'TOP (from +z)', fontsize=4.8, ha='center')
    dim(ax, vs.P(-12.5, -10), vs.P(12.5, -10), -5, '25.0 ±0.05', fs=4.6, mode='h')
    dim(ax, vs.P(12.5, -10), vs.P(12.5, 10), 5, '20.0 ±0.05', fs=4.6, mode='v')
    dim(ax, vf.P(-1.1, 10), vf.P(1.1, 10), 4, '2.2 ±0.05', fs=4.6, mode='h')
    ax.annotate('', xy=vs.P(-4, 13) + (14, 0), xytext=vs.P(-4, 13), arrowprops=dict(arrowstyle='-|>', color=RD, lw=0.7, mutation_scale=6)); ax.text(*(vs.P(-4, 13) + (-1, 0)), 'flight', fontsize=4.6, color=RD, ha='right', va='center')
    leader(ax, vf.P(1.1, -6), (26, 196), 'outer face → wall (+y)\ntape planes ∥ 25 × 20 face', fs=4.6)

    label(ax, 124, 277, 'SABOT  2:1', '4 petals, split to a 2 mm rear web; pocket open to the front')
    vsf = View(ax, PJ['cs_front'], 0.5, 166, 228); vsf.draw()
    ax.text(166, 176, 'FRONT VIEW (from +x) · holes hidden', fontsize=4.8, ha='center', va='top')
    dim(ax, vsf.P(-19, -19), vsf.P(19, -19), -6, 'Ø38.0 (to suit bore, +0.05 interference)', fs=4.4, mode='h')
    dim(ax, vsf.P(-1.15, 12), vsf.P(1.15, 12), 0, '', fs=1) if False else None
    leader(ax, vsf.P(0, 10.1), (182, 268), 'pocket 2.3 × 20.2 × 25.2 deep', fs=4.6)
    leader(ax, vsf.P(19, 0), (195, 255), 'roll-index flat at +y (wall side)', fs=4.6)
    leader(ax, vsf.P(-8, 0), (130, 266), 'slits 0.6 wide, front to 2 mm web', fs=4.6, ha='left')
    leader(ax, vsf.P(-7.78, -7.78), (128, 196), '4 × Ø12 × 24 deep from rear,\non PCD 22 at 45°', fs=4.6, ha='left')
    section_arrows(ax, vsf.P(-22, 7.78), vsf.P(22, 7.78), 'A', d=3.5)
    label(ax, 214, 277, 'SECTION A–A  2:1', 'plane z = +7.78 through two holes, from +z')
    SS = PJ['sab_sec_polys']
    PS = draw_sect(ax, SS, 0.5, np.array([-1.4, 0.0]), np.array([262.0, 236.0]), lw=0.5)
    dim(ax, PS(-15.4, -19), PS(12.6, -19), -6, '28.0', fs=4.6, mode='h')
    dim(ax, PS(-12.6, 13.78), PS(12.6, 13.78), 0.0, '', fs=1) if False else None
    dim(ax, PS(-12.6, -19), PS(12.6, -19), -12, '25.2 pocket', fs=4.6, mode='h')
    dim(ax, PS(-15.4, -19), PS(-12.6, -19), -18, '2.8 web', fs=4.6, tshift=-7, mode='h')
    dim(ax, PS(-15.4, 13.78), PS(8.6, 13.78), 0, '', fs=1) if False else None
    leader(ax, PS(0, 7.78), (296, 262), 'Ø12 × 24 hole', fs=4.6)
    leader(ax, PS(0, 0.5), (296, 250), 'coupon in pocket,\n0.1 recessed', fs=4.6)
    put_image(ax, Image.open(f'{OUT}/renders/T1_coupon_sabot_exploded.png'), 312, 186, 94, 86, title='EXPLODED')
    sg = NUM['sabot_g']; pk = NUM['pkg_MJ']; cg = NUM['coupon_g']
    rows = [('QUANTITY', 'UHMW-PE sabot', 'PC sabot'),
            ('coupon (ρ 8.0 assumed)', f'{cg:.1f} g', f'{cg:.1f} g'),
            ('sabot (CAD volume)', f"{sg['UHMW-PE 0.94']:.1f} g", f"{sg['PC 1.20']:.1f} g"),
            ('launch package', f"{cg + sg['UHMW-PE 0.94']:.1f} g", f"{cg + sg['PC 1.20']:.1f} g"),
            ('KE at 3.0 km/s', f"{pk['UHMW-PE 0.94'][3000]:.3f} MJ", f"{pk['PC 1.20'][3000]:.3f} MJ"),
            ('KE at 6.28 km/s', f"{pk['UHMW-PE 0.94'][6280]:.3f} MJ", f"{pk['PC 1.20'][6280]:.3f} MJ"),
            ('wall load N = m v²/R (3.0 / 6.28)', f"{NUM['N_kN'][3000]:.1f} / {NUM['N_kN'][6280]:.0f} kN", '(coupon only)'),
            ('face pressure (25 × 20)', f"{NUM['p_MPa'][3000]:.0f} / {NUM['p_MPa'][6280]:.0f} MPa", 'I.34: 80 / 351 at 8.9 g')]
    table(ax, 232, 168, [70, 52, 52], rows, fs=5.0, title='MASSES AND ENERGIES', aligns=['l', 'c', 'c'])
    notes(ax, 24, 176, 200, [
        'Coupon: wire-EDM cut from the rotor’s own tape stack (stack thickness 2.2 radial, tape planes parallel to the 25 × 20 face), so it carries the rotor’s line density λ/h. Deburr, weigh to ±0.01 g and measure; the plan value 8.9 g (I.34) assumed 8,000 kg/m³.',
        'Mark the outer (wall-side) face. Load with that face toward +y, aligned to the sabot roll-index flat and the launch-tube index mark; the coupon must reach the track with its broad face on the wall.',
        'Sabot: UHMW-PE (or PC) four-petal sabot; 0.6 mm slits from the front face leave a 2 mm hinge web. Petals open on muzzle exit and are stripped by the Ø30 plate; only the coupon enters the flight tube.',
        'Attitude: fragment simulants fly with 4.7–5.5° mean pitch/yaw end-on (OSTI 2004149). Record attitude at FX1/FX2 every shot; reject shots with yaw > 10° from the analysis set.',
        'Calibration: 4 free-flight shots without the track to measure sabot separation, coupon attitude and velocity scatter at both speeds.'], fs=5.0)
    rows2 = [('SPEC', 'VALUE'), ('dimensions', '25.0 × 20.0 × 2.2 ±0.05'), ('flatness, wall face', '0.03'), ('edges', 'deburred, no radius > 0.1'),
             ('mass', 'record ±0.01 g'), ('stack bond', 'as rotor (solder or epoxy)')]
    table(ax, 24, 138, [40, 62], rows2, fs=5.0, title='COUPON SPECIFICATION')
    put_image(ax, Image.open(f'{OUT}/renders/T1_coupon_sabot_iso.png'), 134, 70, 92, 66, title='ASSEMBLED')
    save(fig, 'PTP-104')

# =====================================================================================  PTP-105
if not ONLY or '105' in ONLY:
    fig, ax = sheet('T1 · INSTRUMENTATION, TRIGGERING AND TIMING', 'PTP-105', 6, 'NTS', TEST)
    label(ax, 24, 281, 'BLOCK DIAGRAM', 'facility items dashed · velocity-adaptive triggering from the laser screens')
    H = 21
    g1 = blk(ax, 24, 248, 32, H, 'GUN CONTROL', ['fire command', '(facility)'], dash=True)
    g2 = blk(ax, 62, 248, 46, H, 'TWO-STAGE LGG', ['breech · pump tube · HP section · launch tube Ø ≥ 38'], dash=True)
    g3 = blk(ax, 114, 248, 32, H, 'BLAST TANK', ['sabot stripper', 'Ø30'], dash=True)
    g4 = blk(ax, 152, 248, 32, H, 'FLIGHT TUBE', ['LS1 · LS2', '0.5 m'], dash=True)
    g5 = blk(ax, 190, 248, 106, H, 'TARGET TANK ≤ 1 mbar', ['track fixture: 9 PVDF gauges · PC witness · catcher', 'PDV probe · 4 FX ports · 2 windows'], fc='#fff8e6')
    g6 = blk(ax, 302, 248, 40, H, 'VACUUM PUMPS', ['roots + rotary', 'gauges → PLC'], dash=True)
    g7 = blk(ax, 348, 248, 58, H, 'SAFETY PLC', ['doors · vacuum · FX HV · gas', '→ firing permissive'])
    for a_, b_ in ((g1, g2), (g2, g3), (g3, g4), (g4, g5)): route(ax, [a_.p('R'), b_.p('L')], kind='mech')
    route(ax, [g6.p('L'), g5.p('R')], kind='vacuum')
    route(ax, [g7.p('T', 0.5), (377, 274), (40, 274), g1.p('T')], kind='signal', label='firing permissive', li=1, loff=(0, 1.3))
    f1 = blk(ax, 140, 200, 44, 28, 'LASER SCREENS', ['2 × diode sheet + photoreceiver', 'rise < 20 ns'])
    f2 = blk(ax, 190, 200, 38, 28, 'FX HEADS ×4', ['2 orthogonal pairs', 'entry + exit', 'image plates'])
    f3 = blk(ax, 232, 200, 40, 28, 'HIGH-SPEED CAMERAS ×2', ['≥ 5 Mfps, ≥ 128 frames', '+ pulsed LED / flash'])
    f4 = blk(ax, 276, 200, 52, 28, 'PDV OPTICS', ['1550 nm seed + EDFA 2 W', 'circulators · LO upshift', 'photoreceivers ≥ 20 GHz'])
    f5 = blk(ax, 334, 200, 72, 28, 'PVDF CONDITIONING ×9', ['current mode: 0.1 Ω CVR, or charge amplifiers', 'in shielded box at the tank'])
    route(ax, [g4.p('B'), f1.p('T', 0.6)], kind='optical', arrow=False, both=False)
    route(ax, [(g5.x + 12, g5.y), (g5.x + 12, 236), (f2.x + 19, 236), f2.p('T')], kind='optical', arrow=False)
    route(ax, [(g5.x + 46, g5.y), f3.p('T')], kind='optical', arrow=False, label='windows', li=0, loff=(6, 0))
    route(ax, [(g5.x + 86, g5.y), (g5.x + 86, 238), (f4.x + 26, 238), f4.p('T')], kind='optical', both=True, arrow=True, label='fibre', li=1, loff=(0, 1.2))
    route(ax, [(g5.x + 100, g5.y), (g5.x + 100, 242), (f5.x + 36, 242), f5.p('T')], kind='rf', label='PVDF coax', li=1, loff=(0, 1.3))
    r1 = blk(ax, 24, 140, 46, 34, 'TRIGGER COMPUTER', ['velocity-adaptive delays from LS1–LS2', '6 outputs, jitter < 1 ns'], fc='#eaf1fb')
    r2 = blk(ax, 76, 140, 34, 34, 'DELAY GEN.', ['DG645 class', 'fixed-delay backup'], fc='#eaf1fb')
    r3 = blk(ax, 116, 140, 34, 34, 'FX PULSERS ×4', ['450 kV class', '20–35 ns pulses'])
    r4 = blk(ax, 156, 140, 32, 34, 'TIME-INTERVAL COUNTER', ['LS1→LS2', '≤ 1 ns'])
    r5 = blk(ax, 194, 140, 44, 34, 'PDV DIGITIZER', ['≥ 16 GHz, ≥ 50 GS/s', '4 ch, 1 ms record'])
    r6 = blk(ax, 244, 140, 52, 34, 'TRANSIENT DIGITIZERS', ['2 × 8 ch, 1 GS/s, 12 bit', 'PVDF ×9, LS ×2, FX monitors'])
    r7 = blk(ax, 302, 140, 34, 34, '10 MHz Rb REF.', ['distribution', 'amp ×8'], fc='#eaf1fb')
    r8 = blk(ax, 342, 140, 64, 34, 'DAQ PC + SHOT DATABASE', ['velocities, μ, line load vs time', 'images, survey, gauge lots'])
    route(ax, [f1.p('L', 0.5), (47, 214), r1.p('T')], kind='signal', label='LS pulses', li=0, loff=(-10, 1.3))
    route(ax, [f1.p('B', 0.75), (173, 186), (172, 186), r4.p('T', 0.5)], kind='signal')
    route(ax, [r1.p('R', 0.8), r2.p('L', 0.8)], kind='trigger')
    route(ax, [r1.p('B', 0.3), (37.8, 132), (133, 132), r3.p('B')], kind='trigger', label='FX fire', li=1, loff=(0, 1.2))
    route(ax, [r3.p('T'), (133, 190), (209, 190), f2.p('B')], kind='power', label='HV', li=1, loff=(-26, 1.2))
    route(ax, [r1.p('B', 0.6), (51.6, 128), (241, 128), (241, 190), (252, 190), f3.p('B', 0.5)], kind='trigger', label='camera start', li=1, loff=(30, 1.2))
    route(ax, [r1.p('B', 0.9), (65.4, 124), (224.8, 124), r5.p('B', 0.7)], kind='trigger', label='arm', li=1, loff=(38, 1.2))
    route(ax, [(224.8, 124), (270, 124), r6.p('B')], kind='trigger')
    route(ax, [f4.p('B', 0.4), (296.8, 192), (216, 192), r5.p('T')], kind='signal', label='beat signals', li=1, loff=(0, 1.2))
    route(ax, [f5.p('B', 0.5), (370, 185), (285, 185), r6.p('T', 0.8)], kind='signal', label='gauge signals', li=1, loff=(0, 1.2))
    route(ax, [r7.p('B'), (319, 120), (100, 120), r2.p('B', 0.7)], kind='trigger', arrow=True)
    for xx in (172, 216, 270): route(ax, [(xx, 120), (xx, 140)], kind='trigger')
    route(ax, [(319, 120), (319, 116), (47, 116), r1.p('B', 0.5)], kind='trigger')
    route(ax, [r6.p('R'), r7.p('L')], kind='data', arrow=False) if False else None
    route(ax, [r5.p('T', 0.2), (202.8, 180), (374, 180), r8.p('T')], kind='data', label='data', li=1, loff=(60, 1.2))
    route(ax, [r6.p('T', 0.2), (254.4, 180)], kind='data', arrow=False)
    route(ax, [r4.p('T', 0.2), (162.4, 180), (202.8, 180)], kind='data', arrow=False)
    route(ax, [f3.p('R', 0.15), (275, 204), (275, 182), (374, 182)], kind='data', arrow=False) if False else None
    ax.text(319, 113.5, '10 MHz to every timing unit', fontsize=4.4, ha='center', color=BL)
    sig_legend(ax, 24, 108, ['mech', 'signal', 'trigger', 'optical', 'rf', 'power', 'vacuum', 'data'], cols=4, colw=50)

    # timing chart
    label(ax, 24, 88, 'TIMING (g = 5, μ = 0.3 assumed)', 'times from LS1 · bars: record windows')
    th = geo[5]['theta']; xi = geo[5]['x_imp']; Lc = R * math.radians(40 - th); mu = 0.3
    def tl(v):
        t = {}; xL = -2200.0
        for nm, xx in (('LS1', -2200), ('LS2', -1700), ('FX1/2', -500), ('T', 0), ('I', xi)): t[nm] = (xx - xL) / v * 1e3
        t['E'] = t['I'] + R / (mu * v) * (math.exp(mu * Lc / R) - 1) * 1e3
        vE = v * math.exp(-mu * Lc / R); t['FX3/4'] = t['E'] + 200 / vE * 1e3; t['PDV end'] = t['E'] + 700 / vE * 1e3; t['C'] = t['E'] + 950 / vE * 1e3
        return t, vE
    x0p, kt = 40, 0.105
    ax.plot([x0p, x0p + 1700 * kt], [24, 24], 'k', lw=0.5)
    for tt in range(0, 1701, 200):
        ax.plot([x0p + tt * kt] * 2, [24, 25.2], 'k', lw=0.4); ax.text(x0p + tt * kt, 21.5, f'{tt}', fontsize=4.4, ha='center')
    ax.text(x0p + 1700 * kt + 2, 24, 'µs', fontsize=4.6, va='center')
    TT = {}
    for row, (v, yy) in enumerate(((6280, 62), (3000, 38))):
        t, vE = tl(v); TT[v] = (t, vE)
        ax.text(24, yy + 6.5, f'{v / 1000:.2f} km/s', fontsize=5.0, weight='bold', va='center')
        ax.text(24, yy + 2.0, f'exit {vE / 1000:.2f}', fontsize=4.4, va='center', color='0.3')
        ax.add_patch(Rectangle((x0p + t['T'] * kt - 10 * kt, yy - 5.5), (t['C'] - t['T'] + 30) * kt, 2.0, color='#c7d8f0', lw=0))
        ax.add_patch(Rectangle((x0p + t['E'] * kt, yy - 8.0), (t['PDV end'] - t['E']) * kt, 2.0, color='#f7d9a8', lw=0))
        ax.add_patch(Rectangle((x0p + t['LS2'] * kt, yy - 10.5), (t['C'] - t['LS2']) * kt, 2.0, color='#d9ecd9', lw=0))
        for k_, nm in enumerate(('LS1', 'LS2', 'FX1/2', 'T', 'I', 'E', 'FX3/4', 'C')):
            xx = x0p + t[nm] * kt; ax.plot([xx, xx], [yy - 2.5, yy + 3.5], color=RD if nm in ('T', 'I', 'E') else 'k', lw=0.6)
            ax.text(xx, yy + 4.6 + (2.6 if k_ % 2 else 0), f'{nm} {t[nm]:.0f}', fontsize=4.0, ha='center', color=RD if nm in ('T', 'I', 'E') else 'k')
    ax.text(x0p + 1080 * kt, 66, 'blue: camera record · orange: PDV exit window · green: PVDF/LS record', fontsize=4.4, ha='left')
    t6, vE6 = TT[6280]; t3, vE3 = TT[3000]
    rows = [('EVENT', 'POSITION', '6.28 km/s', '3.0 km/s', 'ACTION'),
            ('LS1, LS2', 'x −2200, −1700', f"0, {t6['LS2']:.0f} µs", f"0, {t3['LS2']:.0f} µs", 'start TIC; trigger computer computes v'),
            ('FX1/FX2', 'x −500', f"{t6['FX1/2']:.0f}", f"{t3['FX1/2']:.0f}", 'entry speed, attitude, sabot clear'),
            ('T → I', f'x 0 → {xi:.0f}', f"{t6['T']:.0f} → {t6['I']:.0f}", f"{t3['T']:.0f} → {t3['I']:.0f}", 'impact on wall at θ = 4.05°'),
            ('arc I → E', f'{Lc:.0f} mm on R', f"{t6['E'] - t6['I']:.0f}", f"{t3['E'] - t3['I']:.0f}", 'PVDF line load; cameras'),
            ('FX3/FX4', 'exit +200', f"{t6['FX3/4']:.0f}", f"{t3['FX3/4']:.0f}", 'exit speed, state (solid/melt)'),
            ('PDV', 'exit 0–700', f"{t6['E']:.0f}–{t6['PDV end']:.0f}", f"{t3['E']:.0f}–{t3['PDV end']:.0f}", f"beat ≈ {2 * vE6 / 1.55e-3 / 1e6:.1f} / {2 * vE3 / 1.55e-3 / 1e6:.1f} GHz"),
            ('catcher', 'exit +950', f"{t6['C']:.0f}", f"{t3['C']:.0f}", 'stop recording at +2 ms')]
    table(ax, 232, 104, [19, 31, 26, 26, 72], rows, fs=4.6, title='TRIGGER SETTINGS (computed, µs from LS1)')
    ax.text(232, 66.5, 'Delays scale as 1/v from the measured LS1–LS2 time; FX window ±12 µs at 6.28 km/s.', fontsize=4.5)
    save(fig, 'PTP-105')
print('ok')
