"""T3 sheets PTP-301..303 (reads out/t3.pkl)"""
import pickle, math, sys
import numpy as np
from PIL import Image
from ptp import *
RD, BL, OR, GR = '#c0392b', '#1f5fbf', '#d98200', '#2e7d32'
D = pickle.load(open(f'{OUT}/t3.pkl', 'rb')); PJ, NUM = D['PJ'], D['NUM']
TT = 'TEST T3 · B7 K₃C₆₀ FILM IN AN FEL CAVITY · V.9–V.13'
ONLY = sys.argv[1:]
C = NUM['cases']; thB = NUM['theta_B']; cB = NUM['cos_B']
cols = {'PLATE': ('#d6ecf8', ''), 'FILM': ('#202020', ''), 'CPW': ('#e6b84a', ''), 'FARADAY': ('#9fd49f', ''), 'FRAME': ('#e0a46e', '////'), 'CLAMP': ('#e0a46e', '\\\\\\\\'),
        'FIELD': ('#d58b52', 'xx'), 'RTD': ('#c8c8d0', ''), 'CERNOX': ('#333333', ''), 'RECEIVER': ('#e0a46e', '////'), 'CHAMBER': ('#c9ccd2', '////'),
        'BEAM PORT': ('#c9ccd2', '\\\\\\\\'), 'BEAM FLANGE': ('#c9ccd2', ''), 'GATE': ('#9aa6b8', ''), 'BEAM PIPE': ('#c9ccd2', ''), 'VIEWPORT': ('#c9ccd2', ''),
        'WINDOW': ('#d6ecf8', ''), 'TRANSFER': ('#c9ccd2', ''), 'LL': ('#9aa6b8', ''), 'LOAD': ('#c9ccd2', '')}
def dsect(ax, polys, den, mc, c, clip=None, lw=0.4):
    k = 1.0 / den; cp = Rectangle((clip[0], clip[1]), clip[2] - clip[0], clip[3] - clip[1], transform=ax.transData) if clip else None
    for name, (outer, holes) in polys:
        fc, h = next((v for kk, v in cols.items() if name.startswith(kk)), ('#dddddd', ''))
        verts, codes = [], []
        for w in [outer] + holes:
            q = c + (np.asarray(w) - mc) * k; verts += list(q) + [q[0]]; codes += [Path.MOVETO] + [Path.LINETO] * (len(q) - 1) + [Path.CLOSEPOLY]
        pa = ax.add_patch(PathPatch(Path(verts, codes), facecolor=fc, edgecolor='k', lw=lw, hatch=h))
        if cp is not None: pa.set_clip_path(cp)
    return lambda u, v: c + (np.array([u, v]) - mc) * k

# =====================================================================================  PTP-301
if not ONLY or '301' in ONLY:
    fig, ax = sheet('T3 · INTRACAVITY FILM STATION (FELICE-TYPE) · GA', 'PTP-301', 11, '1:10 · NTS', TT)
    label(ax, 24, 279, 'CAVITY LAYOUT (schematic, indicative)', 'FEL oscillator with intracavity focus F; film station on the axis at distance d from F')
    y0 = 252
    ax.add_patch(Rectangle((40, y0 - 9), 3, 18, fc='0.35', ec='k', lw=0.5)); ax.text(41.5, y0 - 12.5, 'M1', fontsize=5, ha='center', va='top')
    ax.add_patch(Rectangle((214, y0 - 9), 3, 18, fc='0.35', ec='k', lw=0.5)); ax.text(215.5, y0 - 12.5, 'M2 (outcoupler)', fontsize=5, ha='center', va='top')
    for i in range(14):
        ax.add_patch(Rectangle((58 + i * 4, y0 + 4), 3.6, 3, fc=('#c0392b' if i % 2 else '#1f5fbf'), lw=0)); ax.add_patch(Rectangle((58 + i * 4, y0 - 7), 3.6, 3, fc=('#1f5fbf' if i % 2 else '#c0392b'), lw=0))
    ax.text(86, y0 + 9.5, 'UNDULATOR', fontsize=5, ha='center')
    ax.annotate('', xy=(58, y0), xytext=(30, y0 - 14), arrowprops=dict(arrowstyle='-|>', lw=0.6, color=GR, mutation_scale=6)); ax.text(28, y0 - 17, 'e⁻ from linac', fontsize=4.6, color=GR)
    xs = np.linspace(43, 214, 300); xF = 136; kx = 0.085
    zz = (xs - xF) / kx
    for (cc, col) in ((C[0], '#7b3fa0'),):
        w = cc['w0'] * np.sqrt(1 + (zz / cc['zR']) ** 2); w = np.minimum(w, 30)
        ax.fill_between(xs, y0 + w * 0.32, y0 - w * 0.32, color='#efe4f5', lw=0)
        ax.plot(xs, y0 + w * 0.32, color=col, lw=0.5); ax.plot(xs, y0 - w * 0.32, color=col, lw=0.5)
    ax.plot([43, 214], [y0, y0], color='k', lw=0.3, ls=(0, (10, 2, 2, 2)))
    ax.plot(xF, y0, 'o', ms=2.5, color=RD); ax.text(xF, y0 + 3, 'F', fontsize=6, color=RD, ha='center', weight='bold')
    ax.text(xF, y0 - 6.5, 'existing stations', fontsize=4.4, ha='center', color='0.3')
    for zf, lab, col in ((C[0]['z_film'], 'film: corrected d', RD), (C[0]['z_beam'], 'plan d', '0.4')):
        xx = xF + zf * kx; ax.plot([xx - 1.2, xx + 1.2], [y0 - 9, y0 + 9], color=col, lw=1.4); ax.text(xx, y0 + 11 + (4 if col != RD else 0), lab, fontsize=4.5, ha='center', color=col)
    ax.text(126, 232, f"envelope: w₀ = {C[0]['w0']:.2f}–{C[1]['w0']:.2f} mm at F (33–53 mJ/cm², 400 µJ), z_R = {C[0]['zR']:.0f}–{C[1]['zR']:.0f} mm · vertical exaggerated ≈ 40×", fontsize=4.5, ha='center')
    label(ax, 24, 224, 'SECTION A–A  1:10', 'horizontal, at beam height (z = 0), from +z')
    SP = PJ['secZ_polys']
    PA = dsect(ax, SP, 10, np.array([0.0, 230.0]), np.array([74.0, 155.0]), clip=(24, 104, 126, 220))
    ax.plot(*zip(PA(-480, 0), PA(480, 0)), color=RD, lw=0.6, ls=(0, (8, 2, 2, 2)))
    ax.annotate('', xy=PA(-330, 0) + (5, 0), xytext=PA(-330, 0), arrowprops=dict(arrowstyle='-|>', color=RD, lw=0.7, mutation_scale=6))
    n2 = np.array([math.cos(math.radians(thB)), math.sin(math.radians(thB))])
    ax.plot(*zip(PA(0, 0), PA(*(n2 * 120))), color=BL, lw=0.4, ls=(0, (3, 1.5))); ax.text(*(PA(*(n2 * 128)) + (0.5, 0)), 'n', fontsize=5.5, color=BL, style='italic')
    angle_mark(ax, PA(0, 0), 9, 0, thB, f'{thB:.1f}°', fs=4.6)
    leader(ax, PA(-6, 3), (40, 186), 'holder at Brewster\n(PTP-302)', fs=4.5, ha='right') if False else leader(ax, PA(-6, 3), (36, 180), 'holder at Brewster (PTP-302)', fs=4.5)
    leader(ax, PA(240, 60), (108, 132), 'gate valve, open while lasing', fs=4.5, ha='left') if False else leader(ax, PA(290, -95), (98, 112), 'gate valves to cavity', fs=4.5)
    leader(ax, PA(*(np.array([math.cos(math.radians(thB - 30)), math.sin(math.radians(thB - 30))]) * 190)), (104, 184), 'probe in (diamond window)', fs=4.5)
    leader(ax, PA(*(np.array([math.cos(math.radians(thB + 30)), math.sin(math.radians(thB + 30))]) * 190)), (30, 206), 'probe out', fs=4.5)
    leader(ax, PA(*(n2 * 330)), (104, 205), 'load lock + transfer arm', fs=4.5)
    ax.text(*(PA(-430, -30) + (0, -2)), 'FEL axis', fontsize=4.6, color=RD)
    label(ax, 130, 224, 'ELEVATION  1:10', 'from −y · beam pipes and −x valve omitted')
    ve = View(ax, PJ['elev'], 10, 178, 158); ve.draw(hidden=False, lw=0.35)
    leader(ax, ve.P(0, 400), (200, 214), 'UHV LHe flow cryostat', fs=4.5)
    leader(ax, ve.P(0, -400), (200, 108), 'ion pump + NEG, turbo', fs=4.5)
    leader(ax, ve.P(240, 0), (208, 190), 'CF100 + gate valve', fs=4.5)
    put_image(ax, Image.open(f'{OUT}/renders/T3_station_cutaway.png'), 232, 176, 174, 100, title='CUTAWAY · chamber front half removed')
    rows = [('ITEM', 'QTY', 'DESCRIPTION', 'NOTE'),
            ('1', '1', 'Chamber Ø254 × 300, CF200 top, CF100 beam ports ×2', '316LN, ≤ 1e-10 mbar'),
            ('2', '2', 'CF100 gate valves to the cavity', 'interlocked to vacuum'),
            ('3', '1', 'UHV LHe flow cryostat 5–300 K, Cu cold finger Ø20', '≥ 15 W at 100 K'),
            ('4', '1', 'Holder assembly (PTP-302) in Cu receiver', 'dovetail along n'),
            ('5', '2', 'CF40 viewports, diamond (or ZnSe), ±30° about n', 'IR + 800 nm probes'),
            ('6', '1', 'Load lock (6-way CF40, turbo) + gate valve', 'suitcase on top'),
            ('7', '1', 'Magnetic linear transfer arm 600 mm along n', '—'),
            ('8', '1', 'Ion pump 300 l/s + NEG; valved turbo for pump-down', '—'),
            ('9', '1', 'CF40 RF feedthrough, 2 × SMA 40 GHz; 2 × 19-pin', 'CPW, sensors'),
            ('10', '1', 'Cu radiation shield on cold finger', '—')]
    table(ax, 232, 170, [8, 8, 112, 46], rows, fs=4.6, title='PARTS')
    rows2 = [('OPTICAL AND THERMAL BUDGET', 'VALUE'),
             ('Brewster angle, diamond n = 2.38 at 30 µm', f'{thB:.1f}°; cos θ_B = {cB:.3f}; footprint ×{1 / cB:.2f}'),
             ('focus: 400 µJ, 33–53 mJ/cm²', f"w₀ {C[0]['w0']:.2f}–{C[1]['w0']:.2f} mm, z_R {C[0]['zR']:.0f}–{C[1]['zR']:.0f} mm"),
             ('plan: w = 8.0 mm (0.4 mJ/cm² in the beam)', f"d = {C[1]['z_beam'] / 1000:.2f}–{C[0]['z_beam'] / 1000:.2f} m; on the tilted film only {0.4 * cB:.2f} mJ/cm²"),
             ('corrected: 0.4 mJ/cm² on the film plane', f"w = {C[0]['w_film']:.1f} mm at d = {C[1]['z_film'] / 1000:.2f}–{C[0]['z_film'] / 1000:.2f} m; footprint {NUM['footprint_mm'][0]:.1f} × {NUM['footprint_mm'][1]:.1f} mm (1/e²)"),
             ('passes per 8 µs macropulse (1 GHz, both directions)', f"{NUM['passes']:,.0f}"),
             ('absorbed per macropulse (A = 0.1–0.2)', f"{NUM['E_abs_J'][0]:.2f}–{NUM['E_abs_J'][1]:.2f} J; {NUM['P_avg_W'][0]:.0f}–{NUM['P_avg_W'][1]:.0f} W at 10 Hz"),
             ('diamond column 0.5 mm under footprint (Debye c, upper bound)', f"100 K → {NUM['T_end_100K'][0]:.0f}–{NUM['T_end_100K'][1]:.0f} K per macropulse; 2 µs: → {NUM['T_end_100K_2us'][0]:.0f}–{NUM['T_end_100K_2us'][1]:.0f} K"),
             ('from 10 K base (below T_c 19 K)', f"→ {NUM['T_end_10K'][0]:.0f}–{NUM['T_end_10K'][1]:.0f} K: low-T controls at reduced power only")]
    table(ax, 24, 96, [86, 118], rows2, fs=4.6, title=None)
    notes(ax, 232, 112, 174, [
        'Check the hold fluence against the film plane: at Brewster incidence the film sees cos θ_B = 0.39 of the beam fluence, so the plan distance (0.58–0.73 m) underdrives it; this sheet uses 0.36–0.45 m.',
        'The macropulse heats the film by tens of kelvin (table). Measure it with the on-chip RTD and offer 2 µs macropulses (≈ 4,000 re-drives) as the fallback.',
        'Lasing needs film absorption A below the headroom g − L (FELIX 0.45; FHI ≈ 1.9; ELBE U100 0.15–0.40). Confirm cavity losses and the station position with the facility.'], fs=4.7)
    save(fig, 'PTP-301')

# =====================================================================================  PTP-302
if not ONLY or '302' in ONLY:
    fig, ax = sheet('T3 · FILM HOLDER, BREWSTER PLATE AND SENSORS · DETAILS', 'PTP-302', 12, '2:1 · 5:1', TT)
    label(ax, 24, 279, 'HOLDER  2:1', 'view on the film face (from +n, z up); FEL footprint red; coil hidden')
    vh = View(ax, PJ['hold_front'], 0.5, 90, 222); vh.draw(hidden=True, lw=0.5)
    fp = NUM['footprint_mm']
    ax.add_patch(Ellipse(vh.P(0, 0), fp[0] * 2, fp[1] * 2, fill=False, ec=RD, lw=0.7, ls=(0, (4, 2))))
    ax.text(*(vh.P(0, 0) + (0, -fp[1] - 2.5)), f'FEL footprint {fp[0]:.1f} × {fp[1]:.1f} (1/e²)', fontsize=4.6, ha='center', color=RD, va='top')
    dim(ax, vh.P(-21, -13), vh.P(21, -13), -7, '42', fs=4.6, mode='h')
    dim(ax, vh.P(-14, 6.5), vh.P(14, 6.5), 0, '', fs=1) if False else None
    dim(ax, vh.P(21, -13), vh.P(21, 13), 6, '26', fs=4.6, mode='v')
    dim(ax, vh.P(-25, 13), vh.P(25, 13), 0, '', fs=1) if False else None
    leader(ax, vh.P(6, 2), (32, 262), 'film K₃C₆₀ 26 × 10', fs=4.6)
    leader(ax, vh.P(-13.5, 0), (140, 262), 'Au CPW pads ×2 (pre-patterned)', fs=4.6)
    leader(ax, vh.P(0, 5.9), (140, 252), 'Faraday sensor (GaP 50 µm)', fs=4.6)
    leader(ax, vh.P(-17, 0), (32, 200), 'Pt RTD on diamond (fast ΔT)', fs=4.6)
    leader(ax, vh.P(17, -9.5), (140, 196), 'planar field coil (hidden),\n20 turns, ±100 µT at film', fs=4.6)
    leader(ax, vh.P(0, 19), (60, 270), 'Cu receiver (dovetail along n)', fs=4.6) if False else leader(ax, vh.P(10, 22), (140, 272), 'Cu receiver, dovetail along n', fs=4.6)
    label(ax, 24, 172, 'SECTION B–B  5:1', 'horizontal through z = 0, left edge (view from +z) · film drawn 20 µm')
    HS = PJ['hold_sec_polys']
    # section coordinates: x along n (from Vx = n), y along z x n ... draw near the left edge of the window
    allx = np.vstack([o for _, (o, h) in HS])
    PB = dsect(ax, HS, 0.2, np.array([-1.0, -15.0]), np.array([75.0, 132.0]), clip=(26, 100, 126, 166), lw=0.5)
    ax.add_patch(Rectangle((26, 100), 100, 66, fill=False, lw=0.3, ls=(0, (4, 2))))
    ax.annotate('', xy=PB(4, -12), xytext=PB(-6, -12 - 10 / math.tan(math.radians(thB)) * 0 - 3.9), arrowprops=dict(arrowstyle='-|>', color=RD, lw=0.6, mutation_scale=5)) if False else None
    for lab_, xy_, at_ in (('diamond 0.5', (0.25, -10), (128, 150)), ('frame Cu 3', (-1.5, -18), (128, 140)), ('clamp Cu 1', (1.0, -18), (128, 130)), ('film 10–20 nm', (0.51, -11), (128, 160))):
        leader(ax, PB(*xy_), at_, lab_, fs=4.6)
    label(ax, 140, 172, 'BREWSTER GEOMETRY', 'horizontal plane · p-polarised FEL · not to scale')
    gx, gy = 185, 132
    nn = np.array([math.cos(math.radians(thB)), math.sin(math.radians(thB))]); tt = np.array([nn[1], -nn[0]])
    ax.plot(*zip((gx, gy) - tt * 30, (gx, gy) + tt * 30), color='#7fb6d8', lw=3.0, solid_capstyle='butt')
    ax.plot(*zip((gx - 44, gy), (gx, gy)), color=RD, lw=0.9); ax.annotate('', xy=(gx - 12, gy), xytext=(gx - 30, gy), arrowprops=dict(arrowstyle='-|>', color=RD, lw=0.9, mutation_scale=7))
    thT = 90 - thB; dT = np.array([math.cos(math.radians(thB - thT)), math.sin(math.radians(thB - thT))])
    ax.plot(*zip((gx, gy), (gx + 40, gy)), color=RD, lw=0.9, ls=(0, (4, 2)))
    ax.plot(*zip((gx, gy) - nn * 22, (gx, gy) + nn * 22), color=BL, lw=0.4, ls=(0, (3, 1.5))); ax.text(*((gx, gy) + nn * 24), 'n', fontsize=6, color=BL, style='italic')
    ax.add_patch(Arc((gx, gy), 26, 26, theta1=180, theta2=180 + thB, lw=0.5)); ax.text(gx - 17, gy - 7.5, f'θ_B = {thB:.1f}°', fontsize=4.8)
    for xx in (gx - 38, gx - 26): ax.annotate('', xy=(xx, gy + 3.5), xytext=(xx, gy - 3.5), arrowprops=dict(arrowstyle='<|-|>', lw=0.5, mutation_scale=4, color=RD))
    ax.text(gx - 32, gy + 6, 'E (p)', fontsize=4.6, ha='center', color=RD)
    ax.text(gx + 3, gy - 30, f'footprint = beam × {1 / cB:.2f} along the plate\nfluence on plate = beam × {cB:.3f}\nno reflection for p-pol at θ_B (both passes)', fontsize=4.6, va='top')
    ax.text(gx + 28, gy + 3, 'to M2', fontsize=4.5, color=RD)
    put_image(ax, Image.open(f'{OUT}/renders/T3_holder_iso.png'), 232, 196, 84, 80, title='HOLDER ISOMETRIC')
    rows = [('LAYER / PART', 'SPEC'),
            ('substrate', 'CVD diamond, optical grade, 30 × 16 × 0.5, both sides polished; sapphire is opaque at 30 µm'),
            ('CPW pads', 'Ti 5 / Au 100 nm, patterned before growth; strip 2 × 22 between pads'),
            ('film', 'K₃C₆₀ 10–20 nm by MBE: C₆₀ + K, 12–24 ML at ≈ 2 ML/h (6–12 h); never exposed to air'),
            ('magnetometry', 'GaP 50 µm magneto-optic layer at the film edge; 800 nm probe; target ≤ 50 nT'),
            ('thermometry', 'Pt thin-film RTD on diamond (µs response) + Cernox on frame'),
            ('field', 'planar coil 20 t around the window: ≈ 0.2 mT/A at the film centre'),
            ('mount', 'frame + clamp OFHC Cu, Au plated; In foil to receiver; alignment θ_B ±0.2°')]
    table(ax, 320, 276, [26, 60], rows, fs=4.5, title='STACK AND SPECIFICATION')
    rows3 = [('ITEM', 'QTY', 'PART'), ('1', '1', 'diamond plate with film, pads, sensor, RTD'), ('2', '1', 'Cu frame 42 × 26 × 3, window 28 × 13'),
             ('3', '1', 'Cu clamp 42 × 26 × 1'), ('4', '1', 'planar field coil, 20 t, Kapton Cu'), ('5', '1', 'Cernox on frame'),
             ('6', '1', 'Cu receiver on cold finger'), ('7', '2', 'semi-rigid coax to RF feedthrough')]
    table(ax, 232, 120, [10, 10, 154], rows3, fs=4.7, title='HOLDER PARTS')
    notes(ax, 24, 92, 200, [
        'Grow the film on the finished plate (pads, sensor and RTD already in place), transfer in UHV only (suitcase ≤ 1e-10 mbar), and mount at room temperature before cooling.',
        'Set the plate to Brewster with the FEL at low power by minimising the back-reflected p power; record the angle.',
        'Field-expulsion runs: ±100 µT from the planar coil, field reversed every macropulse pair; the Faraday signal is differenced between FEL-on and FEL-off macropulses.',
        'The film absorbs only near the footprint; the CPW strip lies on the footprint’s long axis so transport probes the driven region.'], fs=4.8)
    save(fig, 'PTP-302')

# =====================================================================================  PTP-303
if not ONLY or '303' in ONLY:
    fig, ax = sheet('T3 · TIMING, READOUT AND SAMPLE TRANSFER · BLOCK DIAGRAM', 'PTP-303', 13, 'NTS', TT)
    label(ax, 24, 281, 'TIMING AND READOUT', 'macropulse-resolved; facility items dashed')
    a1 = blk(ax, 24, 248, 52, 24, 'FEL (FELICE-type)', ['linac + undulator + cavity', '10 Hz × 8 µs, 1 GHz'], dash=True)
    a2 = blk(ax, 24, 216, 52, 24, 'RF MASTER + TIMING', ['3 GHz master, 10 Hz', 'macropulse trigger'], dash=True)
    a3 = blk(ax, 82, 248, 52, 24, 'FEL DIAGNOSTICS', ['outcoupled power (pyro, fast)', 'spectrum, detuning'], dash=True)
    a4 = blk(ax, 140, 248, 60, 24, 'FILM STATION', ['film · GaP sensor · RTD · CPW', 'planar coil · Cernox'], fc='#fff8e6')
    a5 = blk(ax, 82, 216, 52, 24, 'DELAY GENERATORS', ['probe sync, digitizer', 'gates (FEL on/off)'], fc='#eaf1fb')
    b1 = blk(ax, 210, 248, 60, 24, 'FARADAY PROBE', ['synchronised fs laser 800 nm', 'polariser → sensor → Wollaston'])
    b2 = blk(ax, 210, 216, 60, 24, 'BALANCED DETECTOR', ['2 photodiodes, 100 MHz', '≤ 50 nT after averaging'])
    b3 = blk(ax, 276, 248, 60, 24, 'IR REFLECTIVITY', ['mid/far-IR probe (QCL or OPA)', 'MCT / bolometer detectors'])
    b4 = blk(ax, 276, 216, 60, 24, 'TRANSPORT', ['bias tee + µA–mA source', '40 GHz sampling / on-chip voltmeter'])
    b5 = blk(ax, 342, 248, 64, 24, 'TEMPERATURE', ['336-class ctrl, Cernox + heater', 'RTD 4-wire, 1 MHz amp'])
    b6 = blk(ax, 342, 216, 64, 24, 'FIELD COIL SUPPLY', ['bipolar ±0.5 A', 'reverse per macropulse pair'])
    c1 = blk(ax, 140, 184, 130, 24, 'MACROPULSE DIGITIZERS', ['≥ 1 GS/s, 8 ch: balanced PD, MCT, CPW, RTD, FEL power', 'tagged FEL-on / FEL-off'], fc='#eaf1fb')
    c2 = blk(ax, 276, 184, 60, 24, 'VACUUM + INTERLOCK', ['p > 1e-8 mbar → close', 'gate valves, stop FEL'], fc='#fdecea')
    c3 = blk(ax, 342, 184, 64, 24, 'DAQ PC', ['σ₁, σ₂, R(t), B(t), T(t)', 'per macropulse'])
    route(ax, [a1.p('R'), a3.p('L')], kind='optical'); route(ax, [a1.p('T', 0.6), (55.2, 276), (170, 276), a4.p('T')], kind='optical', label='intracavity beam', li=1, loff=(0, 1.2))
    route(ax, [a2.p('R'), a5.p('L')], kind='trigger'); route(ax, [a2.p('T'), a1.p('B')], kind='trigger')
    route(ax, [a5.p('R', 0.7), (137, 232.8), (137, 244), (240, 244), b1.p('B')], kind='trigger') if False else route(ax, [a5.p('R', 0.7), (205, 232.8), (205, 260), b1.p('L')], kind='trigger', label='sync', li=0, loff=(0, 1.2))
    route(ax, [b1.p('T', 0.3), (228, 274), (190, 274), (190, 272)], kind='optical', arrow=True) if False else route(ax, [b1.p('L', 0.2), (203, 252.8), a4.p('R', 0.2)], kind='optical')
    route(ax, [a4.p('R', 0.6), (206, 262.4), (206, 228), b2.p('L')], kind='optical') if False else None
    route(ax, [b1.p('B'), b2.p('T')], kind='optical', label='after sensor', li=0, loff=(9, 0))
    route(ax, [b2.p('B'), (240, 212), (200, 212), c1.p('T', 0.46)], kind='signal')
    route(ax, [b3.p('B', 0.3), (294, 212), (300, 212)], kind='signal', arrow=False) if False else route(ax, [b3.p('L', 0.5), (273, 260), (273, 212), (230, 212), c1.p('T', 0.69)], kind='signal')
    route(ax, [b4.p('B'), c1.p('R', 0.7)], kind='signal') if False else route(ax, [b4.p('B', 0.5), (306, 211), (272, 211), (272, 200), c1.p('R', 0.67)], kind='rf')
    route(ax, [c1.p('R', 0.35), (276, 192.4)], kind='data', arrow=False) if False else None
    route(ax, [c1.p('B', 0.5), (205, 178), (374, 178), c3.p('B')], kind='data')
    route(ax, [a3.p('B', 0.5), (108, 244), (108, 240)], kind='signal', arrow=False) if False else route(ax, [a3.p('B', 0.7), (118.4, 212), (150, 212), c1.p('T', 0.08)], kind='signal')
    route(ax, [a5.p('B', 0.5), (108, 196), c1.p('L')], kind='trigger', label='gates', li=0, loff=(-4, 0))
    sig_legend(ax, 24, 205, ['optical', 'trigger', 'signal', 'rf', 'data'], cols=1, colw=50)

    label(ax, 24, 160, 'PULSE STRUCTURE AND RE-DRIVE', 'not to scale')
    ax.text(26, 150, '10 Hz', fontsize=4.8, va='center')
    for k in range(4): ax.add_patch(Rectangle((40 + k * 40, 146), 3, 8, color=RD, lw=0))
    ax.text(60, 157, '100 ms', fontsize=4.5, ha='center'); ax.annotate('', xy=(80, 155.5), xytext=(40, 155.5), arrowprops=dict(arrowstyle='<|-|>', lw=0.4, mutation_scale=4))
    ax.plot([43, 70], [146, 128], color='0.5', lw=0.3); ax.plot([40, 26], [146, 128], color='0.5', lw=0.3)
    for k in range(26): ax.plot([28 + k * 6.5] * 2, [118, 126], color=RD, lw=0.8)
    ax.text(110, 129, 'macropulse 8 µs: micropulses every 1 ns (≈ 8,000 per direction)', fontsize=4.6, ha='center')
    tx = np.linspace(0, 1, 400); xs_ = 28 + tx * 160
    yv = []
    for t_ in tx * 24.6:
        yv.append(1 - 0.35 * (1 - math.exp(-(t_ % 1.0) / 10.0)) * 3 if False else 0.92 + 0.08 * math.exp(-(t_ % 1.0) / 0.25))
    ax.plot(xs_, 98 + np.array(yv) * 12, color=BL, lw=0.7)
    ax.plot([188, 205], [98 + 0.92 * 12, 98 + 0.92 * 12 * math.exp(-1.5)], color=BL, lw=0.7, ls=(0, (2, 1)))
    ax.text(110, 94, 'driven state order parameter (sketch): lifetime ≈ 10 ns at 100 K ≫ 1 ns re-drive interval', fontsize=4.6, ha='center', color=BL)
    ax.text(206, 104, 'decay\nafter train', fontsize=4.3, color=BL)

    label(ax, 232, 160, 'SAMPLE PATH (never in air)', None)
    s1 = blk(ax, 232, 128, 40, 26, 'MBE', ['diamond prep, pads', 'C₆₀ + K, 12–24 ML', '≈ 2 ML/h, 6–12 h'])
    s2 = blk(ax, 278, 128, 40, 26, 'UHV SUITCASE', ['≤ 1e-10 mbar', 'ion + NEG, battery', 'transport ≤ 48 h'])
    s3 = blk(ax, 324, 128, 40, 26, 'LOAD LOCK', ['pump to 1e-8', 'with turbo, 2 h', 'open valve'])
    s4 = blk(ax, 370, 128, 36, 26, 'COLD FINGER', ['dovetail along n', 'at 300 K,', 'then cool'])
    for a_, b_ in ((s1, s2), (s2, s3), (s3, s4)): route(ax, [a_.p('R'), b_.p('L')], kind='vacuum')
    rows = [('CONTROL', 'PURPOSE'), ('drive at 41 THz (off resonance)', 'heating vs resonant drive'), ('fluence below threshold', 'state not reached'),
            ('undoped C₆₀ film', 'no superconducting channel'), ('base T from < T_c (19 K) to 300 K', 'equilibrium SC and its absence; low-T only at reduced power'),
            ('cavity with no film', 'baseline lasing, loss budget'), ('field reversed ±100 µT', 'separate expulsion from offsets')]
    table(ax, 232, 118, [70, 104], rows, fs=4.7, title='CONTROLS')
    rows2 = [('PASS', 'zero resistance and field expulsion (χ_v well below −0.1) held through the macropulse at ≥ 100 K'),
             ('FAIL', 'no expulsion at ≈ 50 nT resolution: not a superconductor (high-mobility metal); B7 cut')]
    table(ax, 24, 84, [16, 188], rows2, fs=4.8, header=False, shade_first=False)
    notes(ax, 24, 68, 204, ['Every channel is recorded for FEL-on and FEL-off macropulses at the same base temperature; the difference is the driven response.',
                            'The RTD trace sets the true film temperature during the train; quote results against it, not the cryostat reading.'], fs=4.8)
    save(fig, 'PTP-303')
print('ok')
