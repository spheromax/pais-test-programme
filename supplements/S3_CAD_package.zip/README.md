# Pais gap loop: test programme drawing set (PTP-000 to PTP-902)

Concept A3 drawings, CAD and equipment lists for the five tests left by the gap research loop (stopped after run 11). 13 Nov 2026. Status: concept design for review, not for manufacture.

## Contents
- `PTP_test_programme_A3_drawing_set.pdf`: 20 A3 sheets (vector). Cover/index, then T1 (101–105), T2 (201–204), T3 (301–303), T4 (401–403), T5 (501–502), equipment lists (901–902).
- `step/`: colour STEP assemblies with named parts. Files: T1 track fixture, T1 coupon + sabot, T2a I_c probe, T2b ring + mapper, T3 FEL station, T4a balance, T4b detector, T5 X1 balance.
- `dxf/`: 1:1 views and sections in mm (layers VISIBLE, HIDDEN, SECTION, TEXT).
- `renders/`: shaded views. `png/`: sheet previews.
- `scripts/`:
  - `ptp.py`: helpers for sheets, HLR, sections, renders and symbols.
  - `t*_model.py`: CadQuery models and computed numbers.
  - `t*_sheets.py`: the drawings.
  - Run order per test: model, then sheets.
- `numbers/`: JSON of every geometry-derived number on the sheets.
- `PTP_equipment_list.csv` / `.md`: the PTP-901/902 tables.

## Design checks raised while drawing
1. **T3.** At Brewster incidence the film plane sees cos θ_B = 0.39 of the beam fluence. If the 0.4 mJ/cm² hold fluence applies to the film plane, move the film to w ≈ 5 mm, i.e. 0.36–0.45 m from focus, not 0.58–0.73 m. The footprint is then 25.6 × 9.9 mm (1/e²).
2. **T3 heating.** With A = 0.1–0.2 and 16,000 passes, each 8 µs macropulse deposits 0.64–1.28 J. The diamond column under the footprint rises from 100 K to about 155–180 K (Debye upper bound). Hence the on-chip RTD and the 2 µs-macropulse fallback. Controls below T_c are possible only at reduced power.
3. **T2b.** Single ring rather than a split pair: at the same orbit field, two coils would pull together with about 2 MN. Working point is 300 A: 1.15 T on the orbit, 2.7 T peak, about 210 MPa hoop stress. Needs 3.2 km of 12 mm tape.
4. **T2a.** A 0.5 mm bridge carrying about 700 A has almost no copper, so it needs a trip in under 100 µs and an IGBT diverter. Millisecond current pulses are the option for the highest currents.
5. **T1.** The target tank must hold ≤ 1 mbar (at 1 atm, drag costs about 0.3 % of speed per metre). Fixture mass is 668 kg. Witness plates are polycarbonate so the cameras can see the channel.
